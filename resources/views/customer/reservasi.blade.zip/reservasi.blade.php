@extends('layouts.landing')

@section('title', 'Reservasi - BigBang Eatery')

@section('content')
<div class="pt-24 pb-10">
    <div class="max-w-4xl mx-auto px-4">
        <h1 class="text-3xl font-black text-center mb-2">📅 Reservasi</h1>
        <p class="text-stone-500 text-center mb-8">Isi formulir di bawah untuk melakukan reservasi meja</p>

        <div class="bg-white rounded-xl border-4 border-stone-900 shadow-[8px_8px_0_0_rgba(0,0,0,0.3)] p-6 md:p-8">
            @if(session('error'))
                <div class="mb-4 p-3 rounded-lg bg-red-50 border-2 border-red-400 text-red-700 font-bold">
                    {{ session('error') }}
                </div>
            @endif

            @if($errors->any())
                <div class="mb-4 p-3 rounded-lg bg-red-50 border-2 border-red-400 text-red-700">
                    <ul class="list-disc list-inside text-sm">
                        @foreach($errors->all() as $err)
                            <li class="font-medium">{{ $err }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <form id="reservasiForm" action="{{ route('customer.reservasi.store') }}" method="POST" class="space-y-5">
                @csrf

                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <!-- Nama Customer -->
                    <div>
                        <label class="block font-bold mb-1">Nama Pemesan <span class="text-red-500">*</span></label>
                        <input type="text" name="nama" value="{{ old('nama') }}" required
                               class="w-full border-2 @error('nama') border-red-500 bg-red-50 @else border-stone-300 @enderror rounded-lg px-4 py-3 focus:border-[#4A2311] focus:outline-none">
                        @error('nama')
                            <p class="text-red-500 text-xs mt-1 font-bold">⚠️ {{ $message }}</p>
                        @enderror
                    </div>

                    <!-- No WA -->
                    <div>
                        <label class="block font-bold mb-1">Nomor Telepon (WhatsApp Kalau Ada) <span class="text-red-500">*</span></label>
                        <input type="text" name="nomor_telp" value="{{ old('nomor_telp') }}" required placeholder="08xxxxxxxxxx"
                               class="w-full border-2 @error('nomor_telp') border-red-500 bg-red-50 @else border-stone-300 @enderror rounded-lg px-4 py-3 focus:border-[#4A2311] focus:outline-none">
                        @error('nomor_telp')
                            <p class="text-red-500 text-xs mt-1 font-bold">⚠️ {{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Tanggal -->
                    <div>
                        <label class="block font-bold mb-1">Tanggal <span class="text-red-500">*</span></label>
                        <input type="date" name="tanggal" id="reservasiTanggal" required
                               value="{{ old('tanggal', $prefill['tanggal'] ?? '') }}"
                               min="{{ date('Y-m-d') }}"
                               class="w-full border-2 @error('tanggal') border-red-500 bg-red-50 @else border-stone-300 @enderror rounded-lg px-4 py-3 focus:border-[#4A2311] focus:outline-none">
                        @error('tanggal')
                            <p class="text-red-500 text-xs mt-1 font-bold">⚠️ {{ $message }}</p>
                        @else
                            <p class="text-xs text-stone-500 mt-1">Pilih tanggal yang tersedia</p>
                        @enderror
                    </div>

                    <!-- Jam Mulai -->
                    <div>
                        <label class="block font-bold mb-1">Jam Mulai <span class="text-red-500">*</span></label>
                        <input type="time" name="jam_mulai" required
                               value="{{ old('jam_mulai', $prefill['jam_mulai'] ?? '') }}"
                               class="w-full border-2 @error('jam_mulai') border-red-500 bg-red-50 @else border-stone-300 @enderror rounded-lg px-4 py-3 focus:border-[#4A2311] focus:outline-none">
                        @error('jam_mulai')
                            <p class="text-red-500 text-xs mt-1 font-bold">⚠️ {{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Jam Selesai -->
                    <div>
                        <label class="block font-bold mb-1">Jam Selesai <span class="text-red-500">*</span></label>
                        <input type="time" name="jam_selesai" required
                               value="{{ old('jam_selesai', $prefill['jam_selesai'] ?? '') }}"
                               class="w-full border-2 @error('jam_selesai') border-red-500 bg-red-50 @else border-stone-300 @enderror rounded-lg px-4 py-3 focus:border-[#4A2311] focus:outline-none">
                        @error('jam_selesai')
                            <p class="text-red-500 text-xs mt-1 font-bold">⚠️ {{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Jumlah Orang -->
                    <div>
                        <label class="block font-bold mb-1">Jumlah Orang <span class="text-red-500">*</span></label>
                        <input type="number" name="jml_org" required min="1" max="20"
                               value="{{ old('jml_org', $prefill['jml_org'] ?? '') }}"
                               class="w-full border-2 @error('jml_org') border-red-500 bg-red-50 @else border-stone-300 @enderror rounded-lg px-4 py-3 focus:border-[#4A2311] focus:outline-none">
                        @error('jml_org')
                            <p class="text-red-500 text-xs mt-1 font-bold">⚠️ {{ $message }}</p>
                        @enderror
                    </div>
                </div>

                <!-- Keterangan -->
                <div>
                    <label class="block font-bold mb-1">Keterangan</label>
                    <textarea name="keterangan" rows="3" placeholder="Misal: meja dekat jendela, acara ulang tahun, dll..."
                              class="w-full border-2 @error('keterangan') border-red-500 bg-red-50 @else border-stone-300 @enderror rounded-lg px-4 py-3 focus:border-[#4A2311] focus:outline-none">{{ old('keterangan') }}</textarea>
                    @error('keterangan')
                        <p class="text-red-500 text-xs mt-1 font-bold">⚠️ {{ $message }}</p>
                    @enderror
                </div>

                <!-- Pilih Menu (Popup) -->
                <div>
                    <label class="block font-bold mb-3">Pilih Menu (Opsional - bisa diubah hingga H-1 jam sebelum jadwal)</label>
                    <button type="button" onclick="toggleModalVisibility(true)"
                            class="px-4 py-2 bg-amber-100 text-stone-700 font-bold rounded-lg border-2 border-stone-900 shadow-[3px_3px_0_0_rgba(0,0,0,0.2)] hover:bg-amber-200 transition">
                        + Tambah Menu
                    </button>
                    
                    <!-- Tempat untuk menampilkan ringkasan menu yang dipilih oleh user -->
                    <div id="selectedMenusSummary" class="mt-4 p-4 bg-stone-50 rounded-xl border-2 border-stone-900 shadow-[4px_4px_0_0_rgba(0,0,0,1)] hidden">
                        <!-- Header Ringkasan -->
                        <div class="flex items-center justify-between pb-3 border-b-2 border-stone-200 mb-3">
                            <div class="flex items-center gap-2">
                                <span class="text-base">📋</span>
                                <h4 class="font-black text-sm text-stone-900 uppercase tracking-wide">Ringkasan Pesanan Menu</h4>
                            </div>
                        </div>
                        <!-- Daftar Item Terpilih (Render via JavaScript) -->
                        <div id="summaryList" class="space-y-2 max-h-48 overflow-y-auto pr-1"></div>

                        <!-- Footer Ringkasan (Total Porsi & Estimasi Harga) -->
                        <div class="mt-3 pt-3 border-t-2 border-stone-200 flex justify-between items-center text-sm">
                            <span class="text-xs font-bold text-stone-500 uppercase">Total Menu</span>
                            <div class="text-right">
                                <span id="summaryTotalItems" class="font-bold text-stone-700">0 Item</span>
                                <span class="text-stone-300 mx-1">|</span>
                                <span id="summaryTotalPrice" class="font-black text-[#4A2311] text-base">Rp 0</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tombol -->
                <div class="flex gap-3 pt-3">
                    <button id="reservasiSubmitBtn" type="submit"
                            class="flex-1 py-4 bg-[#4A2311] text-white font-black text-lg rounded-lg border-2 border-stone-900 shadow-[5px_5px_0_0_rgba(0,0,0,0.3)] hover:bg-[#8B5A2B] active:shadow-none active:translate-x-[5px] active:translate-y-[5px] transition-all">
                        🔖 Reservasi
                    </button>
                    <a href="{{ url('/') }}"
                    class="px-6 py-4 bg-stone-200 text-stone-700 font-bold text-lg rounded-lg border-2 border-stone-900 shadow-[5px_5px_0_0_rgba(0,0,0,0.3)] hover:bg-stone-300 text-center">
                        Cancel
                    </a>
                </div>

                <!-- MODAL POP UP UTAMA RESERVASI -->
                <div id="multiMenuModal" class="fixed inset-0 z-100 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 hidden">
                    <div class="bg-white w-full max-w-xl rounded-2xl border-4 border-stone-900 shadow-[8px_8px_0_0_rgba(0,0,0,1)] overflow-hidden flex flex-col max-h-[85vh]">
                        
                        <!-- HEADER POPUP -->
                        <div class="bg-[#4A2311] text-white p-4 flex justify-between items-center border-b-4 border-stone-900">
                            <div>
                                <h3 class="text-xl font-black tracking-wide">Pilih Menu Reservasi</h3>
                                <p class="text-xs text-amber-200 font-medium">Minimal pemesanan menu adalah Rp 50.000</p>
                            </div>
                            <button type="button" onclick="toggleModalVisibility(false)" class="w-8 h-8 bg-red-500 rounded-full border-2 border-stone-900 flex items-center justify-center font-black hover:bg-red-600">✕</button>
                        </div>

                        <!-- BILAH PENCARIAN MENU -->
                        <div class="p-4 bg-stone-50 border-b-2 border-stone-200">
                            <div class="relative">
                                <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-stone-400">🔍</span>
                                <input type="text" id="menuSearchInput" onkeyup="filterMenuSearch('menuSearchInput', '#menuItemsContainer .menu-item-card')" placeholder="Cari menu favorit kamu di sini..." 
                                    class="w-full border-2 border-stone-900 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#4A2311]">
                            </div>
                        </div>

                        <!-- DAFTAR ITEM MENU -->
                        <div class="p-4 overflow-y-auto space-y-4 flex-1 bg-stone-100" id="menuItemsContainer">
                            @foreach($menus as $menu)
                            @php
                                $oldQty = old('menu_qty.'.$menu->id, 0);
                                $oldNote = old('menu_notes.'.$menu->id, '');
                            @endphp
                            <div class="menu-item-card bg-white border-2 border-stone-900 rounded-xl p-4 shadow-[3px_3px_0_0_rgba(0,0,0,1)] transition-all {{ $oldQty > 0 ? 'border-amber-700 bg-amber-50/20' : '' }}" data-nama="{{ strtolower($menu->nama) }}" data-harga="{{ $menu->harga }}">
                                <div class="flex items-center justify-between gap-3">
                                    <div class="flex items-center gap-3">
                                        <div class="w-16 h-16 bg-stone-200 rounded-lg border-2 border-stone-300 overflow-hidden flex-shrink-0">
                                            @if(isset($menu->gambar) && $menu->gambar)
                                                <img src="{{ asset('storage/' . $menu->gambar) }}" alt="{{ $menu->nama }}" class="w-full h-full object-cover">
                                            @else
                                                <div class="w-full h-full flex items-center justify-center text-stone-400 text-2xl">🍽️</div>
                                            @endif
                                        </div>
                                        <div>
                                            <h4 class="font-black text-stone-900 text-base menu-item-title">{{ $menu->nama }}</h4>
                                            <p class="text-sm font-bold text-[#8B5A2B]">Rp {{ number_format($menu->harga, 0, ',', '.') }}</p>
                                        </div>
                                    </div>
                                    
                                    <!-- Sisi Kanan: Counter Qty Dynamic -->
                                    <div class="flex items-center gap-3">
                                        <div class="flex items-center border-2 border-stone-900 rounded-lg overflow-hidden bg-stone-50">
                                            <button type="button" onclick="updateQty(this, -1)" class="btn-minus {{ $oldQty > 0 ? '' : 'hidden' }} px-2.5 py-1 bg-red-100 text-red-700 font-black text-sm border-r border-stone-900 hover:bg-red-200">-</button>
                                            
                                            <input type="number" name="menu_qty[{{ $menu->id }}]" value="{{ $oldQty }}" min="0" readonly class="qty-input w-10 text-center font-extrabold text-sm bg-transparent focus:outline-none">
                                            
                                            <button type="button" onclick="updateQty(this, 1)" class="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-black text-sm border-l border-stone-900 hover:bg-emerald-200">+</button>
                                        </div>
                                    </div>
                                </div>

                                <!-- DROPDOWN CATATAN KHUSUS (Muncul jika Qty > 0) -->
                                <div class="note-dropdown {{ $oldQty > 0 ? '' : 'hidden' }} mt-3 pt-3 border-t border-dashed border-stone-300">
                                    <label class="block text-[11px] font-black text-stone-600 uppercase mb-1">✍️ Catatan Khusus Menu:</label>
                                    <textarea name="menu_notes[{{ $menu->id }}]" placeholder="Contoh: Sangat pedas, tanpa es batu..." 
                                              class="w-full text-xs border border-stone-400 rounded-lg p-2 focus:outline-none focus:border-[#4A2311] font-medium">{{ $oldNote }}</textarea>
                                </div>
                            </div>
                            @endforeach
                        </div>

                        <!-- FOOTER POPUP & INDIKATOR TOTAL MINIMAL -->
                        <div class="p-4 bg-white border-t-4 border-stone-900 space-y-3">
                            <div class="flex justify-between items-center text-xs lg:text-sm font-bold">
                                <span class="text-stone-600">Total Pemesanan Menu:</span>
                                <span id="modalTotalDisplay" class="text-base font-black text-[#4A2311]">Rp 0</span>
                            </div>
                            <div id="minOrderWarning" class="text-xs font-bold text-red-600 bg-red-50 p-2 rounded-lg border border-red-200 text-center">
                                ⚠️ Jumlah pemesanan menu Anda belum memenuhi untuk dapat melanjutkan reservasi.
                            </div>
                            <button type="button" id="btnConfirmMenu" onclick="submitSelectedMenus()" disabled
                                class="w-full py-3 bg-stone-400 text-stone-200 font-black rounded-xl border-2 border-stone-900 cursor-not-allowed transition-all uppercase tracking-wider text-sm">
                                Konfirmasi Pilihan Menu
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleModalVisibility(show) {
    const modal = document.getElementById('multiMenuModal');
    if (show) {
        modal.classList.remove('hidden');
        calculateModalTotal();
    } else {
        modal.classList.add('hidden');
    }
}

function updateQty(button, amount) {
    const card = button.closest('.menu-item-card');
    const input = card.querySelector('.qty-input');
    const btnMinus = card.querySelector('.btn-minus');
    const noteDropdown = card.querySelector('.note-dropdown');
    
    let currentVal = parseInt(input.value) || 0;
    currentVal += amount;
    if (currentVal < 0) currentVal = 0;
    
    input.value = currentVal;

    if (currentVal > 0) {
        if (btnMinus) btnMinus.classList.remove('hidden');
        if (noteDropdown) noteDropdown.classList.remove('hidden');
        card.classList.add('border-amber-700', 'bg-amber-50/20');
    } else {
        if (btnMinus) btnMinus.classList.add('hidden');
        if (noteDropdown) noteDropdown.classList.add('hidden');
        card.classList.remove('border-amber-700', 'bg-amber-50/20');
    }

    calculateModalTotal();
}

function calculateModalTotal() {
    const container = document.getElementById('menuItemsContainer');
    if (!container) return;

    const cards = container.querySelectorAll('.menu-item-card');
    let total = 0;

    cards.forEach(card => {
        const qtyInput = card.querySelector('.qty-input');
        const qty = parseInt(qtyInput ? qtyInput.value : 0) || 0;
        const hargaAttr = card.getAttribute('data-harga');
        const harga = parseFloat(hargaAttr) || 0;

        total += (qty * harga);
    });

    const display = document.getElementById('modalTotalDisplay');
    const warning = document.getElementById('minOrderWarning');
    const button = document.getElementById('btnConfirmMenu');

    if (display) {
        display.innerText = 'Rp ' + new Intl.NumberFormat('id-ID').format(total);
    }

    if (total >= 50000) {
        if (warning) warning.classList.add('hidden');
        if (button) {
            button.disabled = false;
            button.className = "w-full py-3 bg-[#4A2311] text-white font-black rounded-xl border-2 border-stone-900 shadow-[4px_4px_0_0_rgba(0,0,0,1)] hover:bg-[#5c2d17] cursor-pointer transition-all uppercase tracking-wider text-sm";
        }
    } else {
        if (warning) warning.classList.remove('hidden');
        if (button) {
            button.disabled = true;
            button.className = "w-full py-3 bg-stone-400 text-stone-200 font-black rounded-xl border-2 border-stone-900 cursor-not-allowed uppercase tracking-wider text-sm";
        }
    }
}

function filterMenuSearch(inputId, cardSelector) {
    const query = document.getElementById(inputId).value.toLowerCase();
    const cards = document.querySelectorAll(cardSelector);
    
    cards.forEach(card => {
        const name = card.getAttribute('data-nama') || '';
        card.style.display = name.includes(query) ? "block" : "none";
    });
}

function submitSelectedMenus() {
    const selectedItems = [];
    const cards = document.querySelectorAll('#menuItemsContainer .menu-item-card');

    cards.forEach(card => {
        const qtyInput = card.querySelector('.qty-input');
        const qty = parseInt(qtyInput ? qtyInput.value : 0) || 0;

        if (qty > 0) {
            const nama = card.querySelector('.menu-item-title').innerText.trim();
            const harga = parseFloat(card.getAttribute('data-harga')) || 0;
            const noteTextarea = card.querySelector('textarea[name^="menu_notes"]');
            const notes = noteTextarea ? noteTextarea.value.trim() : '';

            selectedItems.push({
                nama: nama,
                harga: harga,
                qty: qty,
                notes: notes
            });
        }
    });

    updateSelectedMenuSummary(selectedItems);
    toggleModalVisibility(false);
}

function updateSelectedMenuSummary(selectedItems) {
    const summaryContainer = document.getElementById('selectedMenusSummary');
    const summaryList = document.getElementById('summaryList');
    const totalItemsEl = document.getElementById('summaryTotalItems');
    const totalPriceEl = document.getElementById('summaryTotalPrice');

    if (!selectedItems || selectedItems.length === 0) {
        summaryContainer.classList.add('hidden');
        summaryList.innerHTML = '';
        return;
    }

    let totalQty = 0;
    let totalPrice = 0;
    let listHTML = '';

    selectedItems.forEach(item => {
        const itemTotal = item.harga * item.qty;
        totalQty += item.qty;
        totalPrice += itemTotal;

        listHTML += `
            <div class="flex items-center justify-between text-sm bg-white p-2.5 rounded-lg border border-stone-200">
                <div class="truncate pr-2">
                    <span class="font-bold text-stone-800 block truncate">${item.nama}</span>
                    ${item.notes ? `<p class="text-xs text-stone-500 italic">"${item.notes}"</p>` : ''}
                </div>
                <div class="text-right whitespace-nowrap">
                    <span class="font-black text-[#4A2311] bg-amber-100 px-2 py-0.5 rounded text-xs">${item.qty}x</span>
                    <span class="text-xs font-bold text-stone-600 ml-1">Rp ${itemTotal.toLocaleString('id-ID')}</span>
                </div>
            </div>
        `;
    });

    summaryList.innerHTML = listHTML;
    totalItemsEl.textContent = `${totalQty} Porsi`;
    totalPriceEl.textContent = `Rp ${totalPrice.toLocaleString('id-ID')}`;
    
    summaryContainer.classList.remove('hidden');
}

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('reservasiForm');
    const submitBtn = document.getElementById('reservasiSubmitBtn');

    if (!form) return;

    form.addEventListener('submit', function (e) {
        console.log('[reservasiForm] submit triggered');
        // Tutup modal jika terbuka supaya overlay tidak menutupi navigasi
        try {
            const modal = document.getElementById('multiMenuModal');
            if (modal && !modal.classList.contains('hidden')) {
                modal.classList.add('hidden');
                console.log('[reservasiForm] modal was open, now closed before submit');
            }
        } catch (err) {
            console.warn('[reservasiForm] error closing modal', err);
        }

        // Disable tombol untuk mencegah double click & beri visual feedback
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerText = 'Mengirim...';
            submitBtn.classList.add('opacity-60', 'cursor-not-allowed');
        }

        // small delay to allow modal hide animation (if any), lalu biarkan form submit normal
        // NOTE: jika Anda menggunakan AJAX submit, ubah alur ini sesuai.
    });
});
</script>

@include('partials.floating_cs_wa')
@endsection