@extends('layouts.landing')

@section('title', 'Detail Reservasi - BigBang Eatery')

@section('content')
{{-- WRAPPER UTAMA: pt-20/pt-24 untuk dorong konten dari header fixed --}}
<div class="w-full max-w-[95%] md:max-w-7xl mx-auto px-2 md:px-4 pt-20 mt-4 md:pt-24 pb-5 md:pb-10 flex flex-col justify-start space-y-4 md:space-y-6">

    @if(session('success'))
    <div class="p-3.5 bg-emerald-100 border-2 border-emerald-900 text-emerald-900 font-bold rounded-xl shadow-[3px_3px_0_0_rgba(16,185,129,0.3)] text-sm">
        ✅ {{ session('success') }}
    </div>
    @endif

    {{-- STEPPER STATUS RESERVASI (TANPA BUNGKUS KOTAK) --}}
    @php
        $statusPesanan = $reservasi->pesanan->status ?? 'Reserved';
        $st = strtolower($statusPesanan);
        
        // Step 1: Status Konfirmasi Awal
        if (in_array($st, ['dp_paid', 'confirmed', 'processing', 'completed'])) {
            $step1_title = "DP Terbayar";
            $step1_active = true;
            $step1_cancel = false;
        } elseif ($st === 'cancelled') {
            $step1_title = "Batal";
            $step1_active = true;
            $step1_cancel = true;
        } else {
            $step1_title = "Tunggu Konfirmasi";
            $step1_active = true;
            $step1_cancel = false;
        }

        // Step 2: Proses / Tunggu Check-In
        if (in_array($st, ['confirmed', 'processing', 'completed'])) {
            $step2_title = ($st === 'processing') ? "Pesanan Diproses" : "Tunggu Check-In";
            $step2_active = true;
            $step2_cancel = false;
        } elseif ($st === 'cancelled') {
            $step2_title = "Tidak Diproses";
            $step2_active = true;
            $step2_cancel = true;
        } else {
            $step2_title = "Tunggu Check-In";
            $step2_active = false;
            $step2_cancel = false;
        }

        // Step 3: Reservasi Berhasil / Batal
        if ($st === 'completed') {
            $step3_title = "Reservasi Berhasil";
            $step3_active = true;
            $step3_cancel = false;
        } elseif ($st === 'cancelled') {
            $step3_title = "Reservasi Batal";
            $step3_active = true;
            $step3_cancel = true;
        } else {
            $step3_title = "Tunggu Selesai";
            $step3_active = false;
            $step3_cancel = false;
        }
    @endphp

    <div class="py-2">
        <div class="flex items-start justify-between w-full max-w-xl mx-auto relative">
            
            {{-- Garis Hubung 1-2 --}}
            <div class="absolute left-[16.66%] right-[50%] top-4 md:top-5 h-1 -translate-y-1/2 {{ $step2_active ? ($step2_cancel ? 'bg-red-500' : 'bg-emerald-500') : 'bg-stone-300' }} transition-colors duration-300 z-0"></div>
            
            {{-- Garis Hubung 2-3 --}}
            <div class="absolute left-[50%] right-[16.66%] top-4 md:top-5 h-1 -translate-y-1/2 {{ $step3_active ? ($step3_cancel ? 'bg-red-500' : 'bg-emerald-500') : 'bg-stone-300' }} transition-colors duration-300 z-0"></div>

            {{-- Tahap 1 --}}
            <div class="flex flex-col items-center z-10 flex-1 text-center">
                <div class="w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center font-black text-xs md:text-sm border-2 border-stone-900 {{ $step1_cancel ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white' }} shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                    1
                </div>
                <span class="mt-2 text-[11px] md:text-xs font-black leading-tight max-w-[95px] md:max-w-none {{ $step1_cancel ? 'text-red-600' : 'text-stone-900' }}">
                    {{ $step1_title }}
                </span>
            </div>

            {{-- Tahap 2 --}}
            <div class="flex flex-col items-center z-10 flex-1 text-center">
                <div class="w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center font-black text-xs md:text-sm border-2 border-stone-900 {{ $step2_active ? ($step2_cancel ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white') : 'bg-stone-100 text-stone-400' }} shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                    2
                </div>
                <span class="mt-2 text-[11px] md:text-xs font-black leading-tight max-w-[95px] md:max-w-none {{ $step2_active ? ($step2_cancel ? 'text-red-600' : 'text-stone-900') : 'text-stone-400' }}">
                    {{ $step2_title }}
                </span>
            </div>

            {{-- Tahap 3 --}}
            <div class="flex flex-col items-center z-10 flex-1 text-center">
                <div class="w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center font-black text-xs md:text-sm border-2 border-stone-900 {{ $step3_active ? ($step3_cancel ? 'bg-red-500 text-white' : 'bg-emerald-500 text-white') : 'bg-stone-100 text-stone-400' }} shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                    3
                </div>
                <span class="mt-2 text-[11px] md:text-xs font-black leading-tight max-w-[95px] md:max-w-none {{ $step3_active ? ($step3_cancel ? 'text-red-600' : 'text-stone-900') : 'text-stone-400' }}">
                    {{ $step3_title }}
                </span>
            </div>

        </div>
    </div>

    {{-- KOTAK UTAMA DUAL-PANEL --}}
    {{-- @php
        // $pesananTerkait = \App\Models\Pesanan::where('id_reservasi', $reservasi->id)->with('detailPesanan.menu')->first();
        // $totalMenu = $pesananTerkait ? ($pesananTerkait->detailPesanan->sum('subtotal') ?? 0) : 0;
        // $pb = round($totalMenu * 0.1);
        // $totalTagihan = $totalMenu + $pb;
        // $sisaTagihan = max(0, $totalTagihan - (float) ($reservasi->dp_bayar ?? 0));
    @endphp --}}

    <div class="bg-white border-4 border-stone-900 shadow-[8px_8px_0_0_rgba(0,0,0,1)] rounded-2xl overflow-hidden grid grid-cols-1 md:grid-cols-12">
        
        {{-- PANEL KIRI --}}
        <div class="md:col-span-5 bg-[#4A2311] text-white p-5 md:p-6 flex flex-col justify-between space-y-6">
            <div>
                <div class="pb-3 border-b border-amber-900/60 mb-5">
                    <span class="text-[11px] uppercase tracking-wider text-amber-300 font-bold">Ringkasan Reservasi</span>
                    <h2 class="text-xl font-black text-white">#BBE-{{ $reservasi->id }}</h2>
                </div>

                <div class="space-y-3.5 text-xs md:text-sm">
                    <div class="flex justify-between items-center pb-2 border-b border-amber-900/30">
                        <span class="text-stone-300 font-medium">Tamu</span>
                        <span class="font-bold text-white text-right">{{ $reservasi->customer->nama }}</span>
                    </div>
                    <div class="flex justify-between items-center pb-2 border-b border-amber-900/30">
                        <span class="text-stone-300 font-medium">WhatsApp</span>
                        <span class="font-bold text-white text-right">{{ $reservasi->customer->nomor_telp }}</span>
                    </div>
                    <div class="flex justify-between items-center pb-2 border-b border-amber-900/30">
                        <span class="text-stone-300 font-medium">Jadwal</span>
                        <span class="font-bold text-amber-200 text-right">
                            {{ \Carbon\Carbon::parse($reservasi->tanggal)->format('d M Y') }} ({{ $reservasi->jam_mulai }})
                        </span>
                    </div>
                    <div class="flex justify-between items-center pb-2 border-b border-amber-900/30">
                        <span class="text-stone-300 font-medium">Catatan</span>
                        <span class="font-medium text-stone-200 italic text-right truncate max-w-[180px]">{{ $reservasi->keterangan ?? '-' }}</span>
                    </div>
                </div>
            </div>

            <div class="space-y-3 pt-4 border-t border-amber-900/60">
                <div class="bg-[#36190c] p-3 rounded-xl border border-amber-800/50 flex justify-between items-center">
                    <span class="text-xs text-stone-300 font-bold">Meja Ditunjuk</span>
                    <span class="text-sm font-black text-amber-400">
                        {{ ($st === 'confirmed' && $reservasi->detailReservasi && $reservasi->detailReservasi->isNotEmpty()) ? 'Meja #'.$reservasi->detailReservasi->first()->meja->nomor_meja : 'Belum Ada' }}
                    </span>
                </div>

                <div class="bg-amber-500/10 p-3 rounded-xl border border-amber-500/30 flex justify-between items-center">
                    <span class="text-xs text-amber-200 font-bold">Sisa Pelunasan</span>
                    <span class="text-base font-black text-amber-300">
                        Rp {{ number_format($sisaTagihan, 0, ',', '.') }}
                    </span>
                </div>

                {{-- Tombol Bayar (Muncul hanya jika status masih Pending) --}}
                @if($reservasi->status === 'pending' && !empty($snapToken))
                    <div class="bg-amber-100 border-2 border-amber-500 p-4 rounded-xl mt-4">
                        <p class="font-bold text-amber-900 mb-2">Menunggu Pembayaran DP</p>
                        <button onclick="snap.pay('{{ $snapToken }}')" class="px-4 py-2 bg-[#4A2311] text-white font-bold rounded-lg shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                            Lanjutkan Pembayaran
                        </button>
                    </div>
                    
                    <!-- Script Midtrans -->
                    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ config('midtrans.client_key', env('MIDTRANS_CLIENT_KEY')) }}"></script>
                    <script type="text/javascript">
                        document.addEventListener("DOMContentLoaded", function() {
                            // Otomatis buka pop-up saat halaman detail dimuat
                            snap.pay('{{ $snapToken }}', {
                                onSuccess: function(result) { window.location.reload(); }
                            });
                        });
                    </script>
                @endif
            </div>
        </div>

        {{-- PANEL KANAN --}}
        <div class="md:col-span-7 p-5 md:p-7 flex flex-col justify-between bg-white space-y-6">
            <div>
                <div class="flex justify-between items-center pb-3 border-b-2 border-stone-200 mb-4">
                    <h3 class="font-black text-base md:text-lg text-stone-900">🍳 Menu Pre-Order</h3>
                    @if($bisaUbahMenu)
                        <button type="button" onclick="toggleEditMenuModal(true)" class="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-stone-800 font-black text-xs border-2 border-stone-900 rounded-lg shadow-[2px_2px_0_0_rgba(0,0,0,1)] transition">
                            ✏️ Ubah Menu
                        </button>
                    @endif
                </div>

                @if($pesanan && $pesanan->detailPesanan->count() > 0)
                    <div class="max-h-[240px] md:max-h-[280px] overflow-y-auto pr-1 space-y-2.5 scrollbar-thin scrollbar-thumb-stone-400">
                        @foreach($pesanan->detailPesanan as $detail)
                            <div class="flex items-center justify-between bg-stone-50 border-2 border-stone-900 p-2.5 rounded-xl shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                                <div class="flex items-center gap-3 min-w-0 pr-2">
                                    <img src="{{ $detail->menu->gambar ? asset('storage/'.$detail->menu->gambar) : 'https://via.placeholder.com/100' }}" 
                                         alt="{{ $detail->menu->nama }}" 
                                         class="w-10 h-10 rounded-full border-2 border-stone-900 object-cover flex-shrink-0">
                                    
                                    <div class="min-w-0">
                                        <p class="font-black text-xs text-stone-900 truncate">{{ $detail->menu->nama }} <span class="text-stone-500">({{ $detail->jumlah }}x)</span></p>
                                        @if($detail->catatan)
                                            <p class="text-[10px] text-amber-800 font-medium italic truncate">💬 {{ $detail->catatan }}</p>
                                        @endif
                                    </div>
                                </div>
                                <span class="font-black text-xs text-stone-900 flex-shrink-0">
                                    Rp {{ number_format($detail->subtotal, 0, ',', '.') }}
                                </span>
                            </div>
                        @endforeach
                    </div>
                @else
                    <p class="text-xs text-stone-400 italic py-8 text-center">Belum ada menu makanan yang dipilih.</p>
                @endif
            </div>

            <div>
                <div class="bg-stone-50 border-2 border-stone-900 p-4 rounded-xl space-y-2.5 shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                    <div class="flex justify-between items-center text-xs font-bold text-stone-600">
                        <span>Total Harga Menu</span>
                        <span class="text-stone-900">Rp {{ number_format($reservasi->pesanan->total_harga, 0, ',', '.') }}</span>
                    </div>
                    
                    <div class="flex justify-between items-center text-xs font-bold text-stone-600 pb-2 border-b border-dashed border-stone-300">
                        <span>PB 10%</span>
                        <span class="text-stone-900">Rp {{ number_format($reservasi->pesanan->pb, 0, ',', '.') }}</span>
                    </div>

                    <div class="flex justify-between items-center font-black text-stone-900 text-sm md:text-base pt-0.5">
                        <span>Total Bayar</span>
                        <span class="text-[#8B5A2B] text-base md:text-lg">Rp {{ number_format($reservasi->total_bayar, 0, ',', '.') }}</span>
                    </div>
                </div>

                @if(!$bisaUbahMenu)
                    <p class="text-[11px] text-red-600 font-bold italic text-center mt-3">
                        ⚠️ Waktu batas prapemesanan habis (H-1 Jam). Pilihan menu telah dikunci.
                    </p>
                @endif
            </div>
        </div>

    </div>

    {{-- POPUP MODAL UPDATE MENU --}}
    @if($bisaUbahMenu)
    <div id="editMenuModal" class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 hidden">
        <div class="bg-white w-full max-w-xl rounded-2xl border-4 border-stone-900 shadow-[8px_8px_0_0_rgba(0,0,0,1)] overflow-hidden flex flex-col max-h-[85vh]">
            <div class="bg-[#4A2311] text-white p-4 flex justify-between items-center border-b-4 border-stone-900">
                <div>
                    <h3 class="text-xl font-black tracking-wide">Sesuaikan Menu Reservasi</h3>
                    <p class="text-xs text-amber-200 font-medium">Minimal pemesanan menu Rp 50.000</p>
                </div>
                <button type="button" onclick="toggleEditMenuModal(false)" class="w-8 h-8 bg-red-500 rounded-full border-2 border-stone-900 flex items-center justify-center font-black hover:bg-red-600">✕</button>
            </div>

            <form action="{{ route('customer.reservasi.update_menu', $reservasi->id) }}" method="POST" class="flex flex-col flex-1 overflow-hidden">
                @csrf
                <div class="p-4 bg-stone-50 border-b-2 border-stone-200">
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-stone-400">🔍</span>
                        <input type="text" id="editMenuSearchInput" onkeyup="filterMenuSearch('editMenuSearchInput', '#editMenuItemsContainer .menu-item-card')" placeholder="Cari menu..." class="w-full border-2 border-stone-900 rounded-xl pl-10 pr-4 py-2.5 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#4A2311]">
                    </div>
                </div>

                <div class="p-4 overflow-y-auto space-y-4 flex-1 bg-stone-100" id="editMenuItemsContainer">
                    @foreach($menus as $menu)
                        {{-- @php
                            $checkedItem = $pesananTerkait ? $pesananTerkait->detailPesanan->where('id_menu', $menu->id)->first() : null;
                            $initialQty = $checkedItem ? $checkedItem->jumlah : 0;
                        @endphp --}}
                        <div class="menu-item-card bg-white border-2 border-stone-900 rounded-xl p-4 shadow-[3px_3px_0_0_rgba(0,0,0,1)] transition-all" data-nama="{{ strtolower($menu->nama) }}" data-harga="{{ $menu->harga }}">
                            <div class="flex items-center justify-between gap-3">
                                <div class="flex items-center gap-3">
                                    <div class="w-16 h-16 bg-stone-200 rounded-lg border-2 border-stone-300 overflow-hidden flex-shrink-0">
                                        @if(isset($menu->gambar) && $menu->gambar)
                                            <img src="{{ asset('storage/' . $menu->gambar) }}" alt="{{ $menu->nama }}" class="w-full h-full object-cover">
                                        @else
                                            <div class="w-full h-full flex items-center justify-center text-stone-400 text-2xl">🍽️</div>
                                        @endif
                                    </div>
                                    <div>
                                        <h4 class="font-black text-stone-900 text-sm menu-item-title">{{ $menu->nama }}</h4>
                                        <p class="text-xs font-bold text-[#8B5A2B]">Rp {{ number_format($menu->harga, 0, ',', '.') }}</p>
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    <div class="flex items-center border border-stone-900 rounded overflow-hidden bg-stone-50">
                                        <button type="button" onclick="updateQty(this, -1)" class="btn-minus {{ $pesanan->detail_pesanan->jumlah > 0 ? '' : 'hidden' }} px-2 py-0.5 bg-red-100 text-red-700 font-black text-xs border-r border-stone-900">-</button>
                                        <input type="number" name="menu_qty[{{ $menu->id }}]" value="{{ $pesanan->detail_pesanan->jumlah }}" min="0" readonly class="qty-input w-8 text-center font-extrabold text-xs bg-transparent focus:outline-none">
                                        <button type="button" onclick="updateQty(this, 1)" class="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-black text-xs border-l border-stone-900">+</button>
                                    </div>
                                </div>
                            </div>

                            <div class="note-dropdown {{ $pesanan->detail_pesanan->jumlah > 0 ? '' : 'hidden' }} mt-3 pt-3 border-t border-dashed border-stone-300">
                                <label class="block text-[11px] font-black text-stone-600 uppercase mb-1">✍️ Catatan Khusus</label>
                                <textarea name="menu_notes[{{ $menu->id }}]" class="w-full text-xs border border-stone-400 rounded-lg p-2 focus:outline-none focus:border-[#4A2311] font-medium"
                                        placeholder="Contoh: tanpa es, extra pedas">{{ $checkedItem->catatan ?? '' }}</textarea>
                            </div>
                        </div>
                    @endforeach
                </div>

                <div class="p-4 bg-white border-t-4 border-stone-900 space-y-3">
                    <div class="flex justify-between items-center text-xs lg:text-sm font-bold">
                        <span class="text-stone-600">Total Pemesanan Menu:</span>
                        <span id="editModalTotalDisplay" class="text-base font-black text-[#4A2311]">Rp 0</span>
                    </div>
                    <div id="editMinOrderWarning" class="text-xs font-bold text-red-600 bg-red-50 p-2 rounded-lg border border-red-200 text-center">
                        ⚠️ Minimal pemesanan menu adalah Rp 50.000.
                    </div>
                    <button type="submit" id="btnConfirmEditMenu" disabled class="w-full py-3 bg-stone-400 text-stone-200 font-black rounded-xl border-2 border-stone-900 cursor-not-allowed uppercase text-xs tracking-wider">
                        Simpan Perubahan Menu
                    </button>
                </div>
            </form>
        </div>
    </div>
    @endif
</div>

<script>
// Fungsi Buka / Tutup Modal Edit Menu
function toggleEditMenuModal(show) {
    const modal = document.getElementById('editMenuModal');
    if (show) {
        modal.classList.remove('hidden');
        calculateEditModalTotal();
    } else {
        modal.classList.add('hidden');
    }
}

// Tambah / Kurangi Qty Menu Edit
function updateQty(button, amount) {
    const card = button.closest('.menu-item-card');
    const input = card.querySelector('.qty-input');
    const btnMinus = card.querySelector('.btn-minus');
    const noteDropdown = card.querySelector('.note-dropdown');
    
    let currentVal = parseInt(input.value) || 0;
    currentVal += amount;
    if (currentVal < 0) currentVal = 0;
    
    input.value = currentVal;

    // Toggle Tombol Minus & Textarea Catatan
    if (currentVal > 0) {
        btnMinus.classList.remove('hidden');
        noteDropdown.classList.remove('hidden');
        card.classList.add('border-amber-700', 'bg-amber-50/20');
    } else {
        btnMinus.classList.add('hidden');
        noteDropdown.classList.add('hidden');
        card.classList.remove('border-amber-700', 'bg-amber-50/20');
    }

    calculateEditModalTotal();
}

// Perhitungan Total Belanja & Validasi Minimal 50 Ribu untuk Modal Edit
function calculateEditModalTotal() {
    const container = document.getElementById('editMenuItemsContainer');
    if (!container) return;

    const cards = container.querySelectorAll('.menu-item-card');
    let total = 0;

    cards.forEach(card => {
        const qty = parseInt(card.querySelector('.qty-input').value) || 0;
        const harga = parseFloat(card.getAttribute('data-harga')) || 0;
        total += (qty * harga);
    });

    const display = document.getElementById('editModalTotalDisplay');
    const warning = document.getElementById('editMinOrderWarning');
    const button = document.getElementById('btnConfirmEditMenu');

    if (display) display.innerText = 'Rp ' + total.toLocaleString('id-ID');

    if (total >= 50000) {
        if (warning) warning.classList.add('hidden');
        if (button) {
            button.disabled = false;
            button.className = "w-full py-3 bg-[#4A2311] text-white font-black rounded-xl border-2 border-stone-900 shadow-[4px_4px_0_0_rgba(0,0,0,1)] hover:bg-[#5c2d17] cursor-pointer transition-all uppercase tracking-wider text-xs";
        }
    } else {
        if (warning) warning.classList.remove('hidden');
        if (button) {
            button.disabled = true;
            button.className = "w-full py-3 bg-stone-400 text-stone-200 font-black rounded-xl border-2 border-stone-900 cursor-not-allowed uppercase tracking-wider text-xs";
        }
    }
}

// Live Search Edit Menu
function filterMenuSearch(inputId, cardSelector) {
    const query = document.getElementById(inputId).value.toLowerCase();
    const cards = document.querySelectorAll(cardSelector);
    
    cards.forEach(card => {
        const name = card.getAttribute('data-nama');
        card.style.display = name.includes(query) ? "block" : "none";
    });
}

// SCRIPT ACCORDION TOGGLE 
function togglePriceDetails() {
    const content = document.getElementById('priceDetailsContent');
    const icon = document.getElementById('chevronIcon');
    
    if (content.classList.contains('hidden')) {
        content.classList.remove('hidden');
        icon.classList.add('rotate-180');
    } else {
        content.classList.add('hidden');
        icon.classList.remove('rotate-180');
    }
}

// Hitung total saat halaman selesai dimuat (jika ada menu bawaan)
document.addEventListener('DOMContentLoaded', () => {
    calculateEditModalTotal();
});
</script>

@include('partials.floating_cs_wa')
@endsection