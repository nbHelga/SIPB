@extends('layouts.landing')

@section('title', 'Pembayaran DP Reservasi - BigBang Eatery')

@section('content')
{{-- Gunakan min-h-screen dan biarkan overflow alami agar saat inspect/layar pendek bisa di-scroll --}}
<div class="pt-24 pb-12 min-h-screen max-w-6xl mx-auto px-4 flex flex-col justify-between box-border">
    
    <!-- GRID CONTAINER -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start flex-1">
        
        <!-- KOLOM KIRI: RINGKASAN RESERVASI & PEMBAYARAN (7 Kolom) -->
        <div class="lg:col-span-7 bg-white rounded-2xl border-4 border-stone-900 shadow-[6px_6px_0_0_rgba(0,0,0,1)] p-5 md:p-6 flex flex-col justify-between">
            
            <div class="space-y-4">
                <div class="border-b-2 border-stone-200 pb-2">
                    <h2 class="text-lg font-black text-stone-900 flex items-center gap-2">
                        📋 Ringkasan Reservasi
                    </h2>
                    <p class="text-xs text-stone-500">Pastikan data jadwal dan pesanan Anda sudah benar.</p>
                </div>

                <!-- Detail Reservasi (Ringkas) -->
                <div class="space-y-2 text-xs lg:text-sm">
                    <div class="flex justify-between items-center py-1 border-b border-stone-100">
                        <span class="text-stone-500 font-medium">Nama Pemesan</span>
                        <span class="font-black text-stone-900">{{ $reservasi->customer->nama ?? 'Guest' }}</span>
                    </div>
                    
                    <div class="flex justify-between items-center py-1 border-b border-stone-100">
                        <span class="text-stone-500 font-medium">Tanggal Kedatangan</span>
                        <span class="font-bold text-stone-900">
                            {{ \Carbon\Carbon::parse($reservasi->tanggal)->translatedFormat('d F Y') }}
                        </span>
                    </div>
                    
                    <div class="flex justify-between items-center py-1 border-b border-stone-100">
                        <span class="text-stone-500 font-medium">Waktu / Sesi</span>
                        <div class="text-right">
                            <span class="font-bold text-stone-900">
                                {{ \Carbon\Carbon::parse($reservasi->jam_mulai)->format('H:i') }} - {{ \Carbon\Carbon::parse($reservasi->jam_selesai)->format('H:i') }} WIB
                            </span>
                            <span class="text-[11px] text-stone-400 block">
                                ({{ \Carbon\Carbon::parse($reservasi->tanggal)->translatedFormat('l') }})
                            </span>
                        </div>
                    </div>
                    
                    <div class="flex justify-between items-center py-1">
                        <span class="text-stone-500 font-medium">Jumlah Tamu</span>
                        <span class="font-bold text-stone-900 bg-stone-100 px-2.5 py-0.5 rounded-full border border-stone-300 text-xs">
                            👥 {{ $reservasi->jml_org }} Orang
                        </span>
                    </div>
                </div>

                <!-- Card DP Info (Kompak) -->
                <div class="bg-amber-50 border-2 border-stone-900 rounded-xl p-3.5 text-center shadow-[3px_3px_0_0_rgba(0,0,0,1)]">
                    <p class="text-[11px] font-black text-stone-600 uppercase tracking-wider mb-0.5">
                        Uang Muka (DP) Wajib Minimal
                    </p>
                    <p class="text-2xl lg:text-3xl font-black text-[#4A2311]">
                        Rp {{ number_format(50000, 0, ',', '.') }}
                    </p>
                    <p class="text-[11px] text-stone-500 mt-1">
                        *Sisa tagihan menu dibayarkan langsung di kasir restoran.
                    </p>
                </div>
            </div>

            <!-- Form Tombol Bayar -->
            {{-- Ubah menjadi POST karena akan memproses pembuatan token transaksi --}}
            <form action="{{ route('customer.reservasi.create_transaction') }}" method="POST" class="space-y-4 mt-6">
                @csrf
                <input type="hidden" name="id_reservasi" value="{{ $reservasi->id }}">
                
                {{-- Input Nominal Fleksibel --}}
                <div class="bg-stone-50 p-4 rounded-xl border-2 border-stone-200">
                    <label class="block text-xs font-bold text-stone-700 mb-2">Nominal Pembayaran (Min. Rp 50.000)</label>
                    <div class="relative">
                        <span class="absolute left-3 top-1/2 -translate-y-1/2 font-black text-stone-600">Rp</span>
                        <input type="number" 
                               name="nominal_dp" 
                               min="50000" 
                               max="{{ $totalBayar ?? 9999999 }}" 
                               value="50000" 
                               class="w-full pl-10 pr-4 py-3 border-2 border-stone-300 rounded-lg text-sm font-black text-[#4A2311] focus:border-[#4A2311] focus:outline-none shadow-[inset_2px_2px_0_0_rgba(0,0,0,0.05)]" 
                               required>
                    </div>
                    <p class="text-[10px] text-stone-500 mt-1.5 leading-tight">
                        *Anda dapat mengubah nominal di atas untuk membayar lebih dari DP minimal, atau melunasi total tagihan.
                    </p>
                </div>

                <button type="submit"
                    class="w-full py-3 bg-[#4A2311] text-white font-black text-sm lg:text-base rounded-xl border-2 border-stone-900 shadow-[4px_4px_0_0_rgba(0,0,0,1)] hover:bg-[#5c2d17] active:shadow-none active:translate-x-0.5 active:translate-y-0.5 transition-all uppercase tracking-wider flex items-center justify-center gap-2">
                    💳 Bayar Sekarang via Midtrans
                </button>
            </form>
        </div>

        <!-- KOLOM KANAN: DETAIL PESANAN MENU (5 Kolom) -->
        <div class="lg:col-span-5 bg-white rounded-2xl border-4 border-stone-900 shadow-[6px_6px_0_0_rgba(0,0,0,1)] p-5 md:p-6 flex flex-col justify-between">
            
            <div>
                <div class="border-b-2 border-stone-200 pb-2 mb-3">
                    <h3 class="text-base font-black text-stone-900 flex items-center gap-2">
                        🍽️ Menu Yang Dipesan
                    </h3>
                </div>

                <!-- LIST ITEM MENU DENGAN SCROLLBAR INTERNAL JIKA TERLALU PANJANG -->
                <div class="max-h-[350px] overflow-y-auto pr-1.5 space-y-2.5 my-3 scrollbar-thin scrollbar-thumb-stone-400 scrollbar-track-stone-100">
                    @forelse($reservasi->pesanan->detailPesanan ?? [] as $item)
                        @php $menu = $item->menu; @endphp
                        <div class="flex items-center gap-2.5 p-2 bg-stone-50 border-2 border-stone-900 rounded-xl shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                            <div class="w-10 h-10 bg-stone-200 rounded-lg flex items-center justify-center flex-shrink-0 border border-stone-300 overflow-hidden">
                                @if($menu->gambar)
                                    <img src="{{ asset('storage/' . $menu->gambar) }}" alt="{{ $menu->nama }}" class="w-full h-full object-cover">
                                @else
                                    <div class="w-full h-full flex items-center justify-center text-stone-400 text-xs">🍽️</div>
                                @endif
                            </div>
                            <div class="flex-1 min-w-0">
                                <h4 class="font-bold text-stone-900 text-xs truncate">{{ $menu->nama ?? 'Menu' }}</h4>
                                <p class="text-[11px] text-stone-500">{{ $item->jumlah }}x @ Rp {{ number_format($menu->harga, 0, ',', '.') }}</p>
                                @if($item->catatan)
                                    <p class="text-[10px] text-stone-400 italic truncate">"{{ $item->catatan }}"</p>
                                @endif
                            </div>
                            <div class="font-black text-stone-900 text-xs flex-shrink-0">
                                Rp {{ number_format($item->jumlah * $menu->harga, 0, ',', '.') }}
                            </div>
                        </div>
                    @empty
                        <p class="text-xs text-stone-400 italic text-center py-6">Tidak ada pesanan menu tambahan.</p>
                    @endforelse
                </div>
            </div>

            <!-- RINGKASAN SUB TOTAL -->
            <div class="pt-3 border-t-2 border-dashed border-stone-300 space-y-1 text-xs mt-4">
                <div class="flex justify-between text-stone-600">
                    <span>Total Harga Menu</span>
                    <span class="font-bold">Rp {{ number_format($totalHargaMenu ?? 0, 0, ',', '.') }}</span>
                </div>
                <div class="flex justify-between text-stone-600">
                    <span>PB1 (10%)</span>
                    <span class="font-bold">Rp {{ number_format($pb ?? 0, 0, ',', '.') }}</span>
                </div>
                <div class="flex justify-between text-stone-900 font-black text-sm pt-1.5 border-t border-stone-200">
                    <span>Total Estimasi</span>
                    <span class="text-[#4A2311]">Rp {{ number_format($totalBayar ?? 0, 0, ',', '.') }}</span>
                </div>
            </div>
        </div>

    </div>
</div>

@include('partials.floating_cs_wa')
@endsection