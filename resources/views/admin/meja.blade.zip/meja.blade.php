{{-- @extends('layouts.admin')

@section('title', 'Denah & Kelola Meja - SIPB')

@section('content')
<!-- Tambahkan state isPlotting: false pada wrapper Alpine.js -->
<div x-data="{ currentTab: '{{ $lantaiList->first() ?? 1 }}', isPlotting: false }" class="w-full">
    
    <!-- HEADER & ACTION BAR -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b-4 border-stone-950 pb-4 mb-6">
        <div>
            <h1 class="text-2xl font-black">🗺️ Alokasi Meja Reservasi</h1>
            <p class="text-xs text-stone-500 mt-1">* Klik nomor meja untuk melihat detail atau aktifkan mode plotting.</p>
        </div>

        <!-- LEGEND LAMPU STATUS -->
        <div class="mt-8 flex items-center gap-3 text-sm">
            <div class="flex items-center gap-2">
                <span class="w-3 h-3 rounded-full bg-green-500"></span>
                <span class="text-stone-600">Available</span>
            </div>
            <div class="flex items-center gap-2">
                <span class="w-3 h-3 rounded-full bg-red-500"></span>
                <span class="text-stone-600">Occupied</span>
            </div>
            <div class="flex items-center gap-2">
                <span class="w-3 h-3 rounded-full bg-yellow-500"></span>
                <span class="text-stone-600">Reserved</span>
            </div>
        </div>
    </div>

    <!-- NAVBAR TAB LANTAI & PLOTTING CONTROL -->
    <div class="flex flex-wrap items-center justify-between gap-3 bg-stone-200 p-2 rounded-xl border-2 border-stone-900 shadow-[3px_3px_0_0_rgba(0,0,0,1)] mb-6">
        
        <!-- TAB LANTAI (SISI KIRI) -->
        <div class="flex items-center gap-1.5 flex-wrap">
            @foreach($lantaiList as $l)
                <button type="button" 
                        @click="currentTab = '{{ $l }}'"
                        :class="currentTab === '{{ $l }}' ? 'bg-[#4A2311] text-white' : 'text-stone-700 hover:bg-stone-300'"
                        class="px-4 py-2 text-sm font-black rounded-lg transition-all duration-150">
                    Lantai {{ $l }}
                </button>
            @endforeach
        </div>
        

        <!-- PLOTTING CONTROLS -->
        <div class="flex items-center gap-3">
            <button type="button" id="togglePlottingBtn" onclick="togglePlottingPanel()" class="px-3 py-2 bg-[#4A2311] text-white text-sm font-bold rounded-lg border-2 border-stone-900 hover:bg-stone-800">
                📍 Alokasi
            </button>

            <div id="plottingControls" class="hidden items-center gap-3"> 
                <!-- dropdown akan diisi dari $reservasiConfirmed --> 
                <div class="relative"> 
                    <select id="plottingReservationSelect" onchange="onPlottingReservationChange(this.value)" class="rounded-lg border-2 border-stone-900 px-3 py-2 text-sm"> 
                        <option value="">
                            Pilih Reservasi (Sudah Dikonfirmasi)
                        </option> 
                        @foreach($reservasiConfirmed as $r) 
                            <option value="{{ $r->id }}" data-tanggal="{{ $r->tanggal }}"> 
                                {{ $r->customer->nama ?? 'Guest' }} - {{ \Carbon\Carbon::parse($r->tanggal)->format('d M Y') }} 
                            </option> 
                        @endforeach 
                    </select> 
                    <!-- Tombol Simpan tetap tampil di sebelah dropdown -->
                    <button type="button" onclick="savePlotting()" class="px-3 py-2 bg-emerald-600 text-white text-sm font-bold rounded-lg border-2 border-stone-900 hover:bg-emerald-700">
                        💾 Simpan
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- WRAPPER DENAH LANTAI -->
    @foreach($denahMeja as $lantai => $daftarMeja)
        <div x-show="currentTab === '{{ $lantai }}'" style="display: none;" x-transition class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
            
            @foreach($daftarMeja as $row)
                <div class="bg-white border-4 border-stone-900 rounded-xl p-4 shadow-[4px_4px_0_0_rgba(0,0,0,1)] flex items-center justify-between relative min-h-[90px] meja-card transition-all"
                    data-meja-id="{{ $row->id }}" data-meja-nomor="{{ $row->nomor_meja }}" onclick="onMejaCardClick(event, {{ $row->id }})" role="button" aria-pressed="false">

                    <div class="flex items-center gap-3">
                        @php
                            // 1. Dapatkan tanggal hari ini (Format YYYY-MM-DD)
                            $today = \Carbon\Carbon::now()->toDateString();

                            // 2. Cek apakah ada reservasi AKTIF khusus untuk HARI INI pada meja ini
                            $isReservedToday = $row->detailReservasi ? $row->detailReservasi->contains(function ($dr) use ($today) {
                                $reservasi = $dr->reservasi;
                                return $reservasi 
                                    && $reservasi->tanggal === $today 
                                    && in_array(strtolower($reservasi->status), ['confirmed', 'approved', 'paid']);
                            }) : false;

                            // 3. Tentukan status tampilan real-time
                            // Prioritas 1: Occupied (sedang dipakai self-order/makan di tempat)
                            // Prioritas 2: Reserved (ada booking khusus hari ini)
                            // Prioritas 3: Status bawaan meja (Available)
                            if ($row->status === 'occupied') {
                                $displayStatus = 'occupied';
                            } elseif ($isReservedToday) {
                                $displayStatus = 'reserved';
                            } else {
                                $displayStatus = 'available';
                            }

                            $lampColors = [
                                'available' => 'bg-green-500',
                                'occupied'  => 'bg-red-500',
                                'reserved'  => 'bg-yellow-500',
                            ];

                            $lampClass = $lampColors[$displayStatus] ?? 'bg-stone-400';
                        @endphp
                        <span class="w-4 h-4 rounded-full {{ $lampClass }} mr-3 flex-shrink-0"></span>

                        <div class="flex flex-col">
                            <span class="text-xl font-black text-stone-800">#{{ $row->nomor_meja }}</span>
                            <!-- optional small label -->
                            <span class="text-xs text-stone-500">Lantai {{ $row->lantai }}</span>
                        </div>
                    </div>

                </div>
            @endforeach
        </div>
    @endforeach

    <!-- FORM HIDDEN UNTUK SUBMIT PLOTTING (DIPINDAHKAN KELUAR LOOP) -->
    <form id="plottingForm" action="" method="POST" class="hidden">
        @csrf
    </form>

    <!-- WRAPPER DETAIL PLOTTING / KETERSEDIAAN -->
    <div id="plottingDetailWrapper" class="mt-6">
        <div id="plottingDetailCard" class="bg-white rounded-xl border-4 border-stone-900 p-6 shadow-[4px_4px_0_0_rgba(0,0,0,1)]">
            <h2 class="font-black text-xl mb-3">📋 Info Reservasi / Ketersediaan Meja</h2>

            <div id="plottingDetailContent" class="space-y-3"> 
                <p class="text-sm text-stone-500">
                    Pilih mode Plotting lalu pilih reservasi untuk melihat daftar meja yang sudah diplot pada tanggal yang sama.
                </p> 
            </div>
        </div>
    </div>

</div>

<script>
    // ==========================================
    // 1. DATA INITIALIZATION FROM BACKEND
    // ==========================================
    const RESERVASI_CONFIRMED = @json($reservasiConfirmed);
    const ALL_MEJA = @json($allMeja);

    // ==========================================
    // 2. GLOBAL PLOTTING STATE
    // ==========================================
    let plottingActive = false;
    let plottingReservationId = null;
    const plottingSelectedTables = new Set(); // Menyimpan ID Meja (String)

    // ==========================================
    // 3. CORE PLOTTING FUNCTIONS
    // ==========================================

    /**
     * Toggle panel plotting saat tombol 📍 Plotting ditekan
     */
    function togglePlottingPanel() {
        plottingActive = !plottingActive;
        const controls = document.getElementById('plottingControls');
        if (!controls) return;

        if (plottingActive) {
            controls.classList.remove('hidden');
            document.querySelectorAll('.meja-card').forEach(c => c.classList.add('cursor-pointer'));
        } else {
            controls.classList.add('hidden');
            
            // Clear selections & UI highlight saat plotting dimatikan
            plottingReservationId = null;
            plottingSelectedTables.clear();
            clearAllHighlights();

            document.getElementById('plottingReservationSelect').value = '';
            renderPlottingDetail();
            document.querySelectorAll('.meja-card').forEach(c => c.classList.remove('cursor-pointer'));
        }
    }

    /**
     * Callback saat kartu meja diklik
     */
    function onMejaCardClick(event, mejaId) {
        if (!plottingActive) return;

        // Toggle seleksi meja
        const id = String(mejaId);
        if (plottingSelectedTables.has(id)) {
            plottingSelectedTables.delete(id);
        } else {
            plottingSelectedTables.add(id);
        }

        updateHighlights();
    }

    /**
     * Hapus semua kelas highlight/seleksi dari semua kartu meja
     */
    function clearAllHighlights() {
        document.querySelectorAll('.meja-card').forEach(card => {
            card.classList.remove(
                'ring-4', 
                'ring-yellow-300', 
                'bg-yellow-50', 
                'shadow-[0_0_20px_rgba(250,204,21,0.15)]'
            );
            card.setAttribute('aria-pressed', 'false');
        });
    }

    /**
     * Perbarui tampilan highlight (kuning) pada kartu meja yang terpilih
     */
    function updateHighlights() {
        clearAllHighlights();
        
        plottingSelectedTables.forEach(id => {
            const card = document.querySelector(`.meja-card[data-meja-id='${id}']`);
            if (card) {
                card.classList.add(
                    'ring-4', 
                    'ring-yellow-300', 
                    'bg-yellow-50', 
                    'shadow-[0_0_20px_rgba(250,204,21,0.15)]'
                );
                card.setAttribute('aria-pressed', 'true');
            }
        });
    }

    /**
     * Callback saat reservasi dipilih dari dropdown
     */
    function onPlottingReservationChange(value) {
        plottingReservationId = value || null;
        plottingSelectedTables.clear();
        clearAllHighlights();

        if (!plottingReservationId) {
            renderPlottingDetail();
            return;
        }

        // Cari objek reservasi yang dipilih
        const selected = RESERVASI_CONFIRMED.find(r => String(r.id) === String(plottingReservationId));
        if (!selected) {
            renderPlottingDetail();
            return;
        }

        // 1. Highlight meja yang milik reservasi ini (jika ada)
        if (Array.isArray(selected.detail_reservasi)) {
            selected.detail_reservasi.forEach(dr => {
                const id_meja = dr.id_meja ?? (dr.meja?.id ?? null);
                if (id_meja) {
                    plottingSelectedTables.add(String(id_meja));
                }
            });
        }

        // 2. Render detail reservasi pada tanggal yang sama
        renderPlottingDetail();

        // 3. Update highlight di UI
        updateHighlights();
    }

    /**
     * Render daftar reservasi pada tanggal yang sama dengan reservasi terpilih
     */
    function renderPlottingDetail() {
        const content = document.getElementById('plottingDetailContent');
        if (!content) return;

        content.innerHTML = '';

        if (!plottingReservationId) {
            content.innerHTML = `
                <p class="text-sm text-stone-500">
                    Pilih reservasi untuk melihat daftar meja yang sudah diplot pada tanggal yang sama.
                </p>`;
            return;
        }

        const selected = RESERVASI_CONFIRMED.find(r => String(r.id) === String(plottingReservationId));
        if (!selected) {
            content.innerHTML = `<p class="text-sm text-stone-500">Reservasi tidak ditemukan.</p>`;
            return;
        }

        const date = selected.tanggal;
        const sameDateReservations = RESERVASI_CONFIRMED.filter(r => r.tanggal === date);

        if (sameDateReservations.length === 0) {
            content.innerHTML = `<p class="text-sm text-stone-500">Tidak ada reservasi lain pada tanggal ini.</p>`;
            return;
        }

        // Build HTML output
        let html = '';
        sameDateReservations.forEach(r => {
            const guest = r.customer?.nama ?? 'Guest';
            const isSelected = String(r.id) === String(plottingReservationId);

            html += `
                <div class="p-4 mb-3 rounded-lg border border-stone-200 bg-white">
                    <div class="flex justify-between items-start mb-2">
                        <div>
                            <div class="font-bold">${guest}</div>
                            <div class="text-xs text-stone-500">
                                ${r.tanggal} • ${r.jam_mulai} - ${r.jam_selesai}
                            </div>
                        </div>
                        <div class="text-sm font-bold ${isSelected ? 'text-[#4A2311]' : 'text-stone-600'}">
                            ${r.pesanan.status}
                        </div>
                    </div>
            `;

            // List meja yang sudah diplot untuk reservasi ini
            const mejaList = (r.detail_reservasi || [])
                .map(dr => dr.meja?.nomor_meja ?? dr.id_meja ?? null)
                .filter(Boolean);

            if (mejaList.length > 0) {
                html += `<div class="flex gap-2 flex-wrap">`;
                mejaList.forEach(m => {
                    html += `
                        <span class="px-2 py-1 text-xs font-black rounded border border-stone-900 bg-stone-50">
                            #${m}
                        </span>`;
                });
                html += `</div>`;
            } else {
                html += `<div class="text-xs italic text-stone-500">Belum ada meja diplot untuk reservasi ini.</div>`;
            }

            html += `</div>`; // End Card
        });

        content.innerHTML = html;
    }

    /**
     * Submit data plotting ke backend via form POST dinamis
     */
    function savePlotting() {
        if (!plottingReservationId) {
            alert('Pilih reservasi dulu.');
            return;
        }

        // Buat form dinamis
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/admin/meja/${plottingReservationId}/assign-meja`;
        form.classList.add('hidden');

        // Ambil CSRF Token
        const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '{{ csrf_token() }}';
        
        const inputToken = document.createElement('input');
        inputToken.type = 'hidden';
        inputToken.name = '_token';
        inputToken.value = token;
        form.appendChild(inputToken);

        // Tambahkan meja terpilih ke form input
        plottingSelectedTables.forEach(id => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'meja_dipilih[]';
            input.value = id;
            form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
    }

    // ==========================================
    // 4. INITIALIZATION ON DOM LOADED
    // ==========================================
    document.addEventListener('DOMContentLoaded', () => {
        // Logika inisialisasi tambahan jika diperlukan
    });
</script>

<!-- DRAWER -->
{{-- <div id="mejaDrawer" class="fixed inset-y-0 right-0 z-50 w-full max-w-lg bg-white border-l-4 border-[#4A2311] shadow-[-8px_0_0_0_rgba(0,0,0,0.3)] transform translate-x-full transition-transform duration-300 overflow-y-auto">
    <div id="mejaDrawerContent" class="p-6"></div>
</div> --}}
{{-- 
<script>
// (Fungsi JS openMejaDrawer & closeMejaDrawer tetap sama persis seperti kode Anda sebelumnya)
function openMejaDrawer(mejaData, reservasiData = null) {
    const drawer = document.getElementById('mejaDrawer');
    const content = document.getElementById('mejaDrawerContent');
    
    if (mejaData === null) {
        // FORM TAMBAH MEJA BARU
        content.innerHTML = `
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-black">➕ Tambah Meja Baru</h2>
                <button onclick="closeMejaDrawer()" class="w-8 h-8 bg-red-500 text-white rounded-full border-2 border-stone-900 font-bold hover:bg-red-600">✕</button>
            </div>
            <form action="{{ route('admin.meja.store') ?? '/admin/meja' }}" method="POST" class="space-y-4">
                @csrf
                <div><label class="block font-bold text-sm mb-1">Nomor Meja</label><input type="text" name="nomor_meja" required class="w-full border-2 border-stone-300 rounded-lg px-4 py-3"></div>
                <div><label class="block font-bold text-sm mb-1">Lantai</label><input type="number" name="lantai" required class="w-full border-2 border-stone-300 rounded-lg px-4 py-3"></div>
                <button type="submit" class="w-full py-3 bg-[#4A2311] text-white font-bold rounded-lg border-2 border-stone-900 shadow-[4px_4px_0_0_rgba(0,0,0,0.3)]">💾 Simpan Meja</button>
            </form>
        `;
    } else {
        // MODE EDIT & DETAIL RESERVASI
        let sectionReservasi = '';

        if (reservasiData) {
            let listMenu = '<li>Tidak ada detail menu di-load</li>';
            if (reservasiData.menus && reservasiData.menus.length > 0) {
                listMenu = reservasiData.menus.map(m => `<li>${m.nama_menu || 'Menu'} (x${m.pivot?.quantity || 1})</li>`).join('');
            }

            const nama = reservasiData.nama_pelanggan || reservasiData.nama_customer || 'Pelanggan';
            const tamu = reservasiData.jumlah_tamu || reservasiData.jumlah_orang || '-';

            sectionReservasi = `
                <div class="border-4 border-stone-900 bg-yellow-50 p-4 rounded-xl mb-6 shadow-[4px_4px_0_0_rgba(0,0,0,1)]">
                    <h3 class="font-black text-xs text-yellow-900 uppercase tracking-widest border-b-2 border-stone-900 pb-1 mb-2">⚠️ DATA RESERVASI AKTIF</h3>
                    <p class="text-xl font-black text-stone-900">${nama}</p>
                    <p class="text-sm font-bold mt-1 text-stone-800">👥 Kapasitas: ${tamu} Orang</p>
                    
                    <div class="grid grid-cols-2 gap-2 mt-4">
                        <form action="/admin/reservasi/${reservasiData.id}/checkin" method="POST" class="inline">
                            @csrf
                            <button type="submit" onclick="return confirm('Check-in customer ini?')" class="w-full bg-green-600 hover:bg-green-700 text-white font-black text-xs py-2.5 rounded border-2 border-stone-900 shadow-[2px_2px_0_0_rgba(0,0,0,1)]">
                                🚀 Customer Datang
                            </button>
                        </form>
                        <a href="/admin/reservasi/${reservasiData.id}/edit" class="bg-stone-800 hover:bg-stone-900 text-white font-black text-xs py-2.5 text-center rounded border-2 border-stone-900 shadow-[2px_2px_0_0_rgba(0,0,0,1)] flex items-center justify-center">
                            ✏️ Detail
                        </a>
                    </div>
                </div>
            `;
        } else {
            sectionReservasi = `
                <div class="bg-green-50 border-2 border-green-300 p-3 rounded-lg text-green-800 text-xs font-bold mb-6">
                    ✅ Tidak ada reservasi aktif untuk meja ini hari ini.
                </div>
            `;
        }

        // Render Drawer Edit Meja
        content.innerHTML = `
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-black">⚙️ Kelola Meja #${mejaData.nomor_meja}</h2>
                <button onclick="closeMejaDrawer()" class="w-8 h-8 bg-red-500 text-white rounded-full border-2 border-stone-900 font-bold hover:bg-red-600">✕</button>
            </div>

            ${sectionReservasi}

            <div class="border-t-4 border-dashed border-stone-200 pt-4">
                <h3 class="font-black text-sm text-stone-800 mb-3">✏️ Edit Struktur Meja</h3>
                <form action="/admin/meja/${mejaData.id}/update" method="POST" class="space-y-4">
                    @csrf
                    @method('PUT')
                    <div>
                        <label class="block font-bold text-sm mb-1">Nomor Meja</label>
                        <input type="text" name="nomor_meja" value="${mejaData.nomor_meja}" class="w-full border-2 border-stone-300 rounded-lg px-4 py-2 font-bold">
                    </div>
                    <div>
                        <label class="block font-bold text-sm mb-1">Posisi Lantai</label>
                        <input type="number" name="lantai" required value="${mejaData.lantai}" class="w-full border-2 border-stone-300 rounded-lg px-4 py-2 font-bold">
                    </div>
                    <div>
                        <label class="block font-bold text-sm mb-1">Status Fisik Meja</label>
                        <select name="status" class="w-full border-2 border-stone-300 rounded-lg px-4 py-2 font-black">
                            <option value="available" ${mejaData.status === 'available' ? 'selected' : ''}>🟢 Available (Kosong)</option>
                            <option value="occupied" ${mejaData.status === 'occupied' ? 'selected' : ''}>🔴 Occupied (Terisi)</option>
                            <option value="reserved" ${mejaData.status === 'reserved' ? 'selected' : ''}>🟡 Reserved (Booking)</option>
                        </select>
                    </div>
                    <button type="submit" class="w-full py-3 bg-[#4A2311] text-white font-bold rounded-lg border-2 border-stone-900 shadow-[4px_4px_0_0_rgba(0,0,0,0.3)]">
                        💾 Perbarui Data Meja
                    </button>
                </form>
            </div>
        `;
    }
    
    drawer.classList.remove('translate-x-full');
}

function closeMejaDrawer() {
    document.getElementById('mejaDrawer').classList.add('translate-x-full');
}
</script> --}}

{{-- <script>
    // Data dari server (serialisasi PHP->JS)
    const RESERVASI_CONFIRMED = @json($reservasiConfirmed);
    const ALL_MEJA = @json($allMeja);

    let plottingActive = false;
    let plottingReservationId = null;
    const plottingSelectedTables = new Set();

    function togglePlottingPanel() {
        plottingActive = !plottingActive;
        document.getElementById('plottingControls').classList.toggle('hidden', !plottingActive);

        // toggle visibility of checkboxes on each card
        document.querySelectorAll('.meja-card-checkbox').forEach(btn => {
            if (plottingActive) btn.classList.remove('hidden'); else btn.classList.add('hidden');
        });

        // also add pointer cursor to cards
        document.querySelectorAll('.meja-card').forEach(card => {
            if(plottingActive) card.classList.add('cursor-pointer'); else card.classList.remove('cursor-pointer');
        });

        // Clear selection when turning off
        if (!plottingActive) {
            plottingReservationId = null;
            plottingSelectedTables.clear();
            clearAllCheckedUI();
            document.getElementById('plottingReservationSelect').value = '';
            renderPlottingDetail();
        }
    }

    function onPlottingReservationChange(value) {
        plottingReservationId = value || null;
        plottingSelectedTables.clear();
        clearAllCheckedUI();

        if (plottingReservationId) {
            // find reservation object from RESERVASI_CONFIRMED
            const res = RESERVASI_CONFIRMED.find(r => r.id == plottingReservationId);
            if (res && res.detail_reservasi) {
                // detail_reservasi may be collection of objects -> use id_meja field
                res.detail_reservasi.forEach(dr => {
                    const id_meja = dr.id_meja ?? dr.id_meja; // accomodate naming
                    plottingSelectedTables.add(String(id_meja));
                });
            }
        }

        // Update UI to check those tables
        updateCheckedUIFromSet();
        renderPlottingDetail();
    }

    // Card click toggles meja selection
    function onMejaCardClick(mejaId) {
        if (!plottingActive) return;
        toggleMejaSelection(String(mejaId));
    }

    function toggleMejaSelect(event, mejaId) {
        // event from checkbox button -> prevent bubbling to card click
        event.stopPropagation();
        if (!plottingActive) return;
        toggleMejaSelection(String(mejaId));
    }

    function toggleMejaSelection(mejaId) {
        if (plottingSelectedTables.has(mejaId)) {
            plottingSelectedTables.delete(mejaId);
        } else {
            plottingSelectedTables.add(mejaId);
        }
        updateCheckedUIFromSet();
    }

    function updateCheckedUIFromSet() {
        document.querySelectorAll('.meja-card').forEach(card => {
            const id = String(card.dataset.mejaId);
            const checkboxBtn = card.querySelector('.meja-card-checkbox');
            const mark = checkboxBtn?.querySelector('.checkbox-mark');
            if (plottingSelectedTables.has(id)) {
                checkboxBtn.classList.add('bg-[#4A2311]', 'text-white');
                if (mark) mark.classList.remove('hidden');
            } else {
                checkboxBtn.classList.remove('bg-[#4A2311]', 'text-white');
                if (mark) mark.classList.add('hidden');
            }
        });
    }

    function clearAllCheckedUI() {
        document.querySelectorAll('.meja-card-checkbox').forEach(btn => {
            btn.classList.remove('bg-[#4A2311]', 'text-white');
            const mark = btn.querySelector('.checkbox-mark');
            if (mark) mark.classList.add('hidden');
        });
    }

    function savePlotting() {
        if (!plottingReservationId) {
            alert('Pilih reservasi terlebih dahulu');
            return;
        }
        if (plottingSelectedTables.size === 0) {
            if (!confirm('Belum memilih meja. Lanjutkan untuk menyimpan tanpa meja?')) return;
        }

        // Create form and submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/admin/meja/${plottingReservationId}/assign-meja`;
        form.classList.add('hidden');

        // CSRF token (Laravel blade has meta tag or you can echo csrf here)
        const token = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '{{ csrf_token() }}';
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = '_token';
        csrfInput.value = token;
        form.appendChild(csrfInput);

        plottingSelectedTables.forEach(id => {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'meja_dipilih[]';
            input.value = id;
            form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
    }

    function renderPlottingDetail() {
        const content = document.getElementById('plottingDetailContent');
        content.innerHTML = '';

        if (!plottingReservationId) {
            // show availability info for today: collect reservations that have tanggal === today (or from selected dropdown option default)
            content.innerHTML = `<p class="text-sm text-stone-500">Pilih reservasi untuk melihat daftar meja yang sudah dipesan pada tanggal yang sama.</p>`;
            return;
        }

        const selectedRes = RESERVASI_CONFIRMED.find(r => r.id == plottingReservationId);
        if (!selectedRes) {
            content.innerHTML = `<p class="text-sm text-stone-500">Reservasi tidak ditemukan.</p>`;
            return;
        }

        // find all reservations on the same date
        const date = selectedRes.tanggal;
        const sameDateReservations = RESERVASI_CONFIRMED.filter(r => r.tanggal === date);

        if (sameDateReservations.length === 0) {
            content.innerHTML = `<p class="text-sm text-stone-500">Tidak ada reservasi lain pada tanggal ini.</p>`;
            return;
        }

        let html = `<div class="space-y-3">`;
        sameDateReservations.forEach(r => {
            const guest = r.customer?.nama ?? 'Guest';
            html += `<div class="p-3 border rounded-lg bg-stone-50">`;
            html += `<div class="flex justify-between items-center mb-2"><div><strong>${guest}</strong><div class="text-xs text-stone-500">${r.tanggal} • ${r.jam_mulai} - ${r.jam_selesai}</div></div></div>`;

            // list meja for this reservation
            const mejaList = (r.detail_reservasi || []).map(dr => dr.meja?.nomor_meja ?? dr.id_meja).filter(Boolean);
            if (mejaList.length > 0) {
                html += `<div class="flex gap-2 flex-wrap">`;
                mejaList.forEach(m => {
                    html += `<span class="px-2 py-1 text-xs font-black rounded border border-stone-900 bg-white">#${m}</span>`;
                });
                html += `</div>`;
            } else {
                html += `<div class="text-xs italic text-stone-500">Belum ada meja diplot</div>`;
            }
            html += `</div>`;
        });
        html += `</div>`;

        content.innerHTML = html;
    }

    // Initialize: hide checkboxes at load
    document.addEventListener('DOMContentLoaded', () => {
        document.querySelectorAll('.meja-card-checkbox').forEach(btn => btn.classList.add('hidden'));
    });
</script> --}}


{{-- @endsection --}} 