<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use App\Models\Menu;
use App\Models\Pesanan;
use App\Models\DetailPesanan;
use App\Models\Meja;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Session;
use Midtrans\Snap;
use Midtrans\Config as MidtransConfig;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Contracts\Encryption\DecryptException;
use App\Models\Pembayaran;
use Illuminate\Support\Facades\DB;
use Midtrans\Transaction;
use Illuminate\Support\Facades\Log;


class SelfOrderController extends Controller
{
    // SELF ORDER — support QR scan via ?nomor_meja=XXX
    private function createSelfOrderCode(): string
    {
        do {
            // MMDD (4 digit tanggal) - HHMM (4 digit jam menit) - RAND (4 digit acak)
            $code = now()->format('md-Hi') . '-' . random_int(1000, 9999);
        } while (Pesanan::where('kode_pesanan', 'SOD-' . $code)->exists());

        return $code;
    }

    private function selfOrderParams(): array
    {
        return [
            'kode' => session('selforder_code'),
            'tableNumber' => session('nomor_meja'),
        ];
    }

    private function redirectToSelfOrder(string $message = '')
    {
        $response = redirect()->route('customer.selforder', $this->selfOrderParams());

        return $message !== '' ? $response->with('error', $message) : $response;
    }

    public function selfOrder(Request $request)
    {
        // 1. Ambil nomor meja dari URL atau Session
        $nomorMeja = $request->query('tableNumber')
            ?? $request->query('nomor_meja')
            ?? session('nomor_meja');

        $tables = Meja::where('nomor_meja', $nomorMeja)->first();

        if (!$tables) {
            return redirect()->route('home')->with('error', 'Meja tidak ditemukan.');
        }

        // 2. Jika berpindah meja fisik, bersihkan keranjang dan kode lama
        if (session('id_meja') && (string) session('id_meja') !== (string) $tables->id) {
            session()->forget(['cart', 'cart_count', 'selforder_code']);
        }

        $codeFromUrl = $request->query('kode');

        // Cek apakah kode (baik dari URL maupun Session) sudah pernah dipakai di database
        $isCodeUsedInDb = function ($c) {
            return is_string($c) && Pesanan::where('kode_pesanan', 'SOD-' . $c)->exists();
        };

        // 3. Validasi format kode dari URL (misal: 1011-1730-1234)
        $isValidUrlCode = is_string($codeFromUrl)
            && preg_match('/^\d{4}-\d{4}-\d{4}$/', $codeFromUrl)
            && !$isCodeUsedInDb($codeFromUrl);

        if ($isValidUrlCode) {
            // Jika kode dari URL valid dan belum dipakai di DB, gunakan kode tersebut
            session(['selforder_code' => $codeFromUrl]);
        } else {
            // Jika kode di session tidak ada ATAU sudah pernah dipakai transaksi di DB, generate KODE BARU
            $currentSessionCode = session('selforder_code');
            if (!$currentSessionCode || $isCodeUsedInDb($currentSessionCode)) {
                session(['selforder_code' => $this->createSelfOrderCode()]);
            }
        }

        // 4. Simpan info meja ke session
        session([
            'nomor_meja' => $tables->nomor_meja,
            'id_meja' => $tables->id,
        ]);

        // 5. Pastikan URL selalu rapi dan berisi kode sesi terbaru serta tableNumber
        if (
            $request->query('kode') !== session('selforder_code') ||
            $request->query('tableNumber') !== $tables->nomor_meja
        ) {
            return redirect()->route('customer.selforder', $this->selfOrderParams());
        }

        // 6. Ambil data menu & kategori
        $menus = Menu::where('status', 'open')
                ->orderByDesc('is_bestseller')
                ->orderBy('kategori')
                ->orderBy('nama', 'asc')
                ->get();
        $categories = Menu::where('status', 'open')
            ->distinct()
            ->orderBy('kategori')
            ->pluck('kategori');

        return view('customer.selforder', compact('menus', 'categories', 'tables'));
    }

    public function menuJson($id)
    {
        $menu = Menu::findOrFail($id);
        return response()->json($menu);
    }

    // Halaman detail menu (halaman terpisah)
    public function menuDetail(Request $request, $id)
    {
        $menu = Menu::findOrFail($id);
        $menus = Menu::where('status', 'open')->get();
        $categories = Menu::where('status', 'open')->distinct()->orderBy('kategori')->pluck('kategori');
        // $nomorMeja = $request->query('nomor_meja')
        $nomorMeja = $request->query('tableNumber')
            ?? $request->query('nomor_meja')
            ?? session('nomor_meja');

        if ($nomorMeja) {
            session(['nomor_meja' => $nomorMeja]);
        }

        $tables = Meja::where('nomor_meja', $nomorMeja)->first();
        return view('customer.menu_detail', compact('menu', 'menus', 'categories', 'tables'));
    }

    // CART
    public function cart(Request $request)
    {
        $nomorMeja = $request->query('tableNumber')
            ?? $request->query('nomor_meja')
            ?? session('nomor_meja');

        $tables = Meja::where('nomor_meja', $nomorMeja)->first();

        if (!$tables || !$nomorMeja || !session('selforder_code')) {
            return redirect()->route('home')->with('error', 'Silakan scan QR meja terlebih dahulu.');
        }

        session([
            'nomor_meja' => $tables->nomor_meja,
            'id_meja' => $tables->id,
        ]);

        if ($request->query('kode') !== session('selforder_code') || $request->query('tableNumber') !== $tables->nomor_meja) {
            return redirect()->route('customer.cart', $this->selfOrderParams());
        }

        $cartItems = session('cart', []);
        // $selectedItems = array_keys($cartItems);
        $totalHarga = 0;
        foreach ($cartItems as $item) {
            $totalHarga += $item['subtotal'];
        }
        return view('customer.cart', compact('cartItems', 'totalHarga', 'tables'));
    }

    public function cartAdd(Request $request)
    {
        $request->validate([
            'id_menu' => 'required|exists:menu,id',
            'jumlah' => 'required|integer|min:1',
            'catatan' => 'nullable|string|max:255',
        ]);

        $menu = Menu::findOrFail($request->id_menu);
        $cart = session('cart', []);

        if (!session('id_meja') || !session('selforder_code')) {
            return redirect()->route('home')->with('error', 'Silakan scan QR meja terlebih dahulu.');
        }
        
        // FIX: Ambil dari $request->catatan, bukan $request->menu->catatan
        $catatan = trim($request->input('catatan', ''));

        // Hash key agar item menu sama dengan catatan beda tersimpan terpisah
        $key = 'menu_' . $menu->id . ($catatan !== '' ? '_' . md5($catatan) : '');

        if (isset($cart[$key])) {
            $cart[$key]['jumlah'] += $request->jumlah;
            $cart[$key]['subtotal'] = $cart[$key]['jumlah'] * $menu->harga;
            if (!empty($catatan)) {
                $cart[$key]['catatan'] = $catatan;
            }
        } else {
            $cart[$key] = [
                'id_menu'  => $menu->id,
                'menu'     => $menu,
                'jumlah'   => $request->jumlah,
                'subtotal' => $request->jumlah * $menu->harga,
                'catatan'  => $catatan, // Disimpan ke session cart
            ];
        }

        session(['cart' => $cart]);
        session(['cart_count' => count($cart)]);

        // $redirect = $request->input('redirect', route('customer.selforder', ['nomor_meja' => session('nomor_meja')]));
        // return redirect($redirect)->with('success', 'Menu berhasil ditambahkan ke keranjang!');
        return redirect()->route('customer.selforder', $this->selfOrderParams())->with('success', 'Menu berhasil ditambahkan ke keranjang!');
    }

    public function cartUpdate(Request $request)
    {
        $cart = session()->get('cart', []);
        $key = $request->key;

        if (isset($cart[$key])) {
            if ($request->action === 'update_note') {
                $cart[$key]['catatan'] = $request->catatan;
            } 
            elseif ($request->action === 'update_qty' || $request->has('jumlah')) {
                $jumlah = max(1, (int) $request->jumlah);
                $cart[$key]['jumlah'] = $jumlah;
                $cart[$key]['subtotal'] = $jumlah * $cart[$key]['menu']['harga'];
            }

            session()->put('cart', $cart);
        }

        return redirect()->back()->with('success', 'Keranjang berhasil diperbarui!');
    }

    public function cartRemove(Request $request)
    {
        $key = $request->key;
        $cart = session('cart', []);
        unset($cart[$key]);
        session(['cart' => $cart]);
        session(['cart_count' => count($cart)]);

        // return redirect()->route('customer.cart')->with('success', 'Menu berhasil dihapus!');
        return redirect()->route('customer.cart', $this->selfOrderParams())->with('success', 'Menu berhasil dihapus!');
    }

    // CHECKOUT
    public function checkout(Request $request)
    {
        // 1. Ambil & Validasi Nomor Meja
        $nomorMeja = $request->query('nomor_meja') ?? session('nomor_meja');
        
        if (!$nomorMeja) {
            return redirect()->route('customer.selforder')
                ->withErrors(['Silakan scan QR code meja terlebih dahulu.']);
        }

        $tables = Meja::where('nomor_meja', $nomorMeja)->first();

        if (!$tables || !session('selforder_code')) {
            return redirect()->route('home')->with('error', 'Silakan scan QR meja terlebih dahulu.');
        }

        session([
            'nomor_meja' => $tables->nomor_meja,
            'id_meja' => $tables->id,
        ]);

        if (
            $request->query('kode') !== session('selforder_code') ||
            $request->query('tableNumber') !== $tables->nomor_meja
        ) {
            return redirect()->route('customer.checkout', $this->selfOrderParams());
        }

        // 2. Validasi Keranjang Belanja
        $cartItems = session('cart', []);

        // Untuk cart kosong:
        if (empty($cartItems)) {
            return $this->redirectToSelfOrder('Keranjang Anda kosong. Silakan pilih menu terlebih dahulu.');
        }

        // --- TAMBAHAN LOGIKA PENGECEKAN REAL-TIME ---
        $hasMenuChanges = false;
        $menuChangeMessages = [];
        $totalHarga = 0;

        foreach ($cartItems as $key => $item) {
            $menuDb = Menu::find($item['menu']['id'] ?? null);

            // Cek jika menu dihapus atau ditutup
            if (!$menuDb || $menuDb->status !== 'open') {
                $hasMenuChanges = true;
                $menuChangeMessages[] = "Menu '{$item['menu']['nama']}' saat ini sudah habis/ditutup.";
            } else {
                // Cek jika harga berubah di database
                if ((int)$menuDb->harga !== (int)($item['menu']['harga'] ?? 0)) {
                    $hasMenuChanges = true;
                    $menuChangeMessages[] = "Harga '{$menuDb->nama}' telah diperbarui menjadi Rp " . number_format($menuDb->harga, 0, ',', '.') . ". Silahkan kembali ke halaman sebelumnya";
                }
                // Selalu kalkulasi ulang berdasarkan harga DB agar aman
                $totalHarga += ((int)$menuDb->harga * $item['jumlah']);
            }
        }

        // 3. Kalkulasi Total Harga, PB1 (10%), dan Total Bayar
        $totalHarga = collect($cartItems)->sum('subtotal');
        // $pb         = round($totalHarga * 0.1);
        // $totalBayar = $totalHarga + $pb;

        return view('customer.checkout', 
            compact('cartItems', 
            'totalHarga', 
            // 'pb', 
            // 'totalBayar', 
            'tables',
            'hasMenuChanges', 
            'menuChangeMessages'));
    }

    // PAYMENT
    public function payment(Request $request)
    {
        $cartItems = session('cart', []);
        if (empty($cartItems)) {
            return redirect()->route('customer.cart');
        }

        $idMeja = session('id_meja');
        if (!$idMeja) {
            return redirect()->route('customer.cart')->withErrors(['Informasi meja hilang, silahkan scan kembali QR Code meja Anda.']);
        }
        return redirect()->route('customer.checkout.create');
    }

    public function createCheckoutTransaction(Request $request)
    {
        $validated = $request->validate([
            'metode_pembayaran' => ['required', 'in:Tunai,Midtrans'],
        ]);

        $metode = strtolower($validated['metode_pembayaran']);
        $cart = session('cart', []);
        $idMeja = session('id_meja');
        $kodePesanan = session('selforder_code');

        if (empty($cart) || !$idMeja || !$kodePesanan) {
            return $this->redirectToSelfOrder(
                'Sesi pesanan tidak ditemukan. Silakan scan QR meja kembali.'
            );
        }

        // --- PENGECEKAN RACE CONDITION (DETIK TERAKHIR) ---
        $hasChanges = false;
        foreach ($cart as $key => $item) {
            $menu = Menu::find($item['menu']['id'] ?? null);
            // Jika menu dihapus, ditutup admin, atau harganya berubah
            if (!$menu || $menu->status !== 'open' || (int)$menu->harga !== (int)($item['menu']['harga'] ?? 0)) {
                $hasChanges = true;
                break;
            }
        }

        // Jika ada perubahan, kembalikan ke halaman Checkout agar Alert Merah muncul dan tombol mati
        if ($hasChanges) {
            return redirect()->route('customer.checkout', $this->selfOrderParams())
                ->with('error', 'Terjadi perubahan pada ketersediaan atau harga menu. Silakan periksa peringatan di layar.');
        }
        // ---------------------------------------------------

        $items = [];
        $totalHarga = 0;
        $detailItems = [];

        foreach ($cart as $key => $item) {
            $menu = Menu::find($item['menu']['id'] ?? null);

            $jumlah = (int) ($item['jumlah'] ?? 0);

            if ($jumlah < 1) {
                return $this->redirectToSelfOrder('Jumlah menu tidak valid.');
            }

            // Gunakan harga terbaru dari database, bukan harga dari session.
            $subtotal = (int) $menu->harga * $jumlah;
            $totalHarga += $subtotal;

            $items[] = [
                'id' => (string) $menu->id,
                'price' => (int) $menu->harga,
                'quantity' => $jumlah,
                'name' => substr($menu->nama, 0, 50),
            ];

            $detailItems[] = [
                'id_menu' => $menu->id,
                'jumlah' => $jumlah,
                'subtotal' => $subtotal,
                'catatan' => $item['catatan'] ?? null,
            ];
        }

        if ($totalHarga < 1) {
            return redirect()->route('customer.cart')->with('error', 'Keranjang Anda kosong.');
        }

        // Buat pesanan, detail, dan pembayaran bersama agar tidak ada data parsial.
        $pesanan = DB::transaction(function () use (
            $idMeja,
            $kodePesanan,
            $totalHarga,
            $detailItems,
            $metode
        ) {
            $order = Pesanan::create([
                'kode_pesanan' => 'SOD-' . $kodePesanan,
                'id_user' => null,
                'id_meja' => $idMeja,
                'total_harga' => $totalHarga,
                'status' => 'Pending',
            ]);

            foreach ($detailItems as $detail) {
                DetailPesanan::create([
                    'id_pesanan' => $order->id,
                    'id_menu' => $detail['id_menu'],
                    'jumlah' => $detail['jumlah'],
                    'subtotal' => $detail['subtotal'],
                    'catatan' => $detail['catatan'],
                ]);
            }

            $order->pembayaran()->create([
                'jenis' => 'Full',
                'metode' => $metode,
                'nominal' => $totalHarga,
                'status' => 'Pending',
            ]);

            return $order;
        });

        // Hindari pembuatan pesanan duplikat jika pelanggan refresh halaman checkout.
        session()->forget(['cart', 'cart_count', 'selforder_code']);

        if ($metode === 'midtrans') {
            try {
                MidtransConfig::$serverKey = config(
                    'services.midtrans.server_key',
                    env('MIDTRANS_SERVER_KEY')
                );
                MidtransConfig::$isProduction = (bool) config(
                    'services.midtrans.is_production',
                    env('MIDTRANS_IS_PRODUCTION') === 'true'
                );
                MidtransConfig::$isSanitized = true;
                MidtransConfig::$is3ds = true;

                $pembayaran = $pesanan->pembayaran()
                    ->whereRaw("LOWER(TRIM(jenis)) = 'full'")
                    ->latest('id')
                    ->firstOrFail();

                $midtransOrderId = 'ORDER-' . $pesanan->id . '-' . Str::random(5);

                $snapToken = Snap::getSnapToken([
                    'transaction_details' => [
                        'order_id' => $midtransOrderId,
                        'gross_amount' => $totalHarga,
                    ],
                    'item_details' => $items,

                    // Dipertahankan karena other_qris sudah berhasil pada konfigurasi sebelumnya.
                    'enabled_payments' => ['other_qris'],

                    'custom_expiry' => [
                        'start_time' => now()->format('Y-m-d H:i:s O'),
                        'unit' => 'minute',
                        'duration' => 15,
                    ],
                    'callbacks' => [
                        'finish' => route('customer.order.detail', [
                            'kode_pesanan' => $pesanan->kode_pesanan,
                        ]),
                        'unfinish' => route('customer.order.detail', [
                            'kode_pesanan' => $pesanan->kode_pesanan,
                        ]),
                        'error' => route('customer.order.detail', [
                            'kode_pesanan' => $pesanan->kode_pesanan,
                        ]),
                    ],
                ]);

                $pembayaran->update([
                    'midtrans_order_id' => $midtransOrderId,
                    'snap_token' => $snapToken,
                ]);
            } catch (\Throwable $e) {
                report($e);

                // Jangan batalkan pesanan. Status pesanan dan pembayaran tetap Pending.
                return redirect()
                    ->route('customer.order.detail', [
                        'kode_pesanan' => $pesanan->kode_pesanan,
                    ])
                    ->with(
                        'error',
                        'QRIS belum dapat disiapkan. Pesanan tetap menunggu pembayaran; silakan coba lagi.'
                    );
            }
        }

        return redirect()->route('customer.order.detail', [
            'kode_pesanan' => $pesanan->kode_pesanan,
        ]);
    }

    // public function createCheckoutTransaction(Request $request)
    // {
    //     $validated = $request->validate([
    //         'metode_pembayaran' => ['required', 'in:Tunai,Midtrans'],
    //     ]);

    //     $metode = $validated['metode_pembayaran'];

    //     // Ambil cart session
    //     $cart = session()->get('cart', []);
    //     $idMeja = session('id_meja');
    //     $kodePesanan = session('selforder_code');
    //     if (empty($cart) || !$idMeja || !$kodePesanan) {
    //         return $this->redirectToSelfOrder('Sesi pesanan tidak ditemukan. Silakan scan QR meja kembali.');
    //     }

    //     // Hitung total harga murni menu & item_details
    //     $items = [];
    //     $totalHargaMenu = 0;

    //     foreach ($cart as $itemKey => $it) {
    //         $menu = $it['menu'];
    //         $qty = (int) $it['jumlah'];
    //         $harga = (int) $menu['harga'];
    //         $subtotal = $harga * $qty;

    //         $items[] = [
    //             'id'       => (string) $menu['id'],
    //             'price'    => $harga,
    //             'quantity' => $qty,
    //             'name'     => substr($menu['nama'], 0, 50), // Midtrans membatasi nama max 50 karakter
    //         ];

    //         $totalHargaMenu += $subtotal;
    //     }

    //     // Kalkulasi PB1 dan Total Bayar
    //     // $pb = round($totalHargaMenu * 0.1);
    //     // $totalBayar = $totalHargaMenu + $pb;

    //     // WAJIB: Tambahkan PB1 ke dalam item_details Midtrans
    //     // Agar gross_amount (Total Bayar) sama dengan total penjumlahan item
    //     // if ($pb > 0) {
    //     //     $items[] = [
    //     //         'id'       => 'TAX-PB1',
    //     //         'price'    => $pb,
    //     //         'quantity' => 1,
    //     //         'name'     => 'Pajak Restoran (PB1 10%)',
    //     //     ];
    //     // }

    //     // Ambil id_meja dari session
    //     $idMeja = session('id_meja');

    //     // Simpan order dengan status Pending dan nilai kalkulasi baru
    //     $order = Pesanan::create([
    //         // 'kode_pesanan'      => 'SOD-' . now()->format('Ymd') . '-' . strtoupper(Str::random(4)),
    //         'kode_pesanan'      => 'SOD-' . $kodePesanan,
    //         'id_user'           => auth()->id(),
    //         'id_meja'           => $idMeja,
    //         // 'id_reservasi'      => null,
    //         'total_harga'       => $totalHargaMenu,
    //         // 'pb'                => $pb,
    //         // 'total_bayar'       => $totalBayar,
    //         'status'            => 'Pending',
    //         // 'metode_pembayaran' => strtolower($metode),
    //     ]);

    //     foreach ($cart as $itemKey => $it) {
    //         DetailPesanan::create([
    //             'id_pesanan' => $order->id,
    //             'id_menu'    => $it['menu']['id'],
    //             'jumlah'     => (int) $it['jumlah'],
    //             'subtotal'   => (int) $it['subtotal'],
    //             'catatan'    => $it['catatan'] ?? null,
    //         ]);
    //     }
    //     // session()->forget('cart');

    //     // Konfigurasi Midtrans
    //     MidtransConfig::$serverKey = env('MIDTRANS_SERVER_KEY');
    //     MidtransConfig::$isProduction = env('MIDTRANS_IS_PRODUCTION') === 'true';
    //     MidtransConfig::$isSanitized = true;
    //     MidtransConfig::$is3ds = true;

    //     $transactionDetails = [
    //         'order_id'     => 'ORDER-' . $order->id . '-' . Str::random(5),
    //         'gross_amount' => (int) $totalHargaMenu,
    //     ];

    //     $params = [
    //         'transaction_details' => $transactionDetails,
    //         'item_details'        => $items,
    //         'enabled_payments'    => ['other_qris'],
    //         'custom_expiry'       => [
    //             'start_time' => date("Y-m-d H:i:s O"),
    //             'unit'       => 'minute',
    //             'duration'   => 15
    //         ],
    //         // Callback untuk mengarahkan UI Pelanggan
    //         'callbacks'           => [
    //             // 'finish'   => route('customer.order.detail', ['id' => $order->id]),
    //             'finish' => route('customer.order.detail', [
    //                 'kode_pesanan' => $order->kode_pesanan,
    //             ]),
    //             // Jika diklik X atau gagal, kembali ke halaman Checkout
    //             // 'unfinish' => route('customer.checkout'),
    //             // 'error'    => route('customer.checkout'),
    //             'unfinish' => route('customer.checkout', $this->selfOrderParams()),
    //             'error' => route('customer.checkout', $this->selfOrderParams()),
    //         ],
    //     ];

    //     // Simpan snapToken ke DB
    //     if($metode === 'Midtrans'){
    //         $snapToken = Snap::getSnapToken($params);
    //         $order->update(['snap_token' => $snapToken]);
    //     }
    //     // if($metode === 'Tunai'){
    //     //     $order->update(['snap_token' => null]);
    //     // }

    //     // Sesudah pesanan berhasil dibuat dan snapToken disimpan:
    //     session()->forget(['cart', 'cart_count', 'selforder_code']);

    //     // Langsung redirect tanpa perlu bawa query parameter snap_token
    //     return redirect()->route('customer.order.detail', ['kode_pesanan' => $order->kode_pesanan]);
    // }

    public function orderDetail($kode_pesanan)
    {
        $pesanan = Pesanan::with(['detailPesanan.menu', 'meja', 'pembayaran'])
            ->where('kode_pesanan', $kode_pesanan)
            ->firstOrFail();

        $this->syncExpiredMidtransPayment($pesanan);
        $pesanan->refresh()->load(['detailPesanan.menu', 'meja', 'pembayaran']);

        $snapToken = $pesanan->pembayaran()
            ->whereRaw("LOWER(TRIM(jenis)) = 'full'")
            ->whereRaw("LOWER(TRIM(status)) = 'pending'")
            ->whereRaw("LOWER(TRIM(metode)) = 'midtrans'")
            ->latest('id')
            ->value('snap_token');

        return view('customer.order_detail', compact('pesanan', 'snapToken'));
    }

    public function orderStatus(string $kode_pesanan)
    {
        $pesanan = Pesanan::where('kode_pesanan', $kode_pesanan)->firstOrFail();

        return response()->json([
            'status' => strtolower($pesanan->status),
        ]);
    }

    private function syncExpiredMidtransPayment(Pesanan $pesanan): void
    {
        $payment = $pesanan->pembayaran()
            ->whereRaw("LOWER(TRIM(jenis)) = 'full'")
            ->whereRaw("LOWER(TRIM(metode)) = 'midtrans'")
            ->whereRaw("LOWER(TRIM(status)) = 'pending'")
            ->latest('id')
            ->first();

        if (!$payment || !$payment->midtrans_order_id || !$payment->created_at?->lte(now()->subMinutes(15))) {
            return;
        }

        MidtransConfig::$serverKey = config('services.midtrans.server_key')
            ?: env('MIDTRANS_SERVER_KEY');
        MidtransConfig::$isProduction = filter_var(
            config('services.midtrans.is_production', env('MIDTRANS_IS_PRODUCTION', false)),
            FILTER_VALIDATE_BOOLEAN
        );

        try {
            $status = Transaction::status($payment->midtrans_order_id);
            $transactionStatus = strtolower((string) ($status->transaction_status ?? ''));

            if (!in_array($transactionStatus, ['expire', 'cancel', 'deny'], true)) {
                return;
            }

            DB::transaction(function () use ($payment, $pesanan) {
                $lockedPayment = Pembayaran::whereKey($payment->id)
                    ->lockForUpdate()
                    ->first();

                $lockedOrder = Pesanan::whereKey($pesanan->id)
                    ->lockForUpdate()
                    ->first();

                // Jangan batalkan transaksi yang sudah berubah status.
                if (
                    !$lockedPayment
                    || !$lockedOrder
                    || strtolower(trim((string) $lockedPayment->status)) !== 'pending'
                    || strtolower(trim((string) $lockedOrder->status)) !== 'pending'
                ) {
                    return;
                }

                $lockedPayment->forceFill(['status' => 'Failed'])->save();
                // $lockedOrder->forceFill(['status' => 'Cancelled'])->save();
            }, 3);
        } catch (\Throwable $e) {
            // Gangguan API Midtrans bukan bukti pembayaran expired; biarkan pending.
            Log::warning('Gagal memeriksa status Midtrans self-order.', [
                'payment_id' => $payment->id,
                'order_id' => $payment->midtrans_order_id,
                'error' => $e->getMessage(),
            ]);
        }
    }
}
