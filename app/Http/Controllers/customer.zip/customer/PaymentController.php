<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use Midtrans\Config as MidtransConfig;
use Midtrans\Notification;
use App\Models\Pesanan;
use App\Models\Pembayaran;
use App\Models\Reservasi;
use App\Services\FonnteService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Midtrans\Transaction;
use Midtrans\Snap;

class PaymentController extends Controller
{
    public function midtransNotification(Request $request)
    {
        MidtransConfig::$serverKey = config('services.midtrans.server_key')
            ?: env('MIDTRANS_SERVER_KEY');

        $production = config('services.midtrans.is_production');
        if ($production === null) {
            $production = env('MIDTRANS_IS_PRODUCTION', false);
        }

        MidtransConfig::$isProduction = filter_var($production, FILTER_VALIDATE_BOOLEAN);
        MidtransConfig::$isSanitized = true;
        MidtransConfig::$is3ds = true;

        try {
            // Memvalidasi notifikasi Midtrans.
            $notification = new Notification();
            $orderId = (string) ($notification->order_id ?? '');

            if ($orderId === '') {
                return response()->json(['message' => 'Order ID tidak ditemukan'], 400);
            }

            $payment = Pembayaran::where('midtrans_order_id', $orderId)->first();

            if (!$payment) {
                Log::warning('Callback Midtrans tidak menemukan pembayaran.', [
                    'order_id' => $orderId,
                ]);

                return response()->json(['message' => 'Payment not found'], 200);
            }

            // Pakai status terbaru dari Midtrans, bukan callback yang mungkin terlambat.
            $latest = Transaction::status($orderId);

            $status = strtolower((string) ($latest->transaction_status ?? ''));
            $fraudStatus = strtolower((string) ($latest->fraud_status ?? ''));
            $grossAmount = (float) ($latest->gross_amount ?? $notification->gross_amount ?? 0);

            if (round($grossAmount, 2) !== round((float) $payment->nominal, 2)) {
                Log::error('Nominal callback Midtrans tidak cocok.', [
                    'order_id' => $orderId,
                    'midtrans_amount' => $grossAmount,
                    'database_amount' => $payment->nominal,
                ]);

                return response()->json(['message' => 'Amount mismatch'], 200);
            }

            $success = $status === 'settlement'
                || ($status === 'capture' && $fraudStatus === 'accept');

            $failed = in_array($status, ['deny', 'cancel', 'expire'], true);

            // Pending/challenge bukan bukti berhasil maupun gagal.
            if (!$success && !$failed) {
                return response()->json(['message' => 'Notification received'], 200);
            }

            $reservasiToNotify = null;

            DB::transaction(function () use ($payment, $success, &$reservasiToNotify) {
                $lockedPayment = Pembayaran::whereKey($payment->id)
                    ->lockForUpdate()
                    ->firstOrFail();

                $pesanan = Pesanan::whereKey($lockedPayment->id_pesanan)
                    ->lockForUpdate()
                    ->firstOrFail();

                $currentPaymentStatus = strtolower(trim((string) $lockedPayment->status));

                // Status pembayaran yang sudah sukses tidak boleh dibatalkan callback gagal.
                if ($currentPaymentStatus === 'success') {
                    return;
                }

                if ($success) {
                    $jenis = strtolower(trim((string) $lockedPayment->jenis));

                    $orderStatus = match ($jenis) {
                        'full' => 'Paid',
                        'dp' => 'Reserved',
                        default => throw new \UnexpectedValueException(
                            "Jenis pembayaran tidak dikenali: {$lockedPayment->jenis}"
                        ),
                    };

                    $lockedPayment->forceFill(['status' => 'Success'])->save();
                    $pesanan->forceFill(['status' => $orderStatus])->save();

                    // TAMBAHKAN KEMBALI LOGIKA FONNTE DI SINI KHUSUS DP
                    if ($jenis === 'dp') {
                        $reservasiToNotify = \App\Models\Reservasi::with('customer')->where('id_pesanan', $pesanan->id)->first();
                    }
                    return;
                }

                $lockedPayment->forceFill(['status' => 'Failed'])->save();
                // $pesanan->forceFill(['status' => 'Cancelled'])->save(); //ini dikomentar krn statusnya masih pending dlu agar bisa ulangi pembayaran
            }, 3);

            // return response()->json(['message' => 'Notification processed'], 200);
            // Kirim notifikasi WA SETELAH DB::transaction selesai dengan aman
            if ($reservasiToNotify) {
                try {
                    $fonnte = app(FonnteService::class);
                    $detailUrl = route('customer.reservasi.detail', ['id' => $reservasiToNotify->id]);

                    if (!$reservasiToNotify->customer_notif) {
                        $reservasiToNotify->update(['customer_notif' => true]);
                        $fonnte->send($reservasiToNotify->customer->nomor_telp, "Pembayaran DP reservasi diterima.\nCek: {$detailUrl}");
                    }
                    if (!$reservasiToNotify->admin_notif) {
                        $reservasiToNotify->update(['admin_notif' => true]);
                        $fonnte->send(env('FONNTE_PHONE'), "Reservasi baru telah membayar DP!\nTanggal: {$reservasiToNotify->tanggal}");
                    }
                } catch (\Throwable $e) {
                    // Log error Fonnte, tapi jangan gagalkan transaksi pembayaran yang sudah sukses
                    Log::error('Fonnte Gagal Kirim Pesan', ['error' => $e->getMessage()]);
                }
            }
        } catch (\Throwable $e) {
            Log::error('Callback Midtrans gagal diproses.', [
                'message' => $e->getMessage(),
                'payload' => $request->all(),
            ]);

            // Error sementara/API Midtrans gagal: minta Midtrans mencoba callback lagi.
            return response()->json(['message' => 'Notification processing failed'], 500);
        }
    }

    public function ulangiPembayaran($kode_pesanan) 
    {
        $pesanan = Pesanan::with(['detailPesanan.menu', 'pembayaran'])->where('kode_pesanan', $kode_pesanan)->firstOrFail();
        
        if (strtolower(trim($pesanan->status)) !== 'pending') {
            return back()->with('error', 'Tindakan ditolak. Status pesanan saat ini adalah ' . $pesanan->status);
        }

        $isReservasi = \App\Models\Reservasi::where('id_pesanan', $pesanan->id)->first();

        // 1. VALIDASI ULANG (MENCEGAH RACE CONDITION SETELAH IDLE 15 MENIT)
        if ($isReservasi) {
            $overlappingOrang = Reservasi::whereDate('tanggal', $isReservasi->tanggal)
                ->where('jam_mulai', '<', $isReservasi->jam_selesai)
                ->where('jam_selesai', '>', $isReservasi->jam_mulai)
                ->where('id', '!=', $isReservasi->id)
                ->whereHas('pesanan', fn($q) => $q->whereNotIn('status', ['Cancelled']))
                ->sum('jml_org');

            if (($overlappingOrang + $isReservasi->jml_org) > 88) {
                $this->batalkanPesanan($kode_pesanan); // Auto Cancel
                return redirect()->route('home')->with('error', 'Maaf, sisa kursi telah habis dipesan pelanggan lain selama Anda belum melakukan pembayaran. Reservasi dibatalkan otomatis.');
            }
        } else {
            foreach ($pesanan->detailPesanan as $detail) {
                if (!$detail->menu || $detail->menu->status !== 'open') {
                    $this->batalkanPesanan($kode_pesanan); // Auto Cancel
                    return redirect()->route('customer.selforder', ['tableNumber' => $pesanan->meja->nomor_meja ?? ''])->with('error', "Maaf, menu '{$detail->menu->nama}' baru saja habis stoknya. Pesanan sebelumnya dibatalkan otomatis, silakan pesan ulang.");
                }
            }
        }

        // 2. BUAT DATA PEMBAYARAN BARU
        $oldPayment = $pesanan->pembayaran()->where('metode', 'midtrans')->latest('id')->first();
        $nominal = $oldPayment ? $oldPayment->nominal : ($isReservasi ? 50000 : $pesanan->total_harga);
        $jenis = $isReservasi ? 'DP' : 'Full';
        
        $midtransOrderId = ($isReservasi ? 'RESERV-' . $isReservasi->id : 'ORDER-' . $pesanan->id) . '-' . Str::random(5);

        $newPayment = Pembayaran::create([
            'id_pesanan' => $pesanan->id,
            'jenis' => $jenis,
            'metode' => 'midtrans',
            'nominal' => $nominal,
            'midtrans_order_id' => $midtransOrderId,
            'status' => 'Pending',
        ]);

        // 3. RE-GENERATE SNAP TOKEN MIDTRANS
        MidtransConfig::$serverKey = config('services.midtrans.server_key') ?: env('MIDTRANS_SERVER_KEY');
        MidtransConfig::$isProduction = filter_var(config('services.midtrans.is_production', env('MIDTRANS_IS_PRODUCTION', false)), FILTER_VALIDATE_BOOLEAN);
        MidtransConfig::$isSanitized = true;
        MidtransConfig::$is3ds = true;

        $items = [];
        if ($isReservasi) {
            $items[] = [
                'id' => 'dp-' . $isReservasi->id,
                'price' => $nominal,
                'quantity' => 1,
                'name' => 'DP Reservasi',
            ];
            $customerDetails = [
                'first_name' => $isReservasi->customer->nama ?? 'Guest',
                'phone' => $isReservasi->customer->nomor_telp ?? '',
            ];
        } else {
            foreach ($pesanan->detailPesanan as $detail) {
                $items[] = [
                    'id' => (string) $detail->id_menu,
                    // GUNAKAN HARGA YANG SUDAH DIKUNCI DI DATABASE, BUKAN HARGA MENU SAAT INI
                    'price' => (int) ($detail->subtotal / $detail->jumlah), 
                    'quantity' => $detail->jumlah,
                    'name' => substr($detail->menu->nama ?? 'Menu', 0, 50),
                ];
            }
            $customerDetails = [
                'first_name' => 'Meja ' . ($pesanan->meja->nomor_meja ?? 'Tamu'),
            ];
        }

        $returnUrl = $isReservasi 
            ? route('customer.reservasi.detail', ['id' => $isReservasi->id])
            : route('customer.order.detail', ['kode_pesanan' => $pesanan->kode_pesanan]);

        try {
            $snapToken = Snap::getSnapToken([
                'transaction_details' => [
                    'order_id' => $midtransOrderId,
                    'gross_amount' => $nominal,
                ],
                'item_details' => $items,
                'customer_details' => $customerDetails,
                'enabled_payments' => $isReservasi ? ['gopay', 'shopeepay', 'other_qris', 'bank_transfer'] : ['other_qris'],
                'custom_expiry' => [
                    'start_time' => now()->format('Y-m-d H:i:s O'),
                    'unit' => 'minute',
                    'duration' => 15, // Diberi waktu 15 menit lagi
                ],
                'callbacks' => [
                    'finish' => $returnUrl,
                    'unfinish' => $returnUrl,
                    'error' => $returnUrl,
                ],
            ]);

            $newPayment->update(['snap_token' => $snapToken]);
            return redirect($returnUrl);

        } catch (\Throwable $e) {
            Log::error('Ulangi pembayaran gagal: ' . $e->getMessage());
            return back()->with('error', 'Gagal memuat pembayaran Midtrans baru. Silakan coba lagi.');
        }
    }

    public function batalkanPesanan($kode_pesanan) 
    {
        $pesanan = Pesanan::where('kode_pesanan', $kode_pesanan)->firstOrFail();
        
        if (strtolower(trim($pesanan->status)) === 'pending') {
            DB::transaction(function () use ($pesanan) {
                $pesanan->update(['status' => 'Cancelled']);
                $pesanan->pembayaran()->where('status', 'Pending')->update(['status' => 'Failed']);
            });
        }
        
        $isReservasi = \App\Models\Reservasi::where('id_pesanan', $pesanan->id)->first();
        if ($isReservasi) {
            return redirect()->route('home')->with('success', 'Reservasi berhasil dibatalkan.');
        }
        
        return redirect()->route('customer.selforder', [
            'kode' => $pesanan->kode_pesanan, 
            'tableNumber' => $pesanan->meja->nomor_meja ?? ''
        ])->with('success', 'Pesanan berhasil dibatalkan.');
    }

// Sembunyikan dari Kasir/Dapur: Pastikan query di AdminController atau OrderController tidak memunculkan pesanan berstatus Pending (via Midtrans) di daftar antrean dapur atau notifikasi kasir. Pesanan hanya boleh muncul setelah berstatus Paid.
// Auto-Cancel Harian: Anda tidak perlu pusing memikirkan data yang menggantung ini. Namun, disarankan membuat satu fungsi sederhana (bisa dieksekusi manual oleh admin saat tutup restoran, atau otomatis lewat Cron Job) yang mencari semua pesanan berstatus Pending lebih dari 2 jam, lalu otomatis mengubah statusnya menjadi Cancelled untuk membersihkan database. Mana yg lebih baik?
}
