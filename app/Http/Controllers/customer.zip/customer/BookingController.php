<?php

namespace App\Http\Controllers\customer;

use App\Http\Controllers\Controller;
use App\Services\MenuQuoteService;
use App\Models\Menu;
use App\Models\Pesanan;
use App\Models\DetailPesanan;
use App\Models\Customer;
use App\Models\Reservasi;
use App\Models\Pembayaran;
use App\Models\Meja;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Midtrans\Snap;
use Midtrans\Transaction;
use Midtrans\Config as MidtransConfig;

class BookingController extends Controller
{
    private const RESERVATION_CAPACITY = 88;

    private function reservationCapacityUsed(
        string $date,
        string $start,
        string $end
    ): int {
        $pendingCutoff = now()->subMinutes(15);
        $reservationExpiryCutoff = now()->subHour();

        return (int) Reservasi::query()
            ->whereDate('tanggal', $date)
            ->where('jam_mulai', '<', $end)
            ->where('jam_selesai', '>', $start)
            ->whereHas('pesanan', function ($query) use ($pendingCutoff, $reservationExpiryCutoff) {
                $query->where(function ($status) use ($pendingCutoff, $reservationExpiryCutoff) {
                    $status->whereRaw(
                        "LOWER(TRIM(status)) IN ('reserved', 'confirmed', 'processing')"
                    )->orWhere(function ($pending) use ($pendingCutoff, $reservationExpiryCutoff) {
                        $pending->whereRaw("LOWER(TRIM(status)) = 'pending'")
                        ->where('created_at', '>=', $reservationExpiryCutoff)
                            ->whereHas('pembayaran', function ($payment) use ($pendingCutoff) {
                                $payment->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
                                    ->whereRaw("LOWER(TRIM(status)) = 'pending'")
                                    ->where('created_at', '>=', $pendingCutoff);
                            });
                    });
                });
            })
            ->sum('jml_org');
    }

    private function findPendingReservationForPhone(string $phone): ?Reservasi
    {
        $customer = Customer::where('nomor_telp', $phone)->first();

        if (!$customer) {
            return null;
        }

        return Reservasi::query()
            ->where('id_customer', $customer->id)
            ->whereHas('pesanan', function ($query) {
                $query->whereRaw("LOWER(TRIM(status)) = 'pending'")
                    ->whereHas('pembayaran', function ($payment) {
                        $payment->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
                            ->whereRaw("LOWER(TRIM(status)) IN ('pending', 'failed')");
                    });
            })
            ->latest('id')
            ->first();
    }

    // private function findActiveReservationForPhone(array $draft): ?Reservasi
    // {
    //     $customer = Customer::where('nomor_telp', $draft['nomor_telp'])->first();

    //     if (!$customer) {
    //         return null;
    //     }

    //     return Reservasi::query()
    //         ->where('id_customer', $customer->id)
    //         ->whereDate('tanggal', $draft['tanggal'])
    //         ->where('jam_mulai', $draft['jam_mulai'])
    //         ->where('created_at', '>=', now()->subHours(24))
    //         ->whereHas('pesanan', function ($query) {
    //             $query->whereRaw(
    //                 "LOWER(TRIM(status)) IN ('pending', 'reserved', 'confirmed')"
    //             );
    //         })
    //         ->latest('id')
    //         ->first();
    // }

    private function reservationQuoteLines(array $draft): array
    {
        $lines = [];
        $quantities = $draft['menu_qty'] ?? [];
        $snapshots = $draft['menu_snapshot'] ?? [];
        $notes = $draft['menu_notes'] ?? [];

        foreach ($quantities as $menuId => $qty) {
            $lines[] = [
                'id' => $menuId,
                'qty' => $qty,
                'notes' => $notes[$menuId] ?? null,
                'snapshot' => $snapshots[(string) $menuId] ?? null,
            ];
        }

        return $lines;
    }

    // RESERVASI
    public function reservasiForm(Request $request)
    {
        // Menu open ATAU (menu closed tapi reservable)
        // $menus = Menu::where('status', 'open')
        //             ->orWhere('is_reservable', true)
        //             ->orderByDesc('is_bestseller')
        //             ->get();
        $menus = Menu::Where('is_reservable', true)
                    ->orderByDesc('is_bestseller')
                    ->get();

        session([
            'reservation_form_menu_quote' => app(MenuQuoteService::class)->capture($menus),
        ]);

        // Ambil data pre-fill dari query string (jika diisi dari beranda)
        // $prefill = [
        //     'tanggal'     => $request->query('tanggal'),
        //     'jam_mulai'   => $request->query('jam_mulai'),
        //     'jam_selesai' => $request->query('jam_selesai'),
        //     'jml_org'   => $request->query('jml_org'),
        // ];
        $draft = session('reservation_draft', []);
        $draft = is_object($draft) ? get_object_vars($draft) : (array) $draft;

        $prefill = array_merge([
            'nama' => '',
            'nomor_telp' => '',
            'tanggal' => '',
            'jam_mulai' => '',
            'jam_selesai' => '',
            'jml_org' => '',
            'keterangan' => '',
        ], array_intersect_key($draft, array_flip([
            'nama',
            'nomor_telp',
            'tanggal',
            'jam_mulai',
            'jam_selesai',
            'jml_org',
            'keterangan',
        ])));

        // Data pengecekan ketersediaan dari landing page mengalahkan jadwal draft lama.
        foreach (['tanggal', 'jam_mulai', 'jam_selesai', 'jml_org'] as $key) {
            if ($request->query->has($key)) {
                $prefill[$key] = $request->query($key);
            }
        }

        return view('customer.reservasi', compact('menus', 'prefill'));
    }

    public function reservationMenu()
    {
        // Menu open ATAU (menu closed tapi reservable)
        $menus = Menu::Where('is_reservable', true)
                    ->orderByDesc('is_bestseller')
                    ->get();
        $categories = Menu::where('status', 'open')->distinct()->orderBy('kategori')->pluck('kategori');

        return view('customer.reservation_menu', compact('menus', 'categories'));
    }

    public function reservationMenuDetail($id)
    {
        $menu = Menu::findOrFail($id);
        return view('customer.reservation_menu_detail', compact('menu'));
    }

    // TAHAP 1: FORM KE SESSION DRAFT (BELUM MASUK DB)
    public function reservasiStore(Request $request)
    {
        // $totalOrangHariIni = Reservasi::whereDate('tanggal', $request->tanggal)->sum('jml_org');
        // if (($totalOrangHariIni + $request->jml_org) > 88) {
        //     return back()->withErrors(['Kapasitas restoran untuk tanggal tersebut sudah penuh.']);
        // }

        $validated = $request->validate([
            'nama'         => 'required|string|min:3|max:50',
            'nomor_telp'   => 'required|string|regex:/^[0-9\+\-\s]{9,20}$/',
            'tanggal'      => 'required|date|after_or_equal:today',
            'jam_mulai'    => 'required|date_format:H:i',
            'jam_selesai'  => 'required|date_format:H:i|after:jam_mulai',
            'jml_org'      => 'required|integer|min:1',
            'keterangan'   => 'nullable|string|max:200',
            'menu_qty' => ['nullable', 'array'],
            'menu_qty.*' => ['nullable', 'integer', 'min:0', 'max:100'],
            'menu_price' => ['nullable', 'array'], 
            'menu_price.*' => ['nullable', 'integer'],
            'menu_notes' => ['nullable', 'array'],
            'menu_notes.*' => ['nullable', 'string', 'max:200'],
        ], ['jam_selesai.after' => 'Jam selesai harus lebih akhir dari jam mulai.']);

        if ($validated['jam_mulai'] < '15:00' || $validated['jam_mulai'] > '23:59'
            || $validated['jam_selesai'] > '23:59') {
            return back()
                ->withErrors(['jam_mulai' => 'Reservasi hanya dapat dibuat pada jam operasional 15:00–00:00.'])
                ->withInput();
        }

        // $overlappingOrang = Reservasi::whereDate('tanggal', $request->tanggal)
        //     ->where('jam_mulai', '<', $request->jam_selesai) // Jam mulai baru < Jam selesai existing
        //     ->where('jam_selesai', '>', $request->jam_mulai) // Jam selesai baru > Jam mulai existing
        //     ->whereHas('pesanan', function($q) {
        //         // Jangan hitung reservasi yang sudah dibatalkan
        //         $q->whereNotIn('status', ['Cancelled']); 
        //     })
        //     ->sum('jml_org');

        // if (($overlappingOrang + $request->jml_org) > 88) {
        //     $sisa = max(0, 88 - $overlappingOrang);
        //     return back()
        //         ->withErrors(["Kapasitas restoran pada rentang jam tersebut sudah hampir penuh (Sisa kapasitas: {$sisa} orang)."])
        //         ->withInput();
        // }

        $overlappingOrang = $this->reservationCapacityUsed(
            $validated['tanggal'],
            $validated['jam_mulai'],
            $validated['jam_selesai']
        );

        if ($overlappingOrang + (int) $validated['jml_org'] > self::RESERVATION_CAPACITY) {
            $sisa = max(0, self::RESERVATION_CAPACITY - $overlappingOrang);

            return back()
                ->withErrors([
                    'kapasitas' => "Kapasitas jadwal tersebut tidak mencukupi. Sisa kapasitas: {$sisa} orang.",
                ])
                ->withInput();
        }

        // 4. Proses Menu & Harga
        $menuQty = collect($validated['menu_qty'] ?? [])
            ->map(fn ($qty) => (int) $qty)
            ->filter(fn ($qty) => $qty > 0)
            ->all();

        $catalogQuote = session('reservation_form_menu_quote', []);
        $selectedMenuIds = array_map('strval', array_keys($menuQty));

        foreach ($selectedMenuIds as $menuId) {
            if (!isset($catalogQuote[$menuId])) {
                return back()
                    ->withErrors(['menu' => 'Pilihan menu sudah kedaluwarsa. Muat ulang form dan pilih menu kembali.'])
                    ->withInput();
            }
        }

        // Snapshot ini adalah harga saat menu ditampilkan, bukan harga terbaru dari DB.
        $menuSnapshot = [];
        $totalHargaMenu = 0;

        foreach ($menuQty as $menuId => $qty) {
            $snapshot = $catalogQuote[(string) $menuId];
            $menuSnapshot[(string) $menuId] = $snapshot;
            $totalHargaMenu += (int) $snapshot['harga'] * $qty;
        }

        // =========================================================================
        // KONDISI 2 (AKTIF): WAJIB PESAN MENU MINIMAL Rp 50.000 SAAT BOOKING
        // =========================================================================
        if ($totalHargaMenu < 50000) {
            return back()
                ->withErrors(['menu' => 'Minimal total pemesanan menu adalah Rp 50.000 untuk dapat melanjutkan reservasi.'])
                ->withInput();
        }

        /*
        // =========================================================================
        // KONDISI 1 (KOMENTAR): BEBAS PESAN MENU NANTI DI LOKASI, DP TETAP Rp 50.000
        // =========================================================================
        // Jika Anda ingin mengubah sistem ke Kondisi 1, berikan tanda komentar (//) 
        // pada 3 baris kode KONDISI 2 di atas. Sistem akan otomatis membiarkan 
        // form tersubmit meskipun $totalHargaMenu bernilai 0.
        */

        $menuQty = array_filter($validated['menu_qty'] ?? [], fn($qty) => (int) $qty > 0);

        session()->put('reservation_draft', [
            'nama'        => $validated['nama'],
            'nomor_telp'  => $validated['nomor_telp'],
            'tanggal'     => $validated['tanggal'],
            'jam_mulai'   => $validated['jam_mulai'],
            'jam_selesai' => $validated['jam_selesai'],
            'jml_org'     => $validated['jml_org'],
            'keterangan'  => $validated['keterangan'] ?? null,
            'menu_qty' => $menuQty,
            'menu_notes' => $validated['menu_notes'] ?? [],
            'menu_snapshot' => $menuSnapshot,
        ]);

        return redirect()->route('customer.reservasi.payment');
    }

    // TAHAP 2: REVIEW (CHECKOUT) SEBELUM BAYAR
    public function reservasiPayment()
    {
        $draft = session('reservation_draft');

        if (!$draft) {
            return redirect()->route('customer.reservasi.form')
                ->with('error', 'Silakan isi form reservasi terlebih dahulu.');
        }

        // Konversi draft array ke object agar view bisa pakai $draft->nama, $draft->tanggal, dst.
        $draftObj = (object) $draft;

        // Data menu dari draft
        $menuItems = [];
        $totalHargaMenu = 0;
        $hasMenuChanges = false;
        $menuChangeMessages = [];

        $overlappingOrang = $this->reservationCapacityUsed(
            $draft['tanggal'],
            $draft['jam_mulai'],
            $draft['jam_selesai']
        );

        if ($overlappingOrang + (int) $draft['jml_org'] > self::RESERVATION_CAPACITY) {
            $menuChangeMessages[] =
                'Kapasitas jadwal tersebut sudah tidak mencukupi. Silakan pilih jadwal lain.';
        }

        $quoteReview = app(MenuQuoteService::class)->review(
            $this->reservationQuoteLines($draft),
            true
        );

        $menuItems = $quoteReview['items'];
        $totalHargaMenu = $quoteReview['total'];
        $menuChangeMessages = array_values(array_unique(array_merge(
            $menuChangeMessages,
            $quoteReview['messages']
        )));
        $hasMenuChanges = count($menuChangeMessages) > 0;

        if ($totalHargaMenu < 50000) {
            $hasMenuChanges = true;
            $menuChangeMessages[] = 'Total menu reservasi harus minimal Rp 50.000.';
        }

        // Cek apakah customer sudah pernah membuat reservasi yang sama dan masih Pending
        // $existingReservasiId = null;
        // $customer = Customer::where('nomor_telp', $draft['nomor_telp'])->first();
        // if ($customer) {
        //     $existing = Reservasi::where('id_customer', $customer->id)
        //         ->whereDate('tanggal', $draft['tanggal'])
        //         ->where('jam_mulai', $draft['jam_mulai'])
        //         ->whereHas('pesanan', function($q){
        //             $q->where('status', 'Pending');
        //         })
        //         ->where('created_at', '>=', now()->subMinutes(60)) // cari dalam 60 menit terakhir
        //         ->first();
        //     if ($existing) {
        //         $existingReservasiId = $existing->id;
        //     }
        // }

        $pendingReservasi = $this->findPendingReservationForPhone($draft['nomor_telp']);

        if ($pendingReservasi) {
            $this->expireUnpaidReservation($pendingReservasi);
            $pendingReservasi->refresh();

            if (strtolower(trim((string) $pendingReservasi->pesanan?->status)) !== 'pending') {
                $pendingReservasi = null;
            }
        }

        return view('customer.reservasi_payment', compact(
            'draftObj',
            'menuItems',
            'totalHargaMenu',
            // 'pb',
            // 'totalBayar',
            // 'totalDP',
            // 'sisaTagihan',
            // 'existingReservasiId', 
            'hasMenuChanges', 
            'menuChangeMessages',
            'pendingReservasi'
        ));
    }

    // TAHAP 3: EKSEKUSI (SIMPAN DB + DAPATKAN QRIS MIDTRANS)
    public function createReservationTransaction(Request $request)
    {
        $draft = session('reservation_draft');
        if (!$draft) {
            return redirect()->route('customer.reservasi.form')
                ->with('error', 'Data reservasi tidak ditemukan. Silakan ulangi form.');
        }
        
        // $menuQty = collect($draft['menu_qty'] ?? [])
        //     ->map(fn ($qty) => (int) $qty)
        //     ->filter(fn ($qty) => $qty > 0)
        //     ->all();

        // $menuSnapshot = $draft['menu_snapshot'] ?? null;

        // if (!is_array($menuSnapshot)) {
        //     return redirect()
        //         ->route('customer.reservasi.payment')
        //         ->with('error', 'Harga menu belum dapat diverifikasi. Silakan kembali ke form dan pilih menu lagi.');
        // }

        // $menusDb = Menu::whereIn('id', array_map('intval', array_keys($menuQty)))
        //     ->lockForUpdate()
        //     ->get()
        //     ->keyBy('id');

        // foreach ($menuQty as $menuId => $qty) {
        //     $menu = $menusDb->get($menuId);

        //     if (!$menu || !$menu->is_reservable) {
        //         throw \Illuminate\Validation\ValidationException::withMessages([
        //             'menu' => 'Menu reservasi baru saja tidak tersedia. Silakan periksa ulang pesanan.',
        //         ]);
        //     }

        //     $snapshot = $menuSnapshot[(string) $menuId] ?? null;

        //     if (!$snapshot || (int) round((float) $menu->harga) !== (int) $snapshot['harga']) {
        //         throw \Illuminate\Validation\ValidationException::withMessages([
        //             'menu' => 'Harga menu baru saja berubah. Silakan periksa harga terbaru sebelum membayar.',
        //         ]);
        //     }
        // }

        $menuQty = collect($draft['menu_qty'] ?? [])
            ->map(fn ($qty) => (int) $qty)
            ->filter(fn ($qty) => $qty > 0)
            ->all();

        $menuSnapshot = $draft['menu_snapshot'] ?? [];
        $quoteReview = app(MenuQuoteService::class)->review(
            $this->reservationQuoteLines($draft),
            true
        );

        $menuChangeMessages = $quoteReview['messages'];

        if ($quoteReview['changed']) {
            return redirect()
                ->route('customer.reservasi.payment')
                ->with('error', 'Harga atau status reservable menu berubah. Periksa perubahan sebelum melanjutkan.')
                ->with('menu_change_messages', $menuChangeMessages);
        }

        $totalHargaMenu = $quoteReview['total'];

        if ($totalHargaMenu < 50000) {
            return redirect()
                ->route('customer.reservasi.payment')
                ->with('error', 'Total menu reservasi harus minimal Rp 50.000.');
        }

        $overlappingOrang = $this->reservationCapacityUsed(
            $draft['tanggal'],
            $draft['jam_mulai'],
            $draft['jam_selesai']
        );

        if ($overlappingOrang + (int) $draft['jml_org'] > self::RESERVATION_CAPACITY) {
            return redirect()
                ->route('customer.reservasi.payment')
                ->with('error', 'Kapasitas jadwal tersebut sudah penuh. Silakan kembali dan pilih jadwal lain.');
        }

        $totalHargaMenu = 0;

        $lines = [];

        foreach ($menuQty as $menuId => $qty) {
            $lines[] = [
                'id' => $menuId,
                'qty' => $qty,
                'notes' => $draft['menu_notes'][$menuId] ?? null,
                'snapshot' => $menuSnapshot[(string) $menuId] ?? null,
            ];
        }

        $quoteReview = app(MenuQuoteService::class)->review($lines, true);

        if ($quoteReview['changed']) {
            return redirect()
                ->route('customer.reservasi.payment')
                ->with('error', 'Harga atau ketersediaan menu berubah. Periksa perubahan sebelum melanjutkan.')
                ->with('menu_change_messages', $quoteReview['messages']);
        }

        $totalHargaMenu = $quoteReview['total'];
        // 1. Simpan DB (Karena pelanggan klik Pay Now)
        // $customer = Customer::firstOrCreate(['nomor_telp' => $draft['nomor_telp']], ['nama' => $draft['nama']]);   
        $hasChanges = false;
        
        // --- PENGECEKAN RACE CONDITION (DETIK TERAKHIR) ---
        $overlappingOrang = Reservasi::whereDate('tanggal', $draft['tanggal'])
            ->where('jam_mulai', '<', $draft['jam_selesai'])
            ->where('jam_selesai', '>', $draft['jam_mulai'])
            ->whereHas('pesanan', function($q) {
                $q->whereNotIn('status', ['Cancelled']); 
            })
            ->sum('jml_org');

        if (($overlappingOrang + $draft['jml_org']) > 88) {
            $hasChanges = true;
        }

        // $menuQty = array_filter($draft['menu_qty'] ?? [], fn ($qty) => (int) $qty > 0);
        // $menusDb = Menu::whereIn('id', array_keys($menuQty))->get()->keyBy('id');
        // $totalHargaMenu = 0;
        
        // foreach ($menuQty as $menuId => $qty) {
        //     $menu = $menusDb->get($menuId);
        //     if (!$menu || !$menu->is_reservable) {
        //          $hasChanges = true;
        //          break;
        //     }
        //     $totalHargaMenu += (float) $menu->harga * (int) $qty;
        // }

        // Jika ada selaan/perubahan, TENDANG KEMBALI KE HALAMAN PAYMENT AGAR MUNCUL ALERT
        if ($hasChanges) {
            return redirect()->route('customer.reservasi.payment')
                ->with('error', 'Terjadi perubahan kapasitas kursi atau menu. Silakan periksa peringatan di layar.');
        }
        // ---------------------------------------------------

        if ($totalHargaMenu < 50000) {
            return back()
                ->withErrors(['nominal_dp' => 'Total menu reservasi harus minimal Rp50.000.'])
                ->withInput();
        }

        $validator = Validator::make($request->all(), [
            'nominal_dp' => [
                'required',
                'integer',
                'min:50000',
                'max:' . (int) $totalHargaMenu,
            ],
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $payAmount = (int) $validator->validated()['nominal_dp'];

        $pendingReservasi = $this->findPendingReservationForPhone($draft['nomor_telp']);

        if ($pendingReservasi) {
            $this->expireUnpaidReservation($pendingReservasi);
            $pendingReservasi->refresh();

            if (strtolower(trim((string) $pendingReservasi->pesanan?->status)) === 'pending') {
                return redirect()
                    ->route('customer.reservasi.payment')
                    ->with('error', 'Nomor telepon ini masih memiliki reservasi yang menunggu pembayaran.');
            }
        }

        $customer = Customer::firstOrCreate(
            ['nomor_telp' => $draft['nomor_telp']],
            ['nama' => $draft['nama']]
        );

        $existingReservasi = Reservasi::where('id_customer', $customer->id)
            ->whereDate('tanggal', $draft['tanggal'])
            ->where('jam_mulai', $draft['jam_mulai'])
            ->whereHas('pesanan', fn ($query) => $query->where('status', 'Pending'))
            ->where('created_at', '>=', now()->subMinutes(60))
            ->first();

        if ($existingReservasi) {
            return redirect()->route('customer.reservasi.detail', ['id' => $existingReservasi->id])
                ->with('info', 'Reservasi masih menunggu pembayaran.');
        }

        // $payAmount = (int) $request->input('nominal_dp', 50000);
        if ($payAmount < 50000) return back()->with('error', 'DP minimal Rp 50.000'); // Dimatikan sesuai request
        $midtransOrderId = null;

        $reservasi = DB::transaction(function () use (
            $draft,
            $customer,
            $menuQty,
            $menuSnapshot,
            $totalHargaMenu,
            $payAmount,
            &$midtransOrderId
        ) {
            // Mutex yang sama untuk seluruh proses pembuatan reservasi.
            Meja::query()->orderBy('id')->lockForUpdate()->firstOrFail();

            $menusDb = Menu::whereIn('id', array_map('intval', array_keys($menuQty)))
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            foreach ($menuQty as $menuId => $qty) {
                $menu = $menusDb->get((int) $menuId);
                $snapshot = $menuSnapshot[(string) $menuId] ?? null;

                if (!$menu || !$menu->is_reservable) {
                    throw \Illuminate\Validation\ValidationException::withMessages([
                        'menu' => 'Menu reservasi baru saja tidak tersedia. Periksa menu sebelum membayar.',
                    ]);
                }

                if (
                    !is_array($snapshot)
                    || (int) round((float) $menu->harga) !== (int) ($snapshot['harga'] ?? -1)
                ) {
                    throw \Illuminate\Validation\ValidationException::withMessages([
                        'menu' => "Harga menu {$menu->nama} baru saja berubah. Periksa harga terbaru sebelum membayar.",
                    ]);
                }
            }

            $usedCapacity = $this->reservationCapacityUsed(
                $draft['tanggal'],
                $draft['jam_mulai'],
                $draft['jam_selesai']
            );

            if ($usedCapacity + (int) $draft['jml_org'] > self::RESERVATION_CAPACITY) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'kapasitas' => 'Kapasitas jadwal ini baru saja penuh. Silakan pilih waktu lain.',
                ]);
            }

            $pesanan = Pesanan::create([
                'kode_pesanan' => 'RSV-' . now()->format('md-Hi') . '-' . random_int(1000, 9999),
                'id_user' => null,
                'id_meja' => null,
                'total_harga' => $totalHargaMenu,
                'status' => 'Pending',
            ]);

            $reservasi = Reservasi::create([
                'id_customer' => $customer->id,
                'id_pesanan' => $pesanan->id,
                'tanggal' => $draft['tanggal'],
                'jam_mulai' => $draft['jam_mulai'],
                'jam_selesai' => $draft['jam_selesai'],
                'jml_org' => $draft['jml_org'],
                'keterangan' => $draft['keterangan'] ?? null,
            ]);

            foreach ($menuQty as $menuId => $qty) {
                $menu = $menusDb->get((int) $menuId);
                $qty = (int) $qty;
                $subtotal = (int) round((float) $menu->harga) * $qty;

                DetailPesanan::create([
                    'id_pesanan' => $pesanan->id,
                    'id_menu' => $menu->id,
                    'jumlah' => $qty,
                    'subtotal' => $subtotal,
                    'catatan' => $draft['menu_notes'][$menuId] ?? null,
                ]);
            }

            $midtransOrderId = 'RESERV-' . $reservasi->id . '-' . Str::random(8);

            Pembayaran::create([
                'id_pesanan' => $pesanan->id,
                'jenis' => 'DP',
                'metode' => 'midtrans',
                'nominal' => $payAmount,
                'midtrans_order_id' => $midtransOrderId,
                'status' => 'Pending',
            ]);

            return $reservasi;
        }, 3);

        // forceFill menghindari snap_token tidak tersimpan karena $fillable.
        $payment = $reservasi->pesanan->pembayaran()
            ->where('midtrans_order_id', $midtransOrderId)
            ->firstOrFail();
        try {
            MidtransConfig::$serverKey = config('services.midtrans.server_key')
                ?: env('MIDTRANS_SERVER_KEY');

            $production = config('services.midtrans.is_production');
            if ($production === null) {
                $production = env('MIDTRANS_IS_PRODUCTION', false);
            }

            MidtransConfig::$isProduction = filter_var($production, FILTER_VALIDATE_BOOLEAN);
            MidtransConfig::$isSanitized = true;
            MidtransConfig::$is3ds = true;

            $returnUrl = route('customer.reservasi.detail', ['id' => $reservasi->id]);

            $snapToken = Snap::getSnapToken([
                'transaction_details' => [
                    'order_id' => $midtransOrderId,
                    'gross_amount' => $payAmount,
                ],
                'item_details' => [[
                    'id' => 'dp-' . $reservasi->id,
                    'price' => $payAmount,
                    'quantity' => 1,
                    'name' => 'DP Reservasi',
                ]],
                'customer_details' => [
                    'first_name' => $customer->nama,
                    'phone' => $customer->nomor_telp,
                ],
                'enabled_payments' => ['gopay', 'shopeepay', 'other_qris', 'bank_transfer'],
                'custom_expiry' => [
                    'start_time' => $reservasi->created_at
                        ->copy()
                        ->timezone(config('app.timezone'))
                        ->format('Y-m-d H:i:s O'),
                    'unit' => 'minute',
                    'duration' => 60,
                ],
                'callbacks' => [
                    'finish' => $returnUrl,
                    'unfinish' => $returnUrl,
                    'error' => $returnUrl,
                ],
            ]);

            $payment->forceFill(['snap_token' => $snapToken])->save();

            session()->forget('reservation_draft');

            return redirect()->route('customer.reservasi.detail', ['id' => $reservasi->id]);
        } catch (\Illuminate\Validation\ValidationException $e) {
            $messages = collect($e->errors())->flatten()->all();

            return redirect()
                ->route('customer.reservasi.payment')
                ->with('error', 'Data reservasi berubah. Periksa kembali sebelum melanjutkan.')
                ->with('menu_change_messages', $messages);
        }
    }

    // // Fungsi ini sekarang menjadi SANGAT PENDEK dan BERSIH
    // public function reservasiPayment($id)
    // {
    //     // Ambil data langsung dari Database
    //     $reservasi = Reservasi::with(['customer', 'pesanan.detailPesanan.menu'])->findOrFail($id);
        
    //     $pesanan = $reservasi->pesanan;
        
    //     $totalHargaMenu = $pesanan ? $pesanan->total_harga : 0;
    //     $pb = $pesanan ? $pesanan->pb : 0;
    //     $totalBayar = $pesanan ? $pesanan->total_bayar : 0;
        
    //     $totalDP = 50000;
    //     $sisaTagihan = max(0, $totalBayar - (float)($reservasi->dp_bayar ?? 0));

    //     return view('customer.reservasi_payment', compact(
    //         'reservasi', 'totalHargaMenu', 'pb', 'totalDP', 'totalBayar', 'sisaTagihan'
    //     ));
    // }

    // // Fungsi untuk melempar ke Midtrans
    // public function createReservationTransaction(Request $request)
    // {
    //     $reservasi = Reservasi::with('customer')->findOrFail($request->id_reservasi);
    //     $payAmount = (int) $request->input('nominal_dp', 50000);

    //     if ($payAmount < 50000) {
    //         return redirect()->back()->withErrors(['nominal' => 'Pembayaran DP minimal adalah Rp 50.000.']);
    //     }

    //     MidtransConfig::$serverKey = env('MIDTRANS_SERVER_KEY');
    //     MidtransConfig::$isProduction = env('MIDTRANS_IS_PRODUCTION') === 'true';
    //     MidtransConfig::$isSanitized = true;
    //     MidtransConfig::$is3ds = true;

    //     $orderId = 'RESERV-' . $reservasi->id . '-' . Str::random(5);

    //     $params = [
    //         'transaction_details' => [
    //             'order_id' => $orderId,
    //             'gross_amount' => $payAmount,
    //         ],
    //         'item_details' => [[
    //             'id' => 'RESERV-DP',
    //             'price' => $payAmount,
    //             'quantity' => 1,
    //             'name' => 'DP Reservasi BigBang',
    //         ]],
    //         'customer_details' => [
    //             'first_name' => $reservasi->customer->nama,
    //             'phone' => $reservasi->customer->nomor_telp,
    //         ],
    //         'enabled_payments' => ['gopay', 'shopeepay', 'other_qris', 'bca_va', 'bni_va', 'bri_va'],
    //     ];

    //     // Buat Token dan Simpan
    //     $snapToken = Snap::getSnapToken($params);
    //     $reservasi->pesanan->update(['snap_token' => $snapToken]);

    //     // Langsung arahkan ke Halaman Detail
    //     return redirect()->route('customer.reservasi.detail', ['id' => $reservasi->id]);
    // }

    // Halaman Tujuan Setelah Pelanggan Menutup Pop-up Midtrans
    public function reservasiPaymentSuccess(Request $request)
    {
        $id = $request->query('id'); // Menangkap ID dari parameter URL callbacks Midtrans
        
        if ($id) {
            return redirect()->route('customer.reservasi.detail', ['id' => $id])
                ->with('success', 'Pembayaran sedang diproses. Silakan cek status reservasi Anda secara berkala.');
        }

        return redirect()->route('customer.reservasi.form');
    }

    // public function reservasiPayDp(Request $request, $id)
    // {
    //     $reservasi = Reservasi::findOrFail($id);

    //     // Jangan langsung sukses. Arahkan ke flow Midtrans untuk DP.
    //     return redirect()->route('customer.reservasi.create_transaction', $reservasi->id)
    //         ->with('success', 'Silakan lanjutkan pembayaran DP.');
    // }

    public function reservasiDetail($id)
    {
        $reservasi = Reservasi::with(['pesanan.pembayaran'])
            ->findOrFail($id);

        $this->expireUnpaidReservation($reservasi);

        $reservasi->refresh()->load(['pesanan.pembayaran']);

        // Waktu ini selalu dari reservasi dibuat, bukan dari pembayaran/retry.
        $reservationExpiresAt = $reservasi->created_at
            ->copy()
            ->addHour()
            ->timestamp * 1000;

        $pesanan = $reservasi->pesanan;

        // 1. Ambil tanggal bersih (YYYY-MM-DD)
        $tanggalSaja = \Carbon\Carbon::parse($reservasi->tanggal)->format('Y-m-d');
        // 2. Ambil jam bersih (HH:MM)
        $jamSaja = \Carbon\Carbon::parse($reservasi->jam_mulai)->format('H:i');
        // 3. Gabungkan dan parse total tanpa takut struktur double date atau detik/trailing data
        $jamMulai = \Carbon\Carbon::parse($tanggalSaja . ' ' . $jamSaja);
        // $batasUbah = $jamMulai->copy()->subHour();
        // $totalHargaMenu = $pesanan ? $pesanan->total_harga : 0;
        // $pb = $pesanan ? $pesanan->pb : 0;
        $totalHarga = $pesanan ? (float) ($pesanan->total_harga ?? 0) : 0;
        // $pb = $pesanan ? (float) ($pesanan->pb ?? 0) : 0;
        // $totalBayar = $pesanan ? (float) ($pesanan->total_bayar ?? 0) : 0;
        // $totalBayar = $pesanan ? $pesanan->total_bayar : 0;
        
        // $totalDP = 50000;
        $dpBayar = (float) ($pesanan?->pembayaran()
            ->where('jenis', 'DP')
            ->where('status', 'Success')
            ->sum('nominal') ?? 0);
        $sisaTagihan = max(0, (float) ($pesanan?->total_harga ?? 0) - $dpBayar);
        $bisaUbahMenu = $pesanan && strtolower($pesanan->status) === 'pending';
        $nominalDp = (int) ($pesanan?->pembayaran()
            ->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
            ->whereRaw("LOWER(TRIM(status)) = 'pending'")
            ->latest('id')
            ->value('nominal') ?? 50000);

        // Menu open ATAU (menu closed tapi reservable)
        // $menus = Menu::where('status', 'open')
        //             ->orWhere('is_reservable', true)
        //             ->orderByDesc('is_bestseller')
        //             ->get();
        $menus = Menu::Where('is_reservable', true)
                    ->orderByDesc('is_bestseller')
                    ->get();

        // $snapToken = $pesanan?->pembayaran
        //     ->where('jenis', 'DP')
        //     ->where('status', 'Pending')
        //     ->sortByDesc('id')
        //     ->first()?->snap_token;

        $paymentDp = $pesanan?->pembayaran()
            ->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
            ->latest('id')
            ->first();

        $paymentStatus = strtolower(trim((string) ($paymentDp?->status ?? '')));
        $snapToken = $paymentStatus === 'pending'
            ? $paymentDp?->snap_token
            : null;
        
        // Tombol retry muncul untuk pembayaran gagal atau token belum berhasil disiapkan.
        $canRetryPayment = strtolower(trim((string) ($pesanan?->status ?? ''))) === 'pending'
            && (!$paymentDp || $paymentStatus === 'failed' || !$paymentDp->snap_token);
            
        $returnUrl = route('customer.reservasi.detail', ['id' => $reservasi->id]);

        return view('customer.reservasi_detail', 
            compact('reservasi', 
            'snapToken', 
            'returnUrl',
            'bisaUbahMenu', 
            'pesanan', 
            'sisaTagihan', 
            'menus', 
            'totalHarga',
            'nominalDp',
            'canRetryPayment',
            'reservationExpiresAt'
            )); 
            // 'pb', 
            // 'totalBayar'));
    }

    public function reservasiUpdateMenu(Request $request, $id)
    {
        $validated = $request->validate([
            'menu_qty' => ['nullable', 'array'],
            'menu_qty.*' => ['nullable', 'integer', 'min:0', 'max:100'],
            'menu_notes' => ['nullable', 'array'],
            'menu_notes.*' => ['nullable', 'string', 'max:200'],
        ]);

        return DB::transaction(function () use ($id, $validated) {
            $reservasi = Reservasi::whereKey($id)
                ->lockForUpdate()
                ->firstOrFail();

            $pesanan = Pesanan::whereKey($reservasi->id_pesanan)
                ->lockForUpdate()
                ->firstOrFail();

            if (strtolower(trim((string) $pesanan->status)) !== 'pending') {
                return back()->with('error', 'Menu hanya dapat diubah sebelum DP dibayar.');
            }

            $dpPayment = $pesanan->pembayaran()
                ->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
                ->whereRaw("LOWER(TRIM(status)) = 'pending'")
                ->latest('id')
                ->lockForUpdate()
                ->first();

            if (!$dpPayment) {
                return back()->with('error', 'Pembayaran DP pending tidak ditemukan; menu tidak dapat diubah.');
            }

            $activeMenuQty = collect($validated['menu_qty'] ?? [])
                ->map(fn ($qty) => (int) $qty)
                ->filter(fn ($qty) => $qty > 0)
                ->all();

            $menuIds = array_map('intval', array_keys($activeMenuQty));
            $menus = Menu::whereIn('id', $menuIds)
                ->where('is_reservable', true)
                ->get()
                ->keyBy('id');

            if ($menus->count() !== count($menuIds)) {
                return back()->withErrors(['menu' => 'Ada menu reservasi yang tidak valid.'])->withInput();
            }

            $totalHarga = 0;

            foreach ($activeMenuQty as $menuId => $qty) {
                $totalHarga += (int) round((float) $menus->get($menuId)->harga) * $qty;
            }

            $minimumTotal = max(50000, (int) $dpPayment->nominal);

            if ($totalHarga < $minimumTotal) {
                return back()
                    ->withErrors([
                        'menu' => 'Total menu tidak boleh kurang dari DP sebesar Rp '
                            . number_format($minimumTotal, 0, ',', '.') . '.',
                    ])
                    ->withInput();
            }

            DetailPesanan::where('id_pesanan', $pesanan->id)->delete();

            foreach ($activeMenuQty as $menuId => $qty) {
                $menu = $menus->get($menuId);

                DetailPesanan::create([
                    'id_pesanan' => $pesanan->id,
                    'id_menu' => $menuId,
                    'jumlah' => $qty,
                    'subtotal' => (int) round((float) $menu->harga) * $qty,
                    'catatan' => $validated['menu_notes'][$menuId] ?? null,
                ]);
            }

            $pesanan->update(['total_harga' => $totalHarga]);

            return redirect()
                ->route('customer.reservasi.detail', ['id' => $reservasi->id])
                ->with('success', 'Menu pre-order berhasil disesuaikan.');
        });
    }

    private function expireUnpaidReservation(Reservasi $reservasi): void
    {
        $expiresAt = $reservasi->created_at?->copy()->addHour();

        if (!$expiresAt || now()->lt($expiresAt)) {
            return;
        }

        DB::transaction(function () use ($reservasi) {
            $lockedReservation = Reservasi::whereKey($reservasi->id)
                ->lockForUpdate()
                ->first();

            if (!$lockedReservation) {
                return;
            }

            $order = Pesanan::whereKey($lockedReservation->id_pesanan)
                ->lockForUpdate()
                ->first();

            // Hanya batalkan pesanan yang masih menunggu pembayaran.
            if (!$order || strtolower(trim((string) $order->status)) !== 'pending') {
                return;
            }

            $hasSuccessfulDp = $order->pembayaran()
                ->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
                ->whereRaw("LOWER(TRIM(status)) = 'success'")
                ->exists();

            if ($hasSuccessfulDp) {
                return;
            }

            $order->update(['status' => 'Cancelled']);

            // Pembayaran pending, termasuk percobaan ulang, ditutup bersama pesanan.
            $order->pembayaran()
                ->whereRaw("LOWER(TRIM(status)) = 'pending'")
                ->update(['status' => 'Failed']);
        }, 3);
    }

    public function cancelPendingReservation(Request $request, int $id)
    {
        $draft = session('reservation_draft');

        if (!$draft || empty($draft['nomor_telp'])) {
            return redirect()->route('customer.reservasi.form')
                ->with('error', 'Sesi reservasi tidak ditemukan. Silakan mulai kembali.');
        }

        $reservasi = Reservasi::with(['customer', 'pesanan.pembayaran'])->findOrFail($id);

        if (
            !$reservasi->customer
            || (string) $reservasi->customer->nomor_telp !== (string) $draft['nomor_telp']
        ) {
            abort(403);
        }

        $this->expireUnpaidReservation($reservasi);
        $reservasi->refresh()->load('pesanan.pembayaran');

        if (strtolower(trim((string) $reservasi->pesanan?->status)) !== 'pending') {
            return redirect()->route('customer.reservasi.payment')
                ->with('error', 'Reservasi tersebut tidak lagi berstatus menunggu pembayaran.');
        }

        try {
            MidtransConfig::$serverKey = config('services.midtrans.server_key')
                ?: env('MIDTRANS_SERVER_KEY');

            $production = config('services.midtrans.is_production')
                ?? env('MIDTRANS_IS_PRODUCTION', false);

            MidtransConfig::$isProduction = filter_var($production, FILTER_VALIDATE_BOOLEAN);
            MidtransConfig::$isSanitized = true;
            MidtransConfig::$is3ds = true;

            foreach ($reservasi->pesanan->pembayaran as $payment) {
                if (
                    strtolower(trim((string) $payment->status)) === 'pending'
                    && $payment->midtrans_order_id
                ) {
                    Transaction::cancel($payment->midtrans_order_id);
                }
            }
        } catch (\Throwable $e) {
            Log::warning('Gagal membatalkan transaksi Midtrans reservasi.', [
                'reservasi_id' => $reservasi->id,
                'error' => $e->getMessage(),
            ]);

            return redirect()->route('customer.reservasi.payment')
                ->with('error', 'Pembayaran lama belum dapat dibatalkan. Buka detail reservasi lama untuk melanjutkan pembayaran.');
        }

        DB::transaction(function () use ($reservasi) {
            $lockedReservation = Reservasi::whereKey($reservasi->id)
                ->lockForUpdate()
                ->firstOrFail();

            $order = Pesanan::whereKey($lockedReservation->id_pesanan)
                ->lockForUpdate()
                ->firstOrFail();

            $hasSuccessfulDp = $order->pembayaran()
                ->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
                ->whereRaw("LOWER(TRIM(status)) = 'success'")
                ->exists();

            if ($hasSuccessfulDp || strtolower(trim((string) $order->status)) !== 'pending') {
                return;
            }

            $order->update(['status' => 'Cancelled']);
            $order->pembayaran()
                ->whereRaw("LOWER(TRIM(status)) = 'pending'")
                ->update(['status' => 'Failed']);
        }, 3);

        return redirect()->route('customer.reservasi.payment')
            ->with('success', 'Reservasi lama berhasil dibatalkan. Anda dapat melanjutkan reservasi baru.');
    }

    public function changeReservationPayment(int $id)
    {
        $reservasi = Reservasi::with(['customer', 'pesanan.pembayaran'])
            ->findOrFail($id);

        $expiresAt = $reservasi->created_at->copy()->addHour();

        if (now()->greaterThanOrEqualTo($expiresAt)) {
            $this->expireUnpaidReservation($reservasi);

            return redirect()
                ->route('customer.reservasi.detail', ['id' => $id])
                ->with('error', 'Waktu pembayaran reservasi telah habis.');
        }

        $order = $reservasi->pesanan;

        if (!$order || strtolower(trim((string) $order->status)) !== 'pending') {
            return redirect()
                ->route('customer.reservasi.detail', ['id' => $id])
                ->with('error', 'Reservasi ini tidak lagi menunggu pembayaran.');
        }

        $oldPayment = $order->pembayaran()
            ->whereRaw("LOWER(TRIM(jenis)) = 'dp'")
            ->latest('id')
            ->first();

        if (!$oldPayment) {
            return redirect()
                ->route('customer.reservasi.detail', ['id' => $id])
                ->with('error', 'Tagihan DP tidak ditemukan.');
        }

        MidtransConfig::$serverKey = config('services.midtrans.server_key')
            ?: env('MIDTRANS_SERVER_KEY');

        $production = config('services.midtrans.is_production')
            ?? env('MIDTRANS_IS_PRODUCTION', false);

        MidtransConfig::$isProduction = filter_var($production, FILTER_VALIDATE_BOOLEAN);
        MidtransConfig::$isSanitized = true;
        MidtransConfig::$is3ds = true;

        // Periksa status transaksi Midtrans terlebih dahulu jika status lokal masih pending.
        if (strtolower(trim((string) $oldPayment->status)) === 'pending') {
            try {
                $midtransStatus = Transaction::status($oldPayment->midtrans_order_id);
                $remoteStatus = strtolower((string) ($midtransStatus->transaction_status ?? ''));

                if (in_array($remoteStatus, ['settlement', 'capture'], true)) {
                    $oldPayment->update(['status' => 'Success']);
                    $order->update(['status' => 'Reserved']);

                    return redirect()
                        ->route('customer.reservasi.detail', ['id' => $id])
                        ->with('success', 'Pembayaran DP sudah berhasil.');
                }

                if (!in_array($remoteStatus, ['expire', 'cancel', 'deny'], true)) {
                    return redirect()
                        ->route('customer.reservasi.detail', ['id' => $id])
                        ->with('error', 'Tagihan masih aktif. Lanjutkan pembayaran dari halaman detail reservasi.');
                }

                $oldPayment->update(['status' => 'Failed']);
            } catch (\Throwable $e) {
                Log::warning('Gagal memeriksa status pembayaran reservasi di Midtrans.', [
                    'reservasi_id' => $id,
                    'error' => $e->getMessage(),
                ]);

                return redirect()
                    ->route('customer.reservasi.detail', ['id' => $id])
                    ->with('error', 'Status pembayaran belum dapat diverifikasi. Coba lagi sebentar.');
            }
        }

        if (strtolower(trim((string) $oldPayment->fresh()->status)) !== 'failed') {
            return redirect()
                ->route('customer.reservasi.detail', ['id' => $id])
                ->with('error', 'Tagihan belum berstatus gagal; tagihan baru tidak dibuat.');
        }

        $newOrderId = 'RESERV-' . $reservasi->id . '-' . Str::random(8);

        $newPayment = DB::transaction(function () use ($order, $oldPayment, $newOrderId) {
            $lockedOrder = Pesanan::whereKey($order->id)
                ->lockForUpdate()
                ->firstOrFail();

            $lockedOldPayment = Pembayaran::whereKey($oldPayment->id)
                ->lockForUpdate()
                ->firstOrFail();

            if (
                strtolower(trim((string) $lockedOrder->status)) !== 'pending'
                || strtolower(trim((string) $lockedOldPayment->status)) !== 'failed'
            ) {
                throw \Illuminate\Validation\ValidationException::withMessages([
                    'payment' => 'Status reservasi atau tagihan berubah. Muat ulang halaman.',
                ]);
            }

            return Pembayaran::create([
                'id_pesanan' => $lockedOrder->id,
                'jenis' => 'DP',
                'metode' => 'midtrans',
                'nominal' => (int) $lockedOldPayment->nominal,
                'midtrans_order_id' => $newOrderId,
                'status' => 'Pending',
            ]);
        });

        try {
            $returnUrl = route('customer.reservasi.detail', ['id' => $id]);
            $amount = (int) $newPayment->nominal;

            $snapToken = Snap::getSnapToken([
                'transaction_details' => [
                    'order_id' => $newOrderId,
                    'gross_amount' => $amount,
                ],
                'item_details' => [[
                    'id' => 'dp-' . $reservasi->id,
                    'price' => $amount,
                    'quantity' => 1,
                    'name' => 'DP Reservasi',
                ]],
                'customer_details' => [
                    'first_name' => $reservasi->customer->nama,
                    'phone' => $reservasi->customer->nomor_telp,
                ],
                'enabled_payments' => ['gopay', 'shopeepay', 'other_qris', 'bank_transfer'],
                'custom_expiry' => [
                    'start_time' => $reservasi->created_at
                        ->copy()
                        ->timezone(config('app.timezone'))
                        ->format('Y-m-d H:i:s O'),
                    'unit' => 'minute',
                    'duration' => 60,
                ],
                'callbacks' => [
                    'finish' => $returnUrl,
                    'unfinish' => $returnUrl,
                    'error' => $returnUrl,
                ],
            ]);

            $newPayment->forceFill(['snap_token' => $snapToken])->save();

            return redirect()->route('customer.reservasi.detail', ['id' => $id])
                ->with('success', 'Tagihan baru berhasil dibuat. Silakan pilih metode pembayaran.');
        } catch (\Throwable $e) {
            $newPayment->update(['status' => 'Failed']);

            Log::error('Gagal membuat tagihan pembayaran reservasi baru.', [
                'reservasi_id' => $id,
                'payment_id' => $newPayment->id,
                'error' => $e->getMessage(),
            ]);

            return redirect()->route('customer.reservasi.detail', ['id' => $id])
                ->with('error', 'Tagihan baru gagal dibuat. Silakan coba kembali sebelum waktu habis.');
        }
    }
}
