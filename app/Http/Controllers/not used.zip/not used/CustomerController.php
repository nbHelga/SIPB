<?php

namespace App\Http\Controllers;

use Midtrans\Snap;
use Midtrans\Config as MidtransConfig;
use Illuminate\Support\Str;
use Midtrans\Notification;
use App\Models\Menu;
use App\Models\Pesanan;
use App\Models\DetailPesanan;
use App\Models\Reservasi;
use App\Models\Customer;
use App\Models\DetailReservasi;
use App\Models\Meja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    // LANDING PAGE
    public function landing()
    {
        $menuTerbaru = Menu::where('status', 'open')->latest()->take(3)->get();
        $menus = Menu::where('status', 'open')->get();
        return view('landing_page', compact('menuTerbaru', 'menus'));
    }

    // METHOD BARU UNTUK PENGECEKAN KETERSEDIAAN
    public function cekKetersediaan(Request $request)
    {
        $request->validate([
            'tanggal' => 'required|date|after_or_equal:today',
            'jam_mulai' => 'required',
            'jam_selesai' => 'required|after:jam_mulai',
            'jml_org' => 'required|integer|min:1',
        ]);

        $tanggal = $request->tanggal;
        $jamMulai = $request->jam_mulai;
        $jamSelesai = $request->jam_selesai;
        $jumlahOrang = (int) $request->jml_org;

        // 1. Hitung total kapasitas meja yang dimiliki restoran
        // Asumsi: Jika ada tabel 'tables', hitung total kapasitas / jumlah meja
        // Atau set kapasitas maksimum per sesi jam (contoh: total 10 meja / 40 kursi)
        $totalKapasitasKursi = 160; // Sesuaikan logika meja Anda

        // 2. Hitung jumlah orang/meja yang sudah ter-reservasi di tanggal & rentang jam tersebut
        $terpakai = Reservasi::where('tanggal', $tanggal)
            ->whereHas('pesanan', function($qp) {
                        $qp->whereIn('status', ['Pending', 'Reserved', 'Confirmed']);
                    }) // Sesuaikan status reservasi aktif
            ->where(function ($query) use ($jamMulai, $jamSelesai) {
                // Pengecekan bentrok jam (overlapping time)
                $query->whereBetween('jam_mulai', [$jamMulai, $jamSelesai])
                      ->orWhereBetween('jam_selesai', [$jamMulai, $jamSelesai])
                      ->orWhere(function ($q) use ($jamMulai, $jamSelesai) {
                          $q->where('jam_mulai', '<=', $jamMulai)
                            ->where('jam_selesai', '>=', $jamSelesai);
                      });
            })
            ->sum('jml_org');

        $sisaKapasitas = $totalKapasitasKursi - $terpakai;

        // 3. Evaluasi
        if ($sisaKapasitas < $jumlahOrang) {
            return response()->json([
                'status' => 'error',
                'message' => 'Maaf, meja/kapasitas untuk jam dan tanggal tersebut sudah penuh atau tidak mencukupi (Sisa kapasitas: ' . max(0, $sisaKapasitas) . ' orang).'
            ], 422);
        }

        // Jika lolos, kirim URL redirect ke form reservasi
        $redirectUrl = route('customer.reservasi.form', [
            'tanggal' => $tanggal,
            'jam_mulai' => $jamMulai,
            'jam_selesai' => $jamSelesai,
            'jml_org' => $jumlahOrang,
        ]);

        return response()->json([
            'status' => 'success',
            'redirect_url' => $redirectUrl
        ]);
    }

    // SELF ORDER — support QR scan via ?nomor_meja=XXX
    public function selfOrder(Request $request)
    {
        $nomorMeja = $request->query('nomor_meja') ?? session('nomor_meja');
        if ($nomorMeja) {
            session(['nomor_meja' => $nomorMeja]);
        }
        $tables = Meja::where('nomor_meja', $nomorMeja)->first();
        $menus = Menu::where('status', 'open')->get();
        $categories = Menu::where('status', 'open')->distinct()->orderBy('kategori')->pluck('kategori');
        return view('customer.selforder', compact('menus', 'categories', 'tables'));
    }

    public function menuJson($id)
    {
        $menu = Menu::findOrFail($id);
        return response()->json($menu);
    }

    // Halaman detail menu (halaman terpisah)
    public function menuDetail(Request $request, $id)
    {
        $menu = Menu::findOrFail($id);
        $menus = Menu::where('status', 'open')->get();
        $categories = Menu::where('status', 'open')->distinct()->orderBy('kategori')->pluck('kategori');
        // $nomorMeja = $request->query('nomor_meja')
        $nomorMeja = $request->query('nomor_meja') ?? session('nomor_meja');
        if ($nomorMeja) {
            session(['nomor_meja' => $nomorMeja]);
        }
        $tables = Meja::where('nomor_meja', $nomorMeja)->first();
        return view('customer.menu_detail', compact('menu', 'menus', 'categories', 'tables'));
    }

    // CART
    public function cart(Request $request)
    {
        $nomorMeja = $request->query('nomor_meja') ?? session('nomor_meja');
        if ($nomorMeja) {
            session(['nomor_meja' => $nomorMeja]);
        }
        $tables = Meja::where('nomor_meja', $nomorMeja)->first();
        $cartItems = session('cart', []);
        $selectedItems = array_keys($cartItems);
        $totalHarga = 0;
        foreach ($cartItems as $item) {
            $totalHarga += $item['subtotal'];
        }
        return view('customer.cart', compact('cartItems', 'selectedItems', 'totalHarga', 'tables'));
    }

    public function cartAdd(Request $request)
    {
        $request->validate([
            'id_menu' => 'required|exists:menu,id',
            'jumlah' => 'required|integer|min:1',
            'catatan' => 'nullable|string|max:255',
        ]);

        $menu = Menu::findOrFail($request->id_menu);
        $cart = session('cart', []);
        
        // FIX: Ambil dari $request->catatan, bukan $request->menu->catatan
        $catatan = trim($request->input('catatan', ''));

        // Hash key agar item menu sama dengan catatan beda tersimpan terpisah
        $key = 'menu_' . $menu->id . ($catatan !== '' ? '_' . md5($catatan) : '');

        if (isset($cart[$key])) {
            $cart[$key]['jumlah'] += $request->jumlah;
            $cart[$key]['subtotal'] = $cart[$key]['jumlah'] * $menu->harga;
            if (!empty($catatan)) {
                $cart[$key]['catatan'] = $catatan;
            }
        } else {
            $cart[$key] = [
                'id_menu'  => $menu->id,
                'menu'     => $menu,
                'jumlah'   => $request->jumlah,
                'subtotal' => $request->jumlah * $menu->harga,
                'catatan'  => $catatan, // Disimpan ke session cart
            ];
        }

        session(['cart' => $cart]);
        session(['cart_count' => count($cart)]);

        $redirect = $request->input('redirect', route('customer.selforder', ['nomor_meja' => session('nomor_meja')]));
        return redirect($redirect)->with('success', 'Menu berhasil ditambahkan ke keranjang!');
    }

    public function cartUpdate(Request $request)
    {
        $cart = session()->get('cart', []);
        $key = $request->key;

        if (isset($cart[$key])) {
            if ($request->action === 'update_note') {
                $cart[$key]['catatan'] = $request->catatan;
            } 
            elseif ($request->action === 'update_qty' || $request->has('jumlah')) {
                $jumlah = max(1, (int) $request->jumlah);
                $cart[$key]['jumlah'] = $jumlah;
                $cart[$key]['subtotal'] = $jumlah * $cart[$key]['menu']['harga'];
            }

            session()->put('cart', $cart);
        }

        return redirect()->back()->with('success', 'Keranjang berhasil diperbarui!');
    }

    public function cartRemove(Request $request)
    {
        $key = $request->key;
        $cart = session('cart', []);
        unset($cart[$key]);
        session(['cart' => $cart]);
        session(['cart_count' => count($cart)]);

        return redirect()->route('customer.cart')->with('success', 'Menu berhasil dihapus!');
    }

    // CHECKOUT
    public function checkout(Request $request)
    {
        $nomorMeja = $request->query('nomor_meja') ?? session('nomor_meja');
        if ($nomorMeja) {
            session(['nomor_meja' => $nomorMeja]);
        }
        $tables = Meja::where('nomor_meja', $nomorMeja)->first();
        if (!$tables) {
            return redirect()->route('customer.selforder')->withErrors(['Meja tidak valid atau tidak terdaftar.']);
        }

        // Simpan ID internal meja ke session untuk proses payment nanti
        session(['id_meja' => $tables->id]);

        $cartItems = session('cart', []);
        if (empty($cartItems)) {
            return redirect()->route('customer.cart');
        }

        $totalProduk = 0;
        foreach ($cartItems as $item) {
            $totalProduk += $item['subtotal'];
        }
        $pb = $totalProduk * 0.1;
        $totalHarga = $totalProduk + $pb;

        return view('customer.checkout', compact('cartItems', 'totalProduk', 'pb', 'totalHarga', 'tables'));
    }

    // PAYMENT
    public function payment(Request $request)
    {
        $cartItems = session('cart', []);
        if (empty($cartItems)) {
            return redirect()->route('customer.cart');
        }

        $idMeja = session('id_meja');
        if (!$idMeja) {
            return redirect()->route('customer.cart')->withErrors(['Informasi meja hilang, silahkan scan kembali QR Code meja Anda.']);
        }

        // return DB::transaction(function () use ($cartItems, $idMeja) {
        //     $totalProduk = 0;
        //     foreach ($cartItems as $item) {
        //         $totalProduk += $item['subtotal'];
        //     }
        //     $pb = round($totalProduk * 0.1);
        //     $totalHarga = $totalProduk + $pb;

        //     // Format: SOD-YYYYMMDD-XXXX
        //     $kodePesanan = 'SOD-' . now()->format('Ymd') . '-' . strtoupper(Str::random(4));

        //     // FIX: Hapus atribut 'catatan' karena sudah dipindah ke DetailPesanan
        //     $pesanan = Pesanan::create([
        //         'kode_pesanan' => $kodePesanan,
        //         'id_meja' => $idMeja,
        //         'id_reservasi' => null,
        //         // 'tanggal_pesanan' => now(),
        //         'total_harga' => $totalHarga,
        //         'status' => 'Paid',
        //         'metode_pembayaran' => 'Midtrans',
        //     ]);

        //     // Simpan catatan per-menu di atribut catatan
        //     foreach ($cartItems as $item) {
        //         DetailPesanan::create([
        //             'id_pesanan' => $pesanan->id,
        //             'id_menu' => $item['menu']['id'],
        //             'jumlah' => $item['jumlah'],
        //             'subtotal' => $item['subtotal'],
        //             'catatan' => $item['catatan'] ?? null,
        //         ]);
        //     }

        //     session()->forget(['cart', 'cart_count', 'id_meja']);

        //     // Di sini integrasi payment gateway (Midtrans)
        //     // Alur: 1) Generate Snap token via Midtrans API
        //     //       2) Redirect ke halaman Midtrans Snap
        //     //       3) Setelah bayar, Midtrans callback ke route notification
        //     //       4) Update status jadi 'Paid'
        //     // Untuk sementara, langsung redirect ke halaman sukses

        //     return redirect()->route('customer.order.success', $pesanan->id);
        // });
        return redirect()->route('customer.checkout.create');
    }

    public function createCheckoutTransaction(Request $request)
    {
        // Ambil cart session
        $cart = session()->get('cart', []);
        if (empty($cart)) {
            return redirect()->route('customer.selforder')->with('error', 'Keranjang kosong');
        }

        // Hitung total & item_details
        $items = [];
        $total = 0;

        foreach ($cart as $itemKey => $it) {
            $menu = $it['menu'];
            $qty = (int) $it['jumlah'];
            $harga = (int) $menu['harga'];

            $items[] = [
                'id' => (string) $menu['id'],
                'price' => $harga,
                'quantity' => $qty,
                'name' => $menu['nama'],
            ];

            $total += $harga * $qty;
        }

        // Ambil id_meja dari session
        $idMeja = session('id_meja');

        // Simpan order dengan kolom yang benar: 'status', bukan 'status_pesanan'
        $order = Pesanan::create([
            'kode_pesanan' => 'SOD-' . now()->format('Ymd') . '-' . strtoupper(Str::random(4)),
            'id_user' => auth()->id(),
            'id_meja' => $idMeja,
            'id_reservasi' => null,
            'total_harga' => $total,
            'status' => 'Pending',
            'metode_pembayaran' => 'Midtrans',
        ]);

        foreach ($cart as $itemKey => $it) {
            $menu = $it['menu'];
            DetailPesanan::create([
                'id_pesanan' => $order->id,
                'id_menu' => $menu['id'],
                'jumlah' => (int) $it['jumlah'],
                'subtotal' => (int) $it['subtotal'],
                'catatan' => $it['catatan'] ?? null,
            ]);
        }

        MidtransConfig::$serverKey = env('MIDTRANS_SERVER_KEY');
        MidtransConfig::$isProduction = env('MIDTRANS_IS_PRODUCTION') === 'true';
        MidtransConfig::$isSanitized = true;
        MidtransConfig::$is3ds = true;

        $transactionDetails = [
            'order_id' => 'ORDER-' . $order->id . '-' . Str::random(5),
            'gross_amount' => (int) $total,
        ];

        $customerDetails = [
            'first_name' => auth()->user()->name ?? 'Guest',
            'phone' => auth()->user()->nomor_telp ?? '',
        ];

        $params = [
            'transaction_details' => $transactionDetails,
            'customer_details' => $customerDetails,
            'item_details' => $items,
            
            // 1. KUNCI HANYA METODE PEMBAYARAN QRIS
            'enabled_payments' => [
                'other_qris' 
            ],
            
            // 2. ATUR BATAS WAKTU (EXPIRY) MENJADI 15 MENIT
            'custom_expiry' => [
                'start_time' => date("Y-m-d H:i:s O"),
                'unit' => 'minute',
                'duration'  => 15
            ],
            
            'callbacks' => [
                'finish' => route('customer.order.success', ['id' => $order->id]),
            ],
        ];

        $paymentUrl = Snap::createTransaction($params)->redirect_url;

        return redirect()->away($paymentUrl);
    }

    public function paymentCallback(Request $request)
    {
        $orderId = $request->input('order_id');
        $result = $request->input('result', []);

        if (!$orderId) {
            return response()->json(['success' => false, 'message' => 'Order ID tidak ditemukan.']);
        }

        $pending = session('pending_reservation_payment');

        if ($pending && ($pending['order_id'] ?? null) === $orderId) {
            $status = data_get($result, 'transaction_status', null);

            if (in_array($status, ['capture', 'settlement', 'success'])) {
                $draft = $pending['draft'];
                $customer = Customer::firstOrCreate(
                    ['nomor_telp' => $draft['nomor_telp']],
                    ['nama' => $draft['nama']]
                );

                $reservasi = Reservasi::create([
                    'id_customer' => $customer->id,
                    'tanggal' => $draft['tanggal'],
                    'jam_mulai' => $draft['jam_mulai'],
                    'jam_selesai' => $draft['jam_selesai'],
                    'jml_org' => $draft['jml_org'],
                    'keterangan' => $draft['keterangan'] ?? null,
                    'dp_bayar' => (float) $pending['pay_amount'],
                    'status_notif' => false,
                ]);

                $pesanan = Pesanan::create([
                    'kode_pesanan' => 'RES-' . now()->format('Ymd') . '-' . strtoupper(Str::random(4)),
                    'id_user' => auth()->id(),
                    'id_reservasi' => $reservasi->id,
                    'id_meja' => null,
                    'total_harga' => 0,
                    'status' => 'Reserved',
                    'metode_pembayaran' => 'Midtrans',
                ]);

                $total = 0;
                $menuQty = $draft['menu_qty'] ?? [];
                $menuNotes = $draft['menu_notes'] ?? [];

                if (!empty($menuQty)) {
                    $menuIds = array_keys($menuQty);
                    $menus = Menu::whereIn('id', $menuIds)->get()->keyBy('id');

                    foreach ($menuQty as $menuId => $qty) {
                        $menu = $menus->get($menuId);
                        if (!$menu) continue;

                        $qty = (int) $qty;
                        $subtotal = $menu->harga * $qty;
                        $total += $subtotal;

                        DetailPesanan::create([
                            'id_pesanan' => $pesanan->id,
                            'id_menu' => $menuId,
                            'jumlah' => $qty,
                            'subtotal' => $subtotal,
                            'catatan' => $menuNotes[$menuId] ?? null,
                        ]);
                    }
                }

                $pb = round($total * 0.1);
                $pesanan->update([
                    'total_harga' => $total + $pb,
                ]);

                session()->forget(['reservation_draft', 'pending_reservation_payment']);

                return response()->json([
                    'success' => true,
                    'message' => 'Pembayaran berhasil dan reservasi telah dibuat.',
                    'reservasi_id' => $reservasi->id,
                ]);
            }
        }

        return response()->json(['success' => true, 'message' => 'Menunggu konfirmasi pembayaran.']);
    }

    public function midtransNotification(Request $request)
    {
        MidtransConfig::$serverKey = env('MIDTRANS_SERVER_KEY');
        MidtransConfig::$isProduction = env('MIDTRANS_IS_PRODUCTION') === 'true';

        $notif = new Notification();
        $transactionStatus = $notif->transaction_status;
        $orderIdRaw = $notif->order_id;

        if (preg_match('/ORDER\-(\d+)\-/', $orderIdRaw, $matches)) {
            $localOrderId = (int) $matches[1];
        } else {
            $localOrderId = (int) $orderIdRaw;
        }

        $order = Pesanan::find($localOrderId);

        if (!$order) {
            return response()->json(['status' => 'not_found'], 404);
        }

        if ($transactionStatus === 'capture' || $transactionStatus === 'settlement') {
            $order->status = 'Paid';
        } elseif ($transactionStatus === 'pending') {
            $order->status = 'Pending';
        } elseif (in_array($transactionStatus, ['deny', 'cancel', 'expire'])) {
            $order->status = 'Cancelled';
        }

        $order->save();

        return response()->json(['status' => 'ok']);
    }

    public function orderSuccess($id)
    {
        $pesanan = Pesanan::with('detailPesanan.menu')->findOrFail($id);
        return view('customer.order_success', compact('pesanan'));
    }

    // RESERVASI
    public function reservasiForm(Request $request)
    {
        $menus = Menu::where('status', 'open')->get();

        // Ambil data pre-fill dari query string (jika diisi dari beranda)
        $prefill = [
            'tanggal'     => $request->query('tanggal'),
            'jam_mulai'   => $request->query('jam_mulai'),
            'jam_selesai' => $request->query('jam_selesai'),
            'jml_org'   => $request->query('jml_org'),
        ];

        return view('customer.reservasi', compact('menus', 'prefill'));
    }

    public function reservationMenu()
    {
        $menus = Menu::where('status', 'open')->get();
        $categories = Menu::where('status', 'open')->distinct()->orderBy('kategori')->pluck('kategori');

        return view('customer.reservation_menu', compact('menus', 'categories'));
    }

    public function reservationMenuDetail($id)
    {
        $menu = Menu::findOrFail($id);
        return view('customer.reservation_menu_detail', compact('menu'));
    }

    public function reservasiStore(Request $request)
    {
        $validated = $request->validate([
            'nama'         => 'required|string|min:3|max:100',
            'nomor_telp'   => 'required|string|regex:/^[0-9\+\-\s]{9,20}$/',
            'tanggal'      => 'required|date|after_or_equal:today',
            'jam_mulai'    => 'required|date_format:H:i',
            'jam_selesai'  => 'required|date_format:H:i|after:jam_mulai',
            'jml_org'    => 'required|integer|min:1|max:20',
            'keterangan'   => 'nullable|string|max:500',

            'menu_qty'     => 'nullable|array|max:30',
            'menu_qty.*'   => 'nullable|integer|min:0|max:100',
            'menu_notes'   => 'nullable|array|max:30',
            'menu_notes.*' => 'nullable|string|max:150',
        ], [
            'nomor_telp.regex'   => 'Format nomor telepon tidak valid.',
            'jam_selesai.after'  => 'Jam selesai harus lebih akhir dari jam mulai.',
            'jml_org.max'      => 'Maksimal reservasi adalah untuk 20 orang.',
        ]);

        $menuQty = $validated['menu_qty'] ?? [];
        $activeMenuQty = array_filter($menuQty, fn($qty) => (int) $qty > 0);

        $selectedMenuIds = array_keys($activeMenuQty);

        if (!empty($selectedMenuIds)) {
            $menus = Menu::whereIn('id', $selectedMenuIds)->get()->keyBy('id');
            $totalHargaTemp = 0;

            foreach ($activeMenuQty as $menuId => $qty) {
                $menu = $menus->get($menuId);
                if ($menu) {
                    $totalHargaTemp += $menu->harga * (int) $qty;
                }
            }

            if ($totalHargaTemp < 50000) {
                return back()
                    ->withErrors(['Minimal total pemesanan menu adalah Rp 50.000.'])
                    ->withInput();
            }
        }

        session()->put('reservation_draft', [
            'nama' => $validated['nama'],
            'nomor_telp' => $validated['nomor_telp'],
            'tanggal' => $validated['tanggal'],
            'jam_mulai' => $validated['jam_mulai'],
            'jam_selesai' => $validated['jam_selesai'],
            'jml_org' => $validated['jml_org'],
            'keterangan' => $validated['keterangan'] ?? null,
            'menu_qty' => $activeMenuQty,
            'menu_notes' => $validated['menu_notes'] ?? [],
        ]);

        return redirect()->route('customer.reservasi.payment');
    }

    public function reservasiPayment($id = null)
    {
        // Cek draft di session dulu (flow: user baru submit form, belum bayar)
        $draft = session('reservation_draft');

        if ($draft) {
            // Buat objek pseudo reservasi agar view tetap menerima $reservasi dan looping detailPesanan berjalan
            $reservasi = new \stdClass();
            $reservasi->id = null;
            $reservasi->customer = (object)[
                'nama' => $draft['nama'],
                'nomor_telp' => $draft['nomor_telp'],
            ];
            $reservasi->tanggal = $draft['tanggal'];
            $reservasi->jam_mulai = $draft['jam_mulai'];
            $reservasi->jam_selesai = $draft['jam_selesai'];
            $reservasi->jml_org = $draft['jml_org'];
            $reservasi->keterangan = $draft['keterangan'] ?? null;

            // Build pesanan->detailPesanan collection dari draft menu (agar view menampilkan daftar menu)
            $detailCollection = collect();
            $totalHargaMenu = 0;

            $menuQty = $draft['menu_qty'] ?? [];
            $menuNotes = $draft['menu_notes'] ?? [];

            if (!empty($menuQty)) {
                $menuIds = array_keys($menuQty);
                $menus = \App\Models\Menu::whereIn('id', $menuIds)->get()->keyBy('id');

                foreach ($menuQty as $menuId => $qty) {
                    $menu = $menus->get($menuId);
                    $qty = (int) $qty;
                    if (!$menu || $qty <= 0) continue;

                    $subtotal = $menu->harga * $qty;
                    $totalHargaMenu += $subtotal;

                    $detail = new \stdClass();
                    $detail->jumlah = $qty;
                    $detail->subtotal = $subtotal;
                    $detail->catatan = $menuNotes[$menuId] ?? null;
                    $detail->menu = $menu;

                    $detailCollection->push($detail);
                }
            }

            // Buat property pesanan agar view dapat mengakses $reservasi->pesanan->detailPesanan
            $reservasi->pesanan = new \stdClass();
            $reservasi->pesanan->detailPesanan = $detailCollection;

            $pb = round($totalHargaMenu * 0.1);
            $totalBayar = $totalHargaMenu + $pb;
            $totalDP = 50000;
            $sisaTagihan = max(0, $totalBayar - $totalDP);

            // Kirim juga flag draft supaya view mengetahui ini mode draft
            return view('customer.reservasi_payment', compact(
                'reservasi',
                'totalHargaMenu',
                'pb',
                'totalDP',
                'totalBayar',
                'sisaTagihan'
            ))->with('isDraftReservasi', true);
        }

        // Jika bukan draft: coba ambil dari DB berdasarkan id jika disediakan
        if ($id) {
            $reservasi = \App\Models\Reservasi::with(['customer', 'pesanan.detailPesanan.menu', 'detailReservasi.meja'])->findOrFail($id);
        } else {
            // Jika tidak ada id, coba cek apakah ada pending_reservation_payment session (pop-up Midtrans flow),
            // atau arahkan kembali ke form jika tidak ditemukan.
            $pending = session('pending_reservation_payment');
            if ($pending && isset($pending['draft'])) {
                // fallback: gunakan draft dari pending (mirip branch atas)
                $draft = $pending['draft'];
                // re-use logic: build pseudo $reservasi (singkat)
                $reservasi = new \stdClass();
                $reservasi->id = null;
                $reservasi->customer = (object)[
                    'nama' => $draft['nama'],
                    'nomor_telp' => $draft['nomor_telp'],
                ];
                $reservasi->tanggal = $draft['tanggal'];
                $reservasi->jam_mulai = $draft['jam_mulai'];
                $reservasi->jam_selesai = $draft['jam_selesai'];
                $reservasi->jml_org = $draft['jml_org'];
                $reservasi->keterangan = $draft['keterangan'] ?? null;

                $detailCollection = collect();
                $totalHargaMenu = 0;
                $menuQty = $draft['menu_qty'] ?? [];
                $menuNotes = $draft['menu_notes'] ?? [];

                if (!empty($menuQty)) {
                    $menuIds = array_keys($menuQty);
                    $menus = \App\Models\Menu::whereIn('id', $menuIds)->get()->keyBy('id');

                    foreach ($menuQty as $menuId => $qty) {
                        $menu = $menus->get($menuId);
                        $qty = (int) $qty;
                        if (!$menu || $qty <= 0) continue;

                        $subtotal = $menu->harga * $qty;
                        $totalHargaMenu += $subtotal;

                        $detail = new \stdClass();
                        $detail->jumlah = $qty;
                        $detail->subtotal = $subtotal;
                        $detail->catatan = $menuNotes[$menuId] ?? null;
                        $detail->menu = $menu;

                        $detailCollection->push($detail);
                    }
                }

                $reservasi->pesanan = new \stdClass();
                $reservasi->pesanan->detailPesanan = $detailCollection;

                $pb = round($totalHargaMenu * 0.1);
                $totalBayar = $totalHargaMenu + $pb;
                $totalDP = 50000;
                $sisaTagihan = max(0, $totalBayar - $totalDP);

                return view('customer.reservasi_payment', compact(
                    'reservasi',
                    'totalHargaMenu',
                    'pb',
                    'totalDP',
                    'totalBayar',
                    'sisaTagihan'
                ))->with('isDraftReservasi', true);
            }

            // tidak ada draft dan tidak ada id => redirect ke form
            return redirect()->route('customer.reservasi.form')->with('error', 'Data reservasi tidak ditemukan. Silakan isi formulir reservasi terlebih dahulu.');
        }

        // Jika sampai di sini berarti $reservasi dari DB
        $totalHargaMenu = 0;
        if ($reservasi->pesanan && $reservasi->pesanan->detailPesanan) {
            $totalHargaMenu = $reservasi->pesanan->detailPesanan->sum('subtotal');
        }
        $pb = round($totalHargaMenu * 0.1);
        $totalBayar = $totalHargaMenu + $pb;
        $totalDP = 50000;
        $sisaTagihan = max(0, $totalBayar - (float)($reservasi->dp_bayar ?? 0));

        return view('customer.reservasi_payment', compact(
            'reservasi',
            'totalHargaMenu',
            'pb',
            'totalDP',
            'totalBayar',
            'sisaTagihan'
        ));
    }

    public function createReservationTransaction(Request $request)
    {
        $draft = session('reservation_draft');
        if (!$draft) {
            return redirect()->route('customer.reservasi.form')
                ->with('error', 'Data reservasi tidak ditemukan. Silakan ulangi form reservasi.');
        }

        $payAmount = (int) $request->input('pay_amount', 50000);

        if ($payAmount < 50000) {
            return redirect()->back()->with('error', 'Pembayaran minimal adalah Rp 50.000.');
        }

        $customer = Customer::firstOrCreate(
            ['nomor_telp' => $draft['nomor_telp']],
            ['nama' => $draft['nama']]
        );

        MidtransConfig::$serverKey = env('MIDTRANS_SERVER_KEY');
        MidtransConfig::$isProduction = env('MIDTRANS_IS_PRODUCTION') === 'true';
        MidtransConfig::$isSanitized = true;
        MidtransConfig::$is3ds = true;

        $orderId = 'RESERV-' . now()->timestamp . '-' . Str::random(6);

        session()->put('pending_reservation_payment', [
            'draft' => $draft,
            'customer_id' => $customer->id,
            'pay_amount' => $payAmount,
            'order_id' => $orderId,
        ]);

        $params = [
            'transaction_details' => [
                'order_id' => $orderId,
                'gross_amount' => $payAmount,
            ],
            'item_details' => [[
                'id' => 'RESERV-DP',
                'price' => $payAmount,
                'quantity' => 1,
                'name' => 'Pembayaran DP Reservasi',
            ]],
            'customer_details' => [
                'first_name' => $customer->nama,
                'phone' => $customer->nomor_telp,
            ],
            'enabled_payments' => ['gopay', 'shopeepay', 'other_qris', 'bca_va', 'bni_va', 'bri_va', 'other_va'],
            'callbacks' => [
                'finish' => route('customer.reservasi.payment.success'),
            ],
        ];

        $snap = Snap::createTransaction($params);

        return redirect()->away($snap->redirect_url);
    }

    public function reservasiPaymentSuccess()
    {
        $pending = session('pending_reservation_payment');

        if (!$pending) {
            return redirect()->route('customer.reservasi.form')
                ->with('error', 'Pembayaran reservasi sedang menunggu validasi.');
        }

        $draft = $pending['draft'];
        $customer = Customer::firstOrCreate(
            ['nomor_telp' => $draft['nomor_telp']],
            ['nama' => $draft['nama']]
        );

        $reservasi = Reservasi::create([
            'id_customer' => $customer->id,
            'tanggal' => $draft['tanggal'],
            'jam_mulai' => $draft['jam_mulai'],
            'jam_selesai' => $draft['jam_selesai'],
            'jml_org' => $draft['jml_org'],
            'keterangan' => $draft['keterangan'] ?? null,
            'dp_bayar' => (float) $pending['pay_amount'],
            'status_notif' => false,
        ]);

        $pesanan = Pesanan::create([
            'kode_pesanan' => 'RES-' . now()->format('Ymd') . '-' . strtoupper(Str::random(4)),
            'id_user' => auth()->id(),
            'id_reservasi' => $reservasi->id,
            'id_meja' => null,
            'total_harga' => 0,
            'status' => 'Reserved',
            'metode_pembayaran' => 'Midtrans',
        ]);

        $totalHarga = 0;
        $menuQty = $draft['menu_qty'] ?? [];
        $menuNotes = $draft['menu_notes'] ?? [];

        if (!empty($menuQty)) {
            $menuIds = array_keys($menuQty);
            $menus = Menu::whereIn('id', $menuIds)->get()->keyBy('id');

            foreach ($menuQty as $menuId => $qty) {
                $menu = $menus->get($menuId);
                if (!$menu) continue;

                $qty = (int) $qty;
                $subtotal = $menu->harga * $qty;
                $totalHarga += $subtotal;

                DetailPesanan::create([
                    'id_pesanan' => $pesanan->id,
                    'id_menu' => $menuId,
                    'jumlah' => $qty,
                    'subtotal' => $subtotal,
                    'catatan' => $menuNotes[$menuId] ?? null,
                ]);
            }
        }

        $pb = round($totalHarga * 0.1);
        $pesanan->update([
            'total_harga' => $totalHarga + $pb,
        ]);

        session()->forget(['reservation_draft', 'pending_reservation_payment']);

        return redirect()->route('customer.reservasi.detail', ['id' => $reservasi->id])
            ->with('success', 'Pembayaran berhasil. Reservasi Anda telah dibuat.');
    }

    public function reservasiPayDp(Request $request, $id)
    {
        $reservasi = Reservasi::findOrFail($id);

        // Jangan langsung sukses. Arahkan ke flow Midtrans untuk DP.
        return redirect()->route('customer.reservasi.create_transaction', $reservasi->id)
            ->with('success', 'Silakan lanjutkan pembayaran DP.');
    }

    public function reservasiDetail($id)
    {
        $reservasi = Reservasi::with(['customer', 'detailReservasi.meja', 'pesanan.detailPesanan.menu'])->findOrFail($id);

        // 1. Ambil tanggal bersih (YYYY-MM-DD)
        $tanggalSaja = \Carbon\Carbon::parse($reservasi->tanggal)->format('Y-m-d');

        // 2. Ambil jam bersih (HH:MM)
        $jamSaja = \Carbon\Carbon::parse($reservasi->jam_mulai)->format('H:i');

        // 3. Gabungkan dan parse total tanpa takut struktur double date atau detik/trailing data
        $jamMulai = \Carbon\Carbon::parse($tanggalSaja . ' ' . $jamSaja);
        $batasUbah = $jamMulai->copy()->subHour();

        $bisaUbahMenu = now() < $batasUbah;

        $menus = Menu::where('status', 'open')->get();

        return view('customer.reservasi_detail', compact('reservasi', 'bisaUbahMenu', 'menus'));
    }

    public function reservasiUpdateMenu(Request $request, $id)
    {
        $reservasi = Reservasi::findOrFail($id);

        $tanggalSaja = \Carbon\Carbon::parse($reservasi->tanggal)->format('Y-m-d');
        $jamSaja = \Carbon\Carbon::parse($reservasi->jam_mulai)->format('H:i');
        $jamMulai = \Carbon\Carbon::parse($tanggalSaja . ' ' . $jamSaja);
        
        if (now() >= $jamMulai->subHour()) {
            return back()->withErrors(['Menu tidak dapat diubah karena sudah melewati batas waktu H-1 jam sebelum reservasi dimulai.']);
        }

        $validated = $request->validate([
            'menu_qty' => 'nullable|array',
            'menu_notes' => 'nullable|array',
        ]);

        // Filter hanya menu dengan qty > 0
        $activeMenuQty = array_filter($validated['menu_qty'] ?? [], function($qty) {
            return intval($qty) > 0;
        });

        $selectedMenuIds = array_keys($activeMenuQty);

        // Validasi Minimal Rp 50.000
        if (!empty($selectedMenuIds)) {
            $menus = Menu::whereIn('id', $selectedMenuIds)->get()->keyBy('id');
            $totalHargaTemp = 0;
            foreach ($activeMenuQty as $menuId => $qty) {
                if ($menu = $menus->get($menuId)) {
                    $totalHargaTemp += ($menu->harga * intval($qty));
                }
            }

            if ($totalHargaTemp < 50000) {
                return back()
                    ->withErrors(['Minimal total pemesanan menu adalah Rp 50.000.']);
            }
        }

        $pesanan = Pesanan::where('id_reservasi', $reservasi->id)->first();
        if (!$pesanan) {
            return back()->withErrors(['Invoice pesanan untuk reservasi ini tidak ditemukan.']);
        }

        return DB::transaction(function () use ($validated, $activeMenuQty, $selectedMenuIds, $pesanan, $reservasi) {
            DetailPesanan::where('id_pesanan', $pesanan->id)->delete();

            $totalHarga = 0;

            if (!empty($selectedMenuIds)) {
                $menus = Menu::whereIn('id', $selectedMenuIds)->get()->keyBy('id');

                foreach ($activeMenuQty as $menuId => $qty) {
                    $menu = $menus->get($menuId);
                    if (!$menu) continue;

                    $qty = intval($qty);
                    $catatan = $validated['menu_notes'][$menuId] ?? null;
                    $subtotal = $menu->harga * $qty;
                    $totalHarga += $subtotal;

                    DetailPesanan::create([
                        'id_pesanan' => $pesanan->id,
                        'id_menu' => $menuId,
                        'jumlah' => $qty,
                        'subtotal' => $subtotal,
                        'catatan' => $catatan,
                    ]);
                }
            }

            $pb = round($totalHarga * 0.1);
            // $totalBayar = $totalHarga + $pb;

            $pesanan->update(['total_harga' => $totalHarga]);

            return redirect()->route('customer.reservasi.detail', $reservasi->id)
                ->with('success', 'Menu pre-order berhasil disesuaikan!');
        });
    }
}
