<?php

namespace App\Http\Controllers;

use App\Models\Pesanan;
use App\Models\DetailPesanan;
use App\Models\Menu;
use App\Models\User;
use App\Models\Meja;
use App\Models\Reservasi;
use App\Models\DetailReservasi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AdminController extends Controller
{
    // DASHBOARD
    public function dashboard()
    {
        $totalOrders = Pesanan::count();
        $totalRevenue = Pesanan::where('status', 'completed')->sum('total_harga');
        $totalMenus = Menu::count();
        $totalUsers = User::count();
        $recentOrders = Pesanan::with('user')
            ->orderByDesc('created_at')
            ->limit(10)
            ->get();

        // Data untuk chart (7 hari terakhir)
        $chartLabels = [];
        $chartData = [];

        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i);
            $chartLabels[] = $date->format('d/m');

            $sales = Pesanan::where('status', 'completed')
                ->whereDate('created_at', $date)
                ->sum('total_harga');

            $chartData[] = $sales;
        }

        return view('admin.dashboard', [
            'totalOrders' => $totalOrders,
            'totalRevenue' => $totalRevenue,
            'totalMenus' => $totalMenus,
            'totalUsers' => $totalUsers,
            'recentOrders' => $recentOrders,
            'chartLabels' => $chartLabels,
            'chartData' => $chartData
        ]);
    }

    // Endpoint untuk fetch sales data dengan range yang berbeda
    public function salesData(Request $request)
    {
        $days = $request->get('days', 7);

        $chartLabels = [];
        $chartData = [];

        for ($i = $days - 1; $i >= 0; $i--) {
            $date = now()->subDays($i);
            $chartLabels[] = $date->format('d/m');

            $sales = Pesanan::where('status', 'completed')
                ->whereDate('created_at', $date)
                ->sum('total_harga');

            $chartData[] = $sales ?? 0;
        }

        return response()->json([
            'labels' => $chartLabels,
            'data' => $chartData
        ]);
    }

    // SELF ORDER (Pesanan)
    public function selfOrder(Request $request, $id = null)
    {
        // Ambil ID dari URL route parameter atau query string ?id=...
        $selectedId = $id ?? $request->query('id');

        $query = Pesanan::with(['meja', 'user', 'detailPesanan.menu'])
            ->whereNull('id_reservasi')
            ->whereNotIn('status', ['Pending', 'Reserved'])
            ->orderBy('created_at', 'desc');

        if ($request->search) {
            $query->where(function($q) use ($request) {
                $q->where('id', 'like', '%'.$request->search.'%')
                  ->orWhereHas('meja', function($qMeja) use ($request) {
                  $qMeja->where('nomor_meja', 'like', '%'.$request->search.'%');
                  });
            });
        }

        if ($request->filter && isset($request->filter['status'])) {
            $query->where('status', $request->filter['status']);
        }

        $pesananList = $query->get();

        // $selectedPesanan = $id 
        //     ? Pesanan::with(['meja', 'user', 'detailPesanan.menu'])->find($id) 
        //     : $pesananList->first();
        // HANYA cari data jika ada $selectedId. Jangan default ke ->first()
        $selectedPesanan = $selectedId 
            ? Pesanan::with(['meja', 'user', 'detailPesanan.menu'])->find($selectedId) 
            : null;

        return view('admin.selforder', compact('pesananList', 'selectedPesanan', 'selectedId'));
    }

    public function orderUpdate(Request $request, $id)
    {
        $request->validate(['status' => 'required|in:Paid,Processing,Completed,Cancelled']);
        $pesanan = Pesanan::findOrFail($id);
        $updateData = ['status' => $request->status];

        // Catat ID Admin/Kasir yang memproses pesanan saat status berubah ke processing/completed
        if (in_array($request->status, ['Processing', 'Completed', 'Cancelled']) && Auth::check()) {
            $updateData['id_user'] = Auth::id();
        }
        
        $pesanan->update($updateData);

        return redirect()->route('admin.selforder', $id)->with('success', 'Status pesanan berhasil diupdate!');
    }

    public function orderNota($id)
    {
        $pesanan = Pesanan::with(['meja', 'user', 'detailPesanan.menu'])->findOrFail($id);
        return view('admin.nota', compact('pesanan'));
    }

    // MENU (unchanged)
    public function menu(Request $request)
    {
        $query = Menu::orderBy('kategori')->orderBy('nama');

        if ($request->search) {
            $query->where('nama', 'like', '%'.$request->search.'%');
        }

        if ($request->filter && isset($request->filter['kategori'])) {
            $query->where('kategori', $request->filter['kategori']);
        }

        $menus = $query->paginate(20);
        $kategoriList = Menu::distinct()->orderBy('kategori')->pluck('kategori');

        return view('admin.menu', compact('menus', 'kategoriList'));
    }

    public function menuJson($id)
    {
        return response()->json(Menu::findOrFail($id));
    }

    public function menuStore(Request $request)
    {
        $validated = $request->validate([
            'gambar'     => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048', // Max 2MB
            'nama'       => 'required|string|min:3|max:100',
            'harga'      => 'required|numeric|min:0|max:10000000', // Min Rp500, Max Rp10jt
            'kategori'   => 'required|string|max:50',
            'stok'       => 'nullable|integer|min:0|max:9999',
            'keterangan' => 'nullable|string|max:1000',
            'status'     => 'nullable|in:open,close',
        ], [
            'gambar.max' => 'Ukuran gambar maksimal adalah 2MB.',
        ]);

        $validated['status'] = $request->status === 'open' ? 'open' : 'close';
        $validated['stok'] = $request->stok ?? 0;

        if ($request->hasFile('gambar')) {
            $validated['gambar'] = $request->file('gambar')->store('menu', 'public');
        }

        Menu::create($validated);

        return redirect()->route('admin.menu')->with('success', 'Menu berhasil ditambahkan!');
    }

    public function menuUpdate(Request $request, $id)
    {
        $menu = Menu::findOrFail($id);

        $validated = $request->validate([
            'gambar' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'nama' => 'required|string|min:3|max:100',
            'harga' => 'required|numeric|min:0|max:10000000',
            'kategori' => 'required|string|max:50',
            'stok' => 'nullable|integer|min:0|max:9999',
            'keterangan' => 'nullable|string|max:1000',
            'status' => 'nullable|in:open,close',
        ]);

        $validated['status'] = $request->status === 'open' ? 'open' : 'close';
        $validated['stok'] = $request->stok ?? 0;

        if ($request->hasFile('gambar')) {
            $validated['gambar'] = $request->file('gambar')->store('menu', 'public');
        }

        $menu->update($validated);

        return redirect()->route('admin.menu')->with('success', 'Menu berhasil diupdate!');
    }

    public function menuDelete($id)
    {
        Menu::findOrFail($id)->delete();
        return redirect()->route('admin.menu')->with('success', 'Menu berhasil dihapus!');
    }

    // USER (unchanged)
    public function user(Request $request)//ubah jadi public function index(...)
    {
        $query = User::orderBy('status')->orderBy('username');

        if ($request->search) {
            $query->where('username', 'like', '%'.$request->search.'%');
        }

        if ($request->filter && isset($request->filter['status'])) {
            $query->where('status', $request->filter['status']);
        }

        $users = $query->paginate(20);

        return view('admin.user', compact('users'));
    }

    public function userJson($id)
    {
        $user = User::findOrFail($id);
        $user->makeHidden('password');
        return response()->json($user);
    }

    public function userStore(Request $request)
    {
        $validated = $request->validate([
            'username' => 'required|string|alpha_dash|min:4|max:30|unique:users,username',
            'password' => 'required|string|min:6|max:64',
            'status'   => 'required|in:admin,kasir',
        ], [
            'username.alpha_dash' => 'Username hanya boleh berisi huruf, angka, strip, dan underscore.',
            'username.unique'     => 'Username sudah digunakan.',
            'password.min'        => 'Password minimal terdiri dari 6 karakter.',
        ]);

        User::create([
            'username' => $validated['username'],
            'password' => Hash::make($validated['password']),
            'status' => $validated['status'],
        ]);

        return redirect()->route('admin.user')->with('success', 'User berhasil ditambahkan!');
    }

    public function userUpdate(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $validated = $request->validate([
            'username' => 'required|string|min:4|max:30|unique:users,username,'.$id,
            'password' => 'nullable|string|min:6|max:64',
            'status' => 'required|in:kasir,admin',
        ]);

        $data = [
            'username' => $validated['username'],
            'status' => $validated['status'],
        ];

        if (!empty($validated['password'])) {
            $data['password'] = Hash::make($validated['password']);
        }

        $user->update($data);

        return redirect()->route('admin.user')->with('success', 'User berhasil diupdate!');
    }

    public function userDelete($id)
    {
        if ($id == Auth::id()) {
            return back()->withErrors(['Tidak dapat menghapus akun sendiri.']);
        }
        User::findOrFail($id)->delete();
        return redirect()->route('admin.user')->with('success', 'User berhasil dihapus!');
    }

    // MEJA
    // MEJA
    public function meja(Request $request)
    {
        $today = Carbon::today()->toDateString();

        // 1. Ambil semua meja beserta reservasi aktif hari ini (Eager Loading untuk cegah N+1 Query)
        $allMeja = Meja::with(['detailReservasi.reservasi' => function ($query) use ($today) {
            $query->whereDate('tanggal', $today)
                ->whereHas('pesanan', function ($q) {
                    // Cek status di tabel pesanan (lowercase)
                    $q->whereIn('status', ['confirmed', 'reserved', 'processing']);
                });
        }])->orderBy('lantai')->orderBy('nomor_meja')->get();

        // Injeksi objek reservasiHariIni ke setiap meja dari eager loading
        $allMeja->map(function ($meja) {
            $meja->reservasiHariIni = $meja->detailReservasi
                ->pluck('reservasi')
                ->first();
            return $meja;
        });

        // Grouping untuk denah per lantai
        $denahMeja = $allMeja->groupBy('lantai');
        $lantaiList = $allMeja->pluck('lantai')->unique()->values();

        // 2. Ambil data reservasi Confirmed & dp terbayar (Status berada di tabel pesanan)
        $reservasiConfirmed = Reservasi::with(['customer', 'detailReservasi.meja', 'pesanan.detailPesanan.menu'])
            ->whereHas('pesanan', function ($q) {
                $q->where('status', 'confirmed');
            })
            ->where('dp_bayar', '>=', 50000)
            ->orderBy('tanggal')
            ->orderBy('jam_mulai')
            ->get();

        return view('admin.meja', compact('allMeja', 'denahMeja', 'lantaiList', 'reservasiConfirmed'));
    }

    public function mejaJson($id)
    {
        $meja = Meja::findOrFail($id);

        // Cek apakah ada reservasi untuk tanggal hari ini yang memanfaatkan meja ini
        // Status diambil dari tabel pesanan via whereHas
        $reservasiHariIni = Reservasi::whereDate('tanggal', Carbon::today())
            ->whereHas('pesanan', function ($q) {
                $q->whereIn('status', ['confirmed', 'reserved', 'processing']);
            })
            ->whereHas('detailReservasi', function ($q) use ($meja) {
                $q->where('id_meja', $meja->id);
            })
            ->with(['pesanan.detailPesanan.menu', 'customer'])
            ->first();

        if ($reservasiHariIni) {
            $pesanan = $reservasiHariIni->pesanan;
            $menuDipesan = [];

            if ($pesanan && $pesanan->detailPesanan) {
                $menuDipesan = $pesanan->detailPesanan->map(function ($dp) {
                    return [
                        'nama' => $dp->menu->nama ?? '-',
                        'jumlah' => $dp->jumlah,
                    ];
                });
            }

            $meja->reservasi_aktif = [
                'id_reservasi' => $reservasiHariIni->id,
                'nama_customer' => $reservasiHariIni->customer->nama ?? null,
                'jumlah_orang' => $reservasiHariIni->jml_org ?? null,
                'jam' => Carbon::parse($reservasiHariIni->jam_mulai)->format('H:i'),
                'menu_dipesan' => $menuDipesan,
            ];
        } else {
            $meja->reservasi_aktif = null;
        }

        return response()->json($meja);
    }

    public function mejaStore(Request $request)
    {
        $validated = $request->validate([
            'nomor_meja' => 'required|string|max:10|unique:meja,nomor_meja',
            'lantai' => 'required|string|max:50',
            'status' => 'required|in:available,occupied,reserved',
        ]);

        Meja::create($validated);

        return redirect()->route('admin.meja')->with('success', 'Meja berhasil ditambahkan!');
    }

    public function mejaUpdate(Request $request, $id)
    {
        $meja = Meja::findOrFail($id);

        $validated = $request->validate([
            'nomor_meja' => 'required|string|max:20',
            'lantai' => 'required|string|max:50',
            'status' => 'required|in:available,occupied,reserved',
        ]);

        $meja->update($validated);

        return redirect()->route('admin.meja')->with('success', 'Meja berhasil diupdate!');
    }

    public function assignMeja(Request $request, $id)
    {
        $reservasi = Reservasi::findOrFail($id);

        // Hapus assignment meja lama
        $reservasi->detailReservasi()->delete();

        // Simpan relasi meja yang baru dicentang
        if ($request->has('meja_dipilih')) {
            foreach ($request->meja_dipilih as $id_meja) {
                DetailReservasi::create([
                    'id_reservasi' => $reservasi->id,
                    'id_meja' => $id_meja
                ]);
            }
        }

        return redirect()->back()->with('success', 'Meja reservasi berhasil diperbarui!');
    }

    // RESERVASI
    public function reservasi(Request $request, $id = null)
    {
        // Ambil ID dari URL route parameter atau query string ?id=...
        $selectedId = $id ?? $request->query('id');

        $query = Reservasi::with(['customer', 'detailReservasi.meja', 'pesanan.detailPesanan.menu'])
            // ->where('dp_bayar', '>=', 50000)
            ->whereHas('pesanan')
            ->orderBy('tanggal', 'desc')
            ->orderBy('jam_mulai', 'desc');

        if ($request->search) {
            $query->whereHas('customer', function($q) use ($request) {
                $q->where('nama', 'like', '%'.$request->search.'%');
            });
        }

        if ($request->filter && isset($request->filter['status'])) {
            $query->whereHas('pesanan', function($q) use ($request) {
                $q->whereRaw('LOWER(status) = ?', [strtolower($request->filter['status'])]);
            });
        }

        $reservasiList = $query->get();

        // $selectedReservasi = $id 
        //     ? Reservasi::with(['customer', 'detailReservasi.meja', 'pesanan.detailPesanan.menu'])->find($id) 
        //     : $reservasiList->first();
        // HANYA cari data jika ada $selectedId. Jangan default ke ->first()
        $selectedReservasi = $selectedId 
            ? Reservasi::with(['customer', 'detailReservasi.meja', 'pesanan.detailPesanan.menu'])->find($selectedId) 
            : null;

        return view('admin.reservasi', compact('reservasiList', 'selectedReservasi', 'selectedId'));
    }

    public function reservasiUpdate(Request $request, $id)
    {
        $request->validate(['status' => 'required|in:reserved,confirmed,processing,completed,cancelled']);
        $reservasi = Reservasi::with('pesanan')->findOrFail($id);

        if ($reservasi->pesanan) {
            $reservasi->pesanan->update([
                'status' => strtolower($request->status)
            ]);

            // Catat Admin yang mengonfirmasi atau memproses reservasi
            if (in_array($request->status, ['confirmed', 'processing', 'completed', 'cancelled']) && Auth::check()) {
                $updateData['id_user'] = Auth::id();
            }

            $reservasi->pesanan->update($updateData);
        }

        // Catatan: Sebaiknya hapus plot meja HANYA saat status 'cancelled'.
        // Jangan hapus detail_reservasi saat 'completed' agar riwayat plot meja historis tetap bisa dilihat di laporan.
        if ($request->status === 'cancelled') {
            $reservasi->detailReservasi()->delete();
        }

        return redirect()->route('admin.reservasi', $id)->with('success', 'Status reservasi berhasil diupdate!');
    }
}
