<?php

// use Illuminate\Database\Migrations\Migration;
// use Illuminate\Database\Schema\Blueprint;
// use Illuminate\Support\Facades\Schema;

// return new class extends Migration
// {
    /**
     * Run the migrations.
     */
    // public function up(): void
    // {
    //     Schema::create('pembayaran', function (Blueprint $table) {
    //         $table->id();
    //         $table->foreignId('id_pesanan')->constrained('pesanan', 'id')->cascadeOnDelete();
    //         $table->enum('jenis_pembayaran', ['dp', 'pelunasan', 'full']); // Jenis pembayaran
    //         $table->decimal('nominal', 12, 2);                             // Jumlah uang masuk
    //         $table->string('metode', 50);                                  // 'Tunai', 'Midtrans', 'QRIS', 'Debit', 'Transfer Bank', dll.
    //         // $table->enum('kategori', ['cash', 'non_cash']);               // Pengelompokan utama, tdk perlu krn bs pke logika sj lbh efektif
    //         $table->string('snap_token')->nullable();
    //         $table->enum('status', ['success', 'failed', 'pending'])->default('success');
    //         $table->timestamps();
    //     });
    // }

    /**
     * Reverse the migrations.
     */
    // public function down(): void
    // {
    //     Schema::dropIfExists('pembayaran');
    // }
// };
